#pragma once

/*
FATP_META:
  meta_version: 1
  component: StateMachine
  file_role: public_header
  path: fat_p/StateMachine.h
  namespace: fat_p
  layer: Domain
  summary: "Public header for StateMachine."
  api_stability: stable
  related:
    docs_search: "StateMachine"
    tests:
      - tests/test_StateMachine.cpp
  hygiene:
    pragma_once: true
    include_guard: false
    defines_total: 0
    defines_unprefixed: 0
    undefs_total: 0
    includes_windows_h: false
  generated:
    by: fatp-meta-tool
    mode: autogen
*/

/**
 * @file StateMachine.h
 * @brief Type-safe finite state machine with compile-time validation.
 *
 * @details
 * This state machine uses a runtime state index and a compile-time state set.
 * Entry/exit hooks are invoked on default-constructed temporary state objects.
 * Store persistent data in Context.
 *
 * Self-transition requests (transitioning to the current state type) are a
 * no-op: no validation is performed and no hooks are invoked.
 *
 * @note Complexity: transition() is O(1) for both AnyToAny and Strict policies.
 * @note Thread-safety: Not thread-safe. All access must be externally
 *       synchronized, including access to the Context object.
 * @note Reentrancy: Do not call transition() from within on_entry/on_exit hooks.
 *       Debug builds detect reentrant calls and fail-fast (throw or terminate).
 *       Release builds have undefined behavior for reentrant transitions.
 * @note Destruction: The destructor does NOT invoke the current state's
 *       on_exit() hook. If cleanup is required, explicitly transition to a
 *       terminal state before destruction, or perform cleanup in Context's
 *       destructor.
 */

#include <array>
#include <concepts>
#include <cstddef>
#include <exception>
#include <stdexcept>
#include <tuple>
#include <type_traits>
#include <utility>

namespace fat_p
{
// ====================================================================
// 1. Policies and Checker Traits
// ====================================================================

// --- Transition Policies ---
/** @brief Enforces only explicitly defined transitions in the TransitionList. */
struct StrictTransitionPolicy
{
};

/** @brief Allows any state to transition to any other state. */
struct AnyToAnyTransitionPolicy
{
};

// --- Action Policies ---
/** @brief Uses static_assert to ensure all State::on_entry/on_exit actions are noexcept. */
struct NoExceptActionPolicy
{
};

/** @brief Default policy allowing actions to throw. */
struct ThrowingActionPolicy
{
};

namespace detail
{

// --- State Contract Concepts (C++20) ---
template <typename TState, typename TContext>
concept HasEntryExit = requires(TState& s, TContext& ctx)
{
    { s.on_entry(ctx) } -> std::same_as<void>;
    { s.on_exit(ctx) } -> std::same_as<void>;
};

template <typename TState, typename TContext>
concept HasNoexceptEntryExit = requires(TState& s, TContext& ctx)
{
    { s.on_entry(ctx) } noexcept -> std::same_as<void>;
    { s.on_exit(ctx) } noexcept -> std::same_as<void>;
};

// --- Unique States Checker ---
template <typename... Ts>
struct AreUnique;

template <>
struct AreUnique<> : std::true_type
{
};

template <typename T, typename... Ts>
struct AreUnique<T, Ts...>
    : std::conjunction<std::negation<std::disjunction<std::is_same<T, Ts>...>>, AreUnique<Ts...>>
{
};

} // namespace detail

// ====================================================================
// 2. Main State Machine Class (Base Template)
// ====================================================================

/**
 * @brief A zero-overhead, compile-time defined state machine based on policies.
 *
 * @tparam Context The mutable data object shared by all states.
 * @tparam TransitionList A std::tuple of std::pair<FromState, ToState> for allowed transitions.
 * @tparam TTransitionPolicy (StrictTransitionPolicy or AnyToAnyTransitionPolicy).
 * @tparam TActionPolicy (NoExceptActionPolicy or ThrowingActionPolicy).
 * @tparam InitialIndex The index of the initial state (default: 0).
 * @tparam States A variadic pack of state types.
 */
template <typename Context,
          typename TransitionList,
          typename TTransitionPolicy,
          typename TActionPolicy,
          std::size_t InitialIndex = 0,
          typename... States>
class StateMachine
{
    using StateTuple = std::tuple<States...>;
    static constexpr std::size_t kNumStates = sizeof...(States);
    static constexpr bool kNoexceptActions = std::is_same_v<TActionPolicy, NoExceptActionPolicy>;

    using ActionFn = std::conditional_t<kNoexceptActions, void (*)(Context&) noexcept, void (*)(Context&)>;

    // Compile-time policy validation
    static_assert(std::is_same_v<TTransitionPolicy, AnyToAnyTransitionPolicy>,
                  "TTransitionPolicy must be StrictTransitionPolicy or AnyToAnyTransitionPolicy");
    static_assert(std::is_same_v<TActionPolicy, NoExceptActionPolicy> ||
                      std::is_same_v<TActionPolicy, ThrowingActionPolicy>,
                  "TActionPolicy must be NoExceptActionPolicy or ThrowingActionPolicy");

    // Compile-time state validation
    static_assert(kNumStates > 0, "StateMachine must have at least one state");
    static_assert(InitialIndex < kNumStates, "InitialIndex must be within 0 to kNumStates-1");
    static_assert(detail::AreUnique<States...>::value, "State types must be unique in the variadic pack");
    static_assert((std::is_default_constructible_v<States> && ...),
                  "CTSM Error: All state types must be default-constructible "
                  "(hooks are invoked on TState{})");
    static_assert(!kNoexceptActions || (std::is_nothrow_default_constructible_v<States> && ...),
                  "CTSM Error: NoExceptActionPolicy requires all state types to be "
                  "nothrow default-constructible (hooks are invoked on TState{} inside "
                  "noexcept wrappers)");
    static_assert((detail::HasEntryExit<States, Context> && ...),
                  "CTSM Error: All state types must provide "
                  "void on_entry(Context&) and void on_exit(Context&)");
    static_assert(!kNoexceptActions || (detail::HasNoexceptEntryExit<States, Context> && ...),
                  "CTSM Error: NoExceptActionPolicy requires "
                  "on_entry and on_exit to be noexcept");

    // --- State Storage ---
    Context& mContext;
    std::size_t mCurrentStateIndex = InitialIndex;

#ifndef NDEBUG
    bool mInTransition = false;
#endif

    // --- Compile-Time Index Finder (Non-Recursive) ---
    template <typename TState, std::size_t... I>
    static consteval int findStateIndexImpl(std::index_sequence<I...>)
    {
        constexpr std::array<bool, kNumStates> kMatches =
            {std::is_same_v<TState, std::tuple_element_t<I, StateTuple>>...};
        for (std::size_t j = 0; j < kNumStates; ++j)
        {
            if (kMatches[j])
            {
                return static_cast<int>(j);
            }
        }
        return -1;
    }

    template <typename TState>
    static consteval int getStateIndex()
    {
        return findStateIndexImpl<TState>(std::make_index_sequence<kNumStates>{});
    }

    template <typename TState>
    static void entryAction(Context& ctx) noexcept(kNoexceptActions)
    {
        TState{}.on_entry(ctx);
    }

    template <typename TState>
    static void exitAction(Context& ctx) noexcept(kNoexceptActions)
    {
        TState{}.on_exit(ctx);
    }

    static constexpr std::array<ActionFn, kNumStates> kEntryActions = {&entryAction<States>...};
    static constexpr std::array<ActionFn, kNumStates> kExitActions = {&exitAction<States>...};

    void dispatchExitAction(std::size_t targetIndex) noexcept(kNoexceptActions)
    {
        kExitActions[targetIndex](mContext);
    }

    void dispatchEntryAction(std::size_t targetIndex) noexcept(kNoexceptActions)
    {
        kEntryActions[targetIndex](mContext);
    }

public:
    explicit StateMachine(Context& context)
        : mContext(context)
        , mCurrentStateIndex(InitialIndex)
    {
        // Enter the initial state
        dispatchEntryAction(InitialIndex);
    }

    ~StateMachine() = default;

    StateMachine(const StateMachine&) = delete;
    StateMachine& operator=(const StateMachine&) = delete;
    StateMachine(StateMachine&&) = delete;
    StateMachine& operator=(StateMachine&&) = delete;

    // --- Compile-Time Introspection ---

    /** @brief Number of states in this state machine. */
    static constexpr std::size_t state_count = kNumStates;

    /** @brief Index of the initial state. */
    static constexpr std::size_t initial_state_index = InitialIndex;

    /**
     * @brief Checks at compile time whether TState is in the state machine.
     * @tparam TState The state type to check.
     */
    template <typename TState>
    static constexpr bool contains_state = (getStateIndex<TState>() != -1);

    /**
     * @brief Gets the number of states in this state machine.
     * @note Complexity: O(1).
     */
    [[nodiscard]] static constexpr std::size_t stateCount() noexcept
    {
        return kNumStates;
    }

    /**
     * @brief Initiates a transition to the specified state type.
     *
     * @tparam TNextState The target state type (must be in the States pack).
     *
     * @note Complexity: O(1).
     * @note Thread-safety: Not thread-safe.
     * @note Reentrancy: Do not call from within on_entry/on_exit hooks.
     *       Debug builds detect and fail-fast; Release behavior is undefined.
     * @note Exception safety (ThrowingActionPolicy):
     *       - If the exit hook throws, the state index remains unchanged.
     *       - If the entry hook throws, the state index is updated to the target index.
     */
    template <typename TNextState>
    void transition() noexcept(kNoexceptActions)
    {
        constexpr int kNextIndex = getStateIndex<TNextState>();
        static_assert(kNextIndex != -1, "Target state type not found in the StateMachine definition");

        const std::size_t currentIndex = mCurrentStateIndex;
        const std::size_t nextStateIndex = static_cast<std::size_t>(kNextIndex);

#ifndef NDEBUG
        // Reentrancy guard - BEFORE self-transition check
        // Even self-transitions from within hooks indicate a logic error
        struct ReentrancyGuard
        {
            bool& mFlag;

            explicit ReentrancyGuard(bool& flag)
                : mFlag(flag)
            {
                if (mFlag)
                {
                    if constexpr (kNoexceptActions)
                    {
                        std::terminate();
                    }
                    else
                    {
                        throw std::runtime_error(
                            "CTSM Error: Reentrant transition detected - "
                            "do not call transition() from within on_entry/on_exit");
                    }
                }
                mFlag = true;
            }

            ~ReentrancyGuard()
            {
                mFlag = false;
            }
        };

        [[maybe_unused]] ReentrancyGuard guard(mInTransition);
#endif

        // Self-transition is a no-op
        if (currentIndex == nextStateIndex)
        {
            return;
        }

        // Exit Action
        dispatchExitAction(currentIndex);

        // Update State
        mCurrentStateIndex = nextStateIndex;

        // Entry Action
        dispatchEntryAction(nextStateIndex);
    }

    /**
     * @brief Gets the runtime index of the current state.
     *
     * @note Complexity: O(1).
     * @note Thread-safety: Not thread-safe.
     */
    [[nodiscard]] std::size_t currentStateIndex() const noexcept
    {
        return mCurrentStateIndex;
    }

    /**
     * @brief Checks whether the state machine is currently in the specified state type.
     *
     * @note Complexity: O(1).
     * @note Thread-safety: Not thread-safe.
     */
    template <typename TState>
    [[nodiscard]] bool isInState() const noexcept
    {
        constexpr int kIndex = getStateIndex<TState>();
        static_assert(kIndex != -1, "Queried state type not found in StateMachine");
        return mCurrentStateIndex == static_cast<std::size_t>(kIndex);
    }
};

// ====================================================================
// 3. Specialization for StrictTransitionPolicy
// ====================================================================

/**
 * @brief StateMachine specialization with strict transition validation.
 *
 * Only transitions explicitly listed in TransitionList are allowed at runtime.
 * Invalid transitions throw std::runtime_error before any hooks execute.
 *
 * @note Memory: Uses a compile-time transition matrix of size O(N^2) where
 *       N = sizeof...(States). For 32 states, this is 1024 bytes. Consider
 *       AnyToAnyTransitionPolicy if memory is constrained and all transitions
 *       are valid by design.
 *
 * @note Complexity: Transition validation is O(1) (matrix lookup).
 */
template <typename Context,
          typename TransitionList,
          typename TActionPolicy,
          std::size_t InitialIndex,
          typename... States>
class StateMachine<Context, TransitionList, StrictTransitionPolicy, TActionPolicy, InitialIndex, States...>
{
    using StateTuple = std::tuple<States...>;
    static constexpr std::size_t kNumStates = sizeof...(States);
    static constexpr bool kNoexceptActions = std::is_same_v<TActionPolicy, NoExceptActionPolicy>;

    using ActionFn = std::conditional_t<kNoexceptActions, void (*)(Context&) noexcept, void (*)(Context&)>;

    // Compile-time policy validation
    static_assert(std::is_same_v<TActionPolicy, NoExceptActionPolicy> ||
                      std::is_same_v<TActionPolicy, ThrowingActionPolicy>,
                  "TActionPolicy must be NoExceptActionPolicy or ThrowingActionPolicy");

    // Compile-time state validation
    static_assert(kNumStates > 0, "StateMachine must have at least one state");
    static_assert(InitialIndex < kNumStates, "InitialIndex must be within 0 to kNumStates-1");
    static_assert(detail::AreUnique<States...>::value, "State types must be unique in the variadic pack");
    static_assert((std::is_default_constructible_v<States> && ...),
                  "CTSM Error: All state types must be default-constructible "
                  "(hooks are invoked on TState{})");
    static_assert(!kNoexceptActions || (std::is_nothrow_default_constructible_v<States> && ...),
                  "CTSM Error: NoExceptActionPolicy requires all state types to be "
                  "nothrow default-constructible (hooks are invoked on TState{} inside "
                  "noexcept wrappers)");
    static_assert((detail::HasEntryExit<States, Context> && ...),
                  "CTSM Error: All state types must provide "
                  "void on_entry(Context&) and void on_exit(Context&)");
    static_assert(!kNoexceptActions || (detail::HasNoexceptEntryExit<States, Context> && ...),
                  "CTSM Error: NoExceptActionPolicy requires "
                  "on_entry and on_exit to be noexcept");

    // --- State Storage ---
    Context& mContext;
    std::size_t mCurrentStateIndex = InitialIndex;

#ifndef NDEBUG
    bool mInTransition = false;
#endif

    // --- Compile-Time Index Finder ---
    template <typename TState, std::size_t... I>
    static consteval int findStateIndexImpl(std::index_sequence<I...>)
    {
        constexpr std::array<bool, kNumStates> kMatches =
            {std::is_same_v<TState, std::tuple_element_t<I, StateTuple>>...};
        for (std::size_t j = 0; j < kNumStates; ++j)
        {
            if (kMatches[j])
            {
                return static_cast<int>(j);
            }
        }
        return -1;
    }

    template <typename TState>
    static consteval int getStateIndex()
    {
        return findStateIndexImpl<TState>(std::make_index_sequence<kNumStates>{});
    }

    template <typename TState>
    static void entryAction(Context& ctx) noexcept(kNoexceptActions)
    {
        TState{}.on_entry(ctx);
    }

    template <typename TState>
    static void exitAction(Context& ctx) noexcept(kNoexceptActions)
    {
        TState{}.on_exit(ctx);
    }

    static constexpr std::array<ActionFn, kNumStates> kEntryActions = {&entryAction<States>...};
    static constexpr std::array<ActionFn, kNumStates> kExitActions = {&exitAction<States>...};

    void dispatchExitAction(std::size_t targetIndex) noexcept(kNoexceptActions)
    {
        kExitActions[targetIndex](mContext);
    }

    void dispatchEntryAction(std::size_t targetIndex) noexcept(kNoexceptActions)
    {
        kEntryActions[targetIndex](mContext);
    }

    template <typename TPair>
    static consteval bool isTransitionPairValid()
    {
        using From = typename TPair::first_type;
        using To = typename TPair::second_type;
        return (getStateIndex<From>() != -1) && (getStateIndex<To>() != -1);
    }

    template <typename List, std::size_t... Idx>
    static consteval bool areTransitionTypesValidImpl(std::index_sequence<Idx...>)
    {
        return (isTransitionPairValid<std::tuple_element_t<Idx, List>>() && ...);
    }

    static constexpr bool kTransitionTypesValid =
        areTransitionTypesValidImpl<TransitionList>(std::make_index_sequence<std::tuple_size_v<TransitionList>>{});

    static_assert(kTransitionTypesValid,
                  "TransitionList contains a state type not present in the StateMachine definition");

    // --- Transition Matrix Building (Optimized with single index sequence) ---
    template <typename TPair>
    static consteval void setTransition(std::array<std::array<bool, kNumStates>, kNumStates>& matrix)
    {
        constexpr std::size_t from_index =
            static_cast<std::size_t>(getStateIndex<typename TPair::first_type>());
        constexpr std::size_t to_index =
            static_cast<std::size_t>(getStateIndex<typename TPair::second_type>());
        matrix[from_index][to_index] = true;
    }

    template <typename List, std::size_t... Idx>
    static consteval auto buildTransitionMatrixImpl(std::index_sequence<Idx...>)
    {
        std::array<std::array<bool, kNumStates>, kNumStates> matrix{};
        (setTransition<std::tuple_element_t<Idx, List>>(matrix), ...);
        return matrix;
    }

    template <typename List>
    static consteval auto buildTransitionMatrix()
    {
        return buildTransitionMatrixImpl<List>(std::make_index_sequence<std::tuple_size_v<List>>{});
    }

    static constexpr auto kTransitionMatrix = buildTransitionMatrix<TransitionList>();

public:
    explicit StateMachine(Context& context)
        : mContext(context)
        , mCurrentStateIndex(InitialIndex)
    {
        // Enter the initial state
        dispatchEntryAction(InitialIndex);
    }

    ~StateMachine() = default;

    StateMachine(const StateMachine&) = delete;
    StateMachine& operator=(const StateMachine&) = delete;
    StateMachine(StateMachine&&) = delete;
    StateMachine& operator=(StateMachine&&) = delete;

    // --- Compile-Time Introspection ---

    /** @brief Number of states in this state machine. */
    static constexpr std::size_t state_count = kNumStates;

    /** @brief Index of the initial state. */
    static constexpr std::size_t initial_state_index = InitialIndex;

    /**
     * @brief Checks at compile time whether TState is in the state machine.
     * @tparam TState The state type to check.
     */
    template <typename TState>
    static constexpr bool contains_state = (getStateIndex<TState>() != -1);

    /**
     * @brief Checks at compile time whether a transition is allowed.
     * @tparam TFrom The source state type.
     * @tparam TTo The target state type.
     *
     * @note Self-transitions are always allowed (they are defined as a no-op).
     */
    template <typename TFrom, typename TTo>
    static constexpr bool is_transition_allowed = []() consteval {
        constexpr int kFromIndex = getStateIndex<TFrom>();
        constexpr int kToIndex = getStateIndex<TTo>();

        static_assert(kFromIndex != -1, "Source state type not found in the StateMachine definition");
        static_assert(kToIndex != -1, "Target state type not found in the StateMachine definition");

        if constexpr (std::is_same_v<TFrom, TTo>)
        {
            return true;
        }

        return kTransitionMatrix[static_cast<std::size_t>(kFromIndex)]
                                [static_cast<std::size_t>(kToIndex)];
    }();

    /**
     * @brief Gets the number of states in this state machine.
     * @note Complexity: O(1).
     */
    [[nodiscard]] static constexpr std::size_t stateCount() noexcept
    {
        return kNumStates;
    }

    /**
     * @brief Initiates a transition to the specified state type.
     *
     * @tparam TNextState The target state type (must be in the States pack).
     * @throws std::runtime_error if transition is not in TransitionList.
     *
     * @note Complexity: O(1).
     * @note Thread-safety: Not thread-safe.
     * @note Reentrancy: Do not call from within on_entry/on_exit hooks.
     *       Debug builds detect and fail-fast; Release behavior is undefined.
     * @note Invalid transitions are rejected before running any entry/exit hooks.
     * @note Exception safety (ThrowingActionPolicy):
     *       - If the exit hook throws, the state index remains unchanged.
     *       - If the entry hook throws, the state index is updated to the target index.
     */
    template <typename TNextState>
    void transition()
    {
        constexpr int kNextIndex = getStateIndex<TNextState>();
        static_assert(kNextIndex != -1, "Target state type not found in the StateMachine definition");

        const std::size_t currentIndex = mCurrentStateIndex;
        const std::size_t nextStateIndex = static_cast<std::size_t>(kNextIndex);

#ifndef NDEBUG
        // Reentrancy guard - BEFORE self-transition check
        // Even self-transitions from within hooks indicate a logic error
        struct ReentrancyGuard
        {
            bool& mFlag;

            explicit ReentrancyGuard(bool& flag)
                : mFlag(flag)
            {
                if (mFlag)
                {
                    // StrictPolicy can always throw (it's not noexcept anyway)
                    throw std::runtime_error(
                        "CTSM Error: Reentrant transition detected - "
                        "do not call transition() from within on_entry/on_exit");
                }
                mFlag = true;
            }

            ~ReentrancyGuard()
            {
                mFlag = false;
            }
        };

        [[maybe_unused]] ReentrancyGuard guard(mInTransition);
#endif

        // Self-transition is a no-op
        if (currentIndex == nextStateIndex)
        {
            return;
        }

        // Runtime Transition Validation
        if (!kTransitionMatrix[currentIndex][nextStateIndex])
        {
            throw std::runtime_error("CTSM Error: Transition is not valid under StrictTransitionPolicy");
        }

        // Exit Action
        dispatchExitAction(currentIndex);

        // Update State
        mCurrentStateIndex = nextStateIndex;

        // Entry Action
        dispatchEntryAction(nextStateIndex);
    }

    /**
     * @brief Gets the runtime index of the current state.
     *
     * @note Complexity: O(1).
     * @note Thread-safety: Not thread-safe.
     */
    [[nodiscard]] std::size_t currentStateIndex() const noexcept
    {
        return mCurrentStateIndex;
    }

    /**
     * @brief Checks whether the state machine is currently in the specified state type.
     *
     * @note Complexity: O(1).
     * @note Thread-safety: Not thread-safe.
     */
    template <typename TState>
    [[nodiscard]] bool isInState() const noexcept
    {
        constexpr int kIndex = getStateIndex<TState>();
        static_assert(kIndex != -1, "Queried state type not found in StateMachine");
        return mCurrentStateIndex == static_cast<std::size_t>(kIndex);
    }
};

} // namespace fat_p
