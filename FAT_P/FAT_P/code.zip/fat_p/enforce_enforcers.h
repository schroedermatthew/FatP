/**
 * @file enforce_enforcers.h
 * @brief Defines the core RAII object used by all contract enforcement
 * macros, specializing on the chosen Raiser policy for failure handling.
 *
 *
 *
 * @layer Foundation
 *
 * @details This file contains the primary Enforcer class and the factory
 * functions necessary to implement the fluent contract syntax:
 * `enforce(cond)("msg", value, ...).`
 */
#pragma once
/*
FATP_META:
  meta_version: 1
  component: enforce_enforcers
  file_role: public_header
  path: fat_p/enforce_enforcers.h
  namespace: fat_p
  layer: Foundation
  summary: "Public header for enforce_enforcers."
  api_stability: in_work
  related:
    docs_search: "enforce_enforcers"
  hygiene:
    pragma_once: true
    include_guard: false
    defines_total: 5
    defines_unprefixed: 0
    undefs_total: 0
    includes_windows_h: false
  generated:
    by: fatp-meta-tool
    mode: autogen
*/
#include "CppStandardDetection.h"
#include "FatPConfig.h"

#include <exception>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>

#include "ContractException.h"
#include "enforce_raisers.h"
#include "Stringify.h"

// ==================================================================================
// Portable Compiler Attributes
// ==================================================================================

// FATP_NOINLINE: Provided by FatPConfig.h (Rule F: single source of truth)

// FATP_UNLIKELY_COND: Branch hint (C++20 [[unlikely]] where available, otherwise no-op)
#if FATP_HAS_EXPECTED || FATP_CPP20_OR_LATER
#define FATP_UNLIKELY_IF(cond) if (cond) [[unlikely]]
#else
#define FATP_UNLIKELY_IF(cond) if (cond)
#endif

namespace fat_p
{

/**
 * @brief Utility struct for building the final diagnostic message string.
 *
 * @details This builder uses `std::ostringstream` and a C++17 fold
 * expression with `toString` to safely concatenate any number
 * of streamable arguments into a single message.
 */
struct MessageBuilder
{
    std::ostringstream ss;

    /**
     * @brief Safely converts and appends a single argument to the stream.
     * @tparam T The type of the message argument.
     * @param msg The message argument to append.
     */
    template <typename T>
    void append_message(T&& msg)
    {
        ss << toString(std::forward<T>(msg));
    }

    /**
     * @brief Concatenates a variadic list of arguments into the message.
     * @tparam Msgs The types of the message arguments.
     * @param msgs The arguments to concatenate.
     */
    template <typename... Msgs>
    void format(Msgs&&... msgs)
    {
        (append_message(std::forward<Msgs>(msgs)), ...);
    }

    /**
     * @brief Formats and returns the complete, structured error message.
     * @param locus The file and line number where the failure occurred.
     * @param expression The source code text of the failed condition.
     * @return The complete error message string.
     */
    std::string get_message(const char* locus, const std::string& expression) const
    {
        return "\n\tCondition: " + expression + "\n\tLocus: " + locus + "\n\tMessage: " + ss.str();
    }
};

// Helper trait to detect ExpectedRaiser<E> for any E
template <typename T>
struct is_expected_raiser : std::false_type
{
};

template <typename E>
struct is_expected_raiser<ExpectedRaiser<E>> : std::true_type
{
};

template <typename T>
inline constexpr bool is_expected_raiser_v = is_expected_raiser<T>::value;

// --- 1. The Core Enforcer (Active Check) ---
/**
 * @brief The main RAII object created by all active contract macros.
 *
 * @details The destructor is guaranteed to run, checking the condition
 * result and invoking the Raiser policy on failure.
 *
 * CRITICAL: This class is designed for ZERO overhead when the condition passes.
 * All members are trivially destructible (pointers/bool only). The expensive
 * operations (string building, ostringstream, exception throwing) only happen
 * in the failure path, which is marked cold.
 *
 * @tparam Raiser The failure consequence policy (e.g., throw, log, abort).
 */
template <typename Raiser>
class Enforcer
{
    const bool mPassed;
    const char* const mLocus;
    const char* const mExpression;
    const char* user_message_ = nullptr; // Points to static string or nullptr - NO allocation

public:
    /**
     * @brief Constructor for the Enforcer.
     * @param passed The result of the condition check (true if passed).
     * @param expression_str The source code text of the condition.
     * @param locus The file and line number of the contract call.
     */
    constexpr Enforcer(bool passed, const char* expression_str, const char* locus) noexcept
        : mPassed(passed)
        , mLocus(locus)
        , mExpression(expression_str)
    {
    }

    /**
     * @brief The core RAII check logic runs here upon scope exit.
     *
     * @details Calls `Raiser::fail` if the condition was false. The failure
     * path is marked cold to help the optimizer keep the hot path tight.
     */
    ~Enforcer() noexcept(std::is_same_v<Raiser, NoThrowRaiser> || std::is_same_v<Raiser, WarningToCerrRaiser> ||
                         std::is_same_v<Raiser, NoOpRaiser>)
    {
        FATP_UNLIKELY_IF(!mPassed)
        {
            fail_impl();
        }
    }

private:
    /**
     * @brief Cold path - only called on failure
     *
     * Marked noinline to prevent the exception handling machinery from
     * polluting the hot path where the condition passes.
     */
    FATP_NOINLINE
    void fail_impl()
    {
        std::string full_message = "\n\tCondition: ";
        full_message += mExpression;
        full_message += "\n\tLocus: ";
        full_message += mLocus;
        if (user_message_)
        {
            full_message += "\n\tMessage: ";
            full_message += user_message_;
        }

        if constexpr (std::is_same_v<Raiser, NoThrowRaiser> || std::is_same_v<Raiser, WarningToCerrRaiser> ||
                      std::is_same_v<Raiser, NoOpRaiser>)
        {
            Raiser::fail(full_message);
        }
        else
        {
            Raiser::fail(full_message);
        }
    }

public:
    /**
     * @brief Set diagnostic message (simple const char* version).
     */
    void operator()(const char* msg) noexcept
    {
        FATP_UNLIKELY_IF(!mPassed)
        {
            user_message_ = msg;
        }
    }

    /**
     * @brief Set diagnostic message (variadic version for complex messages).
     *
     * Uses ostringstream to format multiple arguments. Only called on failure.
     */
    template <typename... Msgs>
    void operator()(Msgs&&... msgs)
    {
        FATP_UNLIKELY_IF(!mPassed)
        {
            // Build message on heap - only happens on failure
            static thread_local std::string formatted_message;
            formatted_message.clear();
            std::ostringstream ss;
            (ss << ... << toString(std::forward<Msgs>(msgs)));
            formatted_message = ss.str();
            user_message_ = formatted_message.c_str();
        }
    }

    /**
     * @brief The asterisk operator forces full evaluation of the Enforcer
     * object before it leaves scope.
     */
    Enforcer& operator*()
    {
        return *this;
    }
};

// --- 2. The NoOp Enforcer (Passive Check) ---
/**
 * @brief A specialized Enforcer used when checks are disabled
 * (e.g., enforce() in Release).
 *
 * @details All methods are empty, resulting in zero overhead due to
 * optimization. It is used when the policy is `NoOpRaiser`.
 */
class NoOpEnforcer
{
public:
    /**
     * @brief Zero-overhead constructor.
     */
    NoOpEnforcer(bool /* passed */, const char* /* expression_str */, const char* /* locus */) noexcept
    {
    }

    /**
     * @brief Zero-overhead destructor.
     */
    ~NoOpEnforcer() noexcept
    {
    }

    /**
     * @brief Zero-overhead message operator.
     */
    template <typename... Msgs>
    void operator()(Msgs&&...)
    {
    }

    /**
     * @brief Zero-overhead dereference operator.
     */
    NoOpEnforcer& operator*()
    {
        return *this;
    }
};

// --- 3. Factory Function for Policy Selection ---
/**
 * @brief Factory function that returns the appropriate Enforcer type
 * based on the Raiser policy.
 *
 * @details Uses C++17 `if constexpr` to select between the standard
 * `Enforcer` and the zero-overhead `NoOpEnforcer` at compile time.
 * @tparam Raiser The failure consequence policy.
 * @param passed The result of the condition check.
 * @param expression_str The source code text of the condition.
 * @param locus The file and line number of the contract call.
 * @return Either an `Enforcer<Raiser>` or `NoOpEnforcer` instance.
 */
template <typename Raiser>
[[nodiscard]] auto MakeEnforcer(bool passed, const char* expression_str, const char* locus)
{
    if constexpr (std::is_same_v<Raiser, NoOpRaiser>)
    {
        return NoOpEnforcer(passed, expression_str, locus);
    }
    else
    {
        return Enforcer<Raiser>(passed, expression_str, locus);
    }
}

} // namespace fat_p
