#define BOOST_TEST_MODULE PolynomialRootFinderTests

#ifdef BOOST_TEST_INCLUDED
// Header-only mode (more portable, no linking required)
#include <boost/test/included/unit_test.hpp>
#else
// Linked mode (requires libboost_unit_test_framework)
#include <boost/test/unit_test.hpp>
#endif

#include "PolynomialRootFinder.hpp"

#include <cmath>
#include <numbers>

using FatP::PolynomialRootFinder;
using FatP::RootResult;
using FatP::RootStatus;

namespace
{
    constexpr double TOLERANCE = 1e-12;
    // Note: BOOST_CHECK_CLOSE interprets tolerance as percentage
    // LOOSE_TOL = 1e-10 means 1e-10% = 1e-12 relative tolerance
    constexpr double LOOSE_TOL = 1e-10;
}

// ============================================================================
// Polynomial Evaluation Tests
// ============================================================================

BOOST_AUTO_TEST_SUITE(EvaluationTests)

BOOST_AUTO_TEST_CASE(EvaluateConstant)
{
    // p(x) = 5
    std::vector<double> coeffs = {5.0};
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, 0.0), 5.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, 100.0), 5.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, -42.0), 5.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(EvaluateLinear)
{
    // p(x) = 2 + 3x
    std::vector<double> coeffs = {2.0, 3.0};
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, 0.0), 2.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, 1.0), 5.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, -1.0), -1.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(EvaluateQuadratic)
{
    // p(x) = 1 - x^2  (coeffs: [1, 0, -1])
    std::vector<double> coeffs = {1.0, 0.0, -1.0};
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, 0.0), 1.0, LOOSE_TOL);
    BOOST_CHECK_SMALL(PolynomialRootFinder<>::evaluate(coeffs, 1.0), LOOSE_TOL);
    BOOST_CHECK_SMALL(PolynomialRootFinder<>::evaluate(coeffs, -1.0), LOOSE_TOL);
    BOOST_CHECK_CLOSE(PolynomialRootFinder<>::evaluate(coeffs, 2.0), -3.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(EvaluateCubic)
{
    // p(x) = x^3 - 6x^2 + 11x - 6 = (x-1)(x-2)(x-3)
    std::vector<double> coeffs = {-6.0, 11.0, -6.0, 1.0};
    BOOST_CHECK_SMALL(PolynomialRootFinder<>::evaluate(coeffs, 1.0), LOOSE_TOL);
    BOOST_CHECK_SMALL(PolynomialRootFinder<>::evaluate(coeffs, 2.0), LOOSE_TOL);
    BOOST_CHECK_SMALL(PolynomialRootFinder<>::evaluate(coeffs, 3.0), LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(EvaluateEmpty)
{
    std::vector<double> coeffs;
    BOOST_CHECK_SMALL(PolynomialRootFinder<>::evaluate(coeffs, 5.0), LOOSE_TOL);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Derivative Tests
// ============================================================================

BOOST_AUTO_TEST_SUITE(DerivativeTests)

BOOST_AUTO_TEST_CASE(DerivativeConstant)
{
    // p(x) = 7, p'(x) = 0
    std::vector<double> coeffs = {7.0};
    auto [f, df] = PolynomialRootFinder<>::evaluateWithDerivative(coeffs, 3.0);
    BOOST_CHECK_CLOSE(f, 7.0, LOOSE_TOL);
    BOOST_CHECK_SMALL(df, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(DerivativeLinear)
{
    // p(x) = 2 + 3x, p'(x) = 3
    std::vector<double> coeffs = {2.0, 3.0};
    auto [f, df] = PolynomialRootFinder<>::evaluateWithDerivative(coeffs, 5.0);
    BOOST_CHECK_CLOSE(f, 17.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(df, 3.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(DerivativeQuadratic)
{
    // p(x) = 1 + 2x + 3x^2, p'(x) = 2 + 6x
    std::vector<double> coeffs = {1.0, 2.0, 3.0};
    auto [f, df] = PolynomialRootFinder<>::evaluateWithDerivative(coeffs, 2.0);
    BOOST_CHECK_CLOSE(f, 1.0 + 4.0 + 12.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(df, 2.0 + 12.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(DerivativeCubic)
{
    // p(x) = x^3 - x, p'(x) = 3x^2 - 1
    std::vector<double> coeffs = {0.0, -1.0, 0.0, 1.0};
    auto [f, df] = PolynomialRootFinder<>::evaluateWithDerivative(coeffs, 2.0);
    BOOST_CHECK_CLOSE(f, 8.0 - 2.0, LOOSE_TOL);      // 6
    BOOST_CHECK_CLOSE(df, 12.0 - 1.0, LOOSE_TOL);    // 11
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Root Finding Tests - Linear
// ============================================================================

BOOST_AUTO_TEST_SUITE(LinearRootTests)

BOOST_AUTO_TEST_CASE(SimpleLinearRoot)
{
    // p(x) = -2 + x, root at x = 2
    std::vector<double> coeffs = {-2.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 2.0, LOOSE_TOL);
    BOOST_CHECK_SMALL(result.functionValue, TOLERANCE * 10);
}

BOOST_AUTO_TEST_CASE(LinearRootNegativeSlope)
{
    // p(x) = 6 - 2x, root at x = 3
    std::vector<double> coeffs = {6.0, -2.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 10.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 3.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(LinearRootAtEndpoint)
{
    // p(x) = x, root at x = 0
    std::vector<double> coeffs = {0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_SMALL(result.root, TOLERANCE * 10);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Root Finding Tests - Quadratic
// ============================================================================

BOOST_AUTO_TEST_SUITE(QuadraticRootTests)

BOOST_AUTO_TEST_CASE(QuadraticPositiveRoots)
{
    // p(x) = (x-1)(x-4) = x^2 - 5x + 4
    std::vector<double> coeffs = {4.0, -5.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    // Find root near 1
    auto result1 = finder.findRoot(coeffs, 0.0, 2.5);
    BOOST_CHECK(result1.converged());
    BOOST_CHECK_CLOSE(result1.root, 1.0, LOOSE_TOL);

    // Find root near 4
    auto result4 = finder.findRoot(coeffs, 2.5, 6.0);
    BOOST_CHECK(result4.converged());
    BOOST_CHECK_CLOSE(result4.root, 4.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(QuadraticIrrationalRoot)
{
    // p(x) = x^2 - 2, roots at ±sqrt(2)
    std::vector<double> coeffs = {-2.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 1.0, 2.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, std::sqrt(2.0), LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(QuadraticNegativeRoot)
{
    // p(x) = x^2 - 2, roots at ±sqrt(2)
    std::vector<double> coeffs = {-2.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, -2.0, 0.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, -std::sqrt(2.0), LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(QuadraticNegativeRootReversedSigns)
{
    // p(x) = x^2 - 2, interval [-2, 0] where f(-2) > 0 and f(0) < 0
    // This tests the case where fLo > 0 and fHi < 0 (was broken before)
    std::vector<double> coeffs = {-2.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    // f(-2) = 4 - 2 = 2 > 0
    // f(0) = -2 < 0
    auto result = finder.findRoot(coeffs, -2.0, 0.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, -std::sqrt(2.0), LOOSE_TOL);
    BOOST_CHECK_SMALL(result.functionValue, TOLERANCE * 10);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Root Finding Tests - Higher Degree
// ============================================================================

BOOST_AUTO_TEST_SUITE(HigherDegreeTests)

BOOST_AUTO_TEST_CASE(CubicMultipleRoots)
{
    // p(x) = (x-1)(x-2)(x-3) = x^3 - 6x^2 + 11x - 6
    std::vector<double> coeffs = {-6.0, 11.0, -6.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto r1 = finder.findRoot(coeffs, 0.5, 1.5);
    auto r2 = finder.findRoot(coeffs, 1.5, 2.5);
    auto r3 = finder.findRoot(coeffs, 2.5, 3.5);

    BOOST_CHECK(r1.converged());
    BOOST_CHECK(r2.converged());
    BOOST_CHECK(r3.converged());
    BOOST_CHECK_CLOSE(r1.root, 1.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(r2.root, 2.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(r3.root, 3.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(QuarticRoot)
{
    // p(x) = x^4 - 16, root at x = 2
    std::vector<double> coeffs = {-16.0, 0.0, 0.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 1.0, 3.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 2.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(Degree5Polynomial)
{
    // p(x) = x^5 - x - 1, has a real root near 1.1673
    std::vector<double> coeffs = {-1.0, -1.0, 0.0, 0.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 1.0, 2.0);

    BOOST_CHECK(result.converged());
    // Verify it's actually a root
    BOOST_CHECK_SMALL(PolynomialRootFinder<>::evaluate(coeffs, result.root), TOLERANCE * 10);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Edge Cases and Robustness
// ============================================================================

BOOST_AUTO_TEST_SUITE(EdgeCaseTests)

BOOST_AUTO_TEST_CASE(TightBracket)
{
    // p(x) = x - 1, root at 1
    std::vector<double> coeffs = {-1.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.9999, 1.0001);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 1.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(WideBracket)
{
    // p(x) = x - 1, root at 1
    std::vector<double> coeffs = {-1.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, -1000.0, 1000.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 1.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(RootNearZeroDerivative)
{
    // p(x) = (x-1)^2 * (x+1) = x^3 - x^2 - x + 1
    // Root at x=1 where derivative is also zero (double root)
    // Single root at x=-1
    std::vector<double> coeffs = {1.0, -1.0, -1.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 200);

    auto result = finder.findRoot(coeffs, -2.0, 0.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, -1.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(VerySmallRoot)
{
    // p(x) = x - 1e-8
    std::vector<double> coeffs = {-1e-8, 1.0};
    PolynomialRootFinder<> finder(1e-15);

    auto result = finder.findRoot(coeffs, -1.0, 1.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 1e-8, 1e-6);
}

BOOST_AUTO_TEST_CASE(LargeCoefficients)
{
    // p(x) = 1e10 * (x - 5) = -5e10 + 1e10 * x
    std::vector<double> coeffs = {-5e10, 1e10};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 10.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 5.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(WilkinsonPolynomialRoot)
{
    // Wilkinson's polynomial: prod(x-i) for i=1..5
    // = x^5 - 15x^4 + 85x^3 - 225x^2 + 274x - 120
    std::vector<double> coeffs = {-120.0, 274.0, -225.0, 85.0, -15.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto r1 = finder.findRoot(coeffs, 0.5, 1.5);
    auto r3 = finder.findRoot(coeffs, 2.5, 3.5);
    auto r5 = finder.findRoot(coeffs, 4.5, 5.5);

    BOOST_CHECK(r1.converged());
    BOOST_CHECK(r3.converged());
    BOOST_CHECK(r5.converged());
    BOOST_CHECK_CLOSE(r1.root, 1.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(r3.root, 3.0, LOOSE_TOL);
    BOOST_CHECK_CLOSE(r5.root, 5.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Multiple Root Tests (even multiplicity - no sign change)
// ============================================================================

BOOST_AUTO_TEST_SUITE(MultipleRootTests)

BOOST_AUTO_TEST_CASE(DoubleRootQuadratic)
{
    // p(x) = (x-2)^2 = x^2 - 4x + 4, double root at x = 2
    std::vector<double> coeffs = {4.0, -4.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 2.0, 1e-6);
}

BOOST_AUTO_TEST_CASE(DoubleRootAtOrigin)
{
    // p(x) = x^2, double root at x = 0
    std::vector<double> coeffs = {0.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, -1.0, 1.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_SMALL(result.root, 1e-6);
}

BOOST_AUTO_TEST_CASE(TripleRoot)
{
    // p(x) = (x-1)^3 = x^3 - 3x^2 + 3x - 1, triple root at x = 1
    // Has sign change, so should work with standard method
    std::vector<double> coeffs = {-1.0, 3.0, -3.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 200);

    auto result = finder.findRoot(coeffs, 0.0, 3.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 1.0, 1e-4);
}

BOOST_AUTO_TEST_CASE(QuadrupleRoot)
{
    // p(x) = (x-3)^4, quadruple root at x = 3 (even multiplicity, no sign change)
    // = x^4 - 12x^3 + 54x^2 - 108x + 81
    std::vector<double> coeffs = {81.0, -108.0, 54.0, -12.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 6.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 3.0, 1e-4);
}

BOOST_AUTO_TEST_CASE(MixedMultiplicity)
{
    // p(x) = (x-1)^2 * (x-3) = x^3 - 5x^2 + 7x - 3
    // Double root at 1, simple root at 3
    std::vector<double> coeffs = {-3.0, 7.0, -5.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    // Find the double root at x=1 (no sign change in [0, 2])
    auto r1 = finder.findRoot(coeffs, 0.0, 2.0);
    BOOST_CHECK(r1.converged());
    BOOST_CHECK_CLOSE(r1.root, 1.0, 1e-4);

    // Find simple root at x=3 (has sign change)
    auto r3 = finder.findRoot(coeffs, 2.0, 4.0);
    BOOST_CHECK(r3.converged());
    BOOST_CHECK_CLOSE(r3.root, 3.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(DoubleRootNegative)
{
    // p(x) = (x+2)^2 = x^2 + 4x + 4, double root at x = -2
    std::vector<double> coeffs = {4.0, 4.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, -5.0, 0.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, -2.0, 1e-6);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Error Handling / Status Tests
// ============================================================================

BOOST_AUTO_TEST_SUITE(ErrorHandlingTests)

BOOST_AUTO_TEST_CASE(EmptyCoefficients)
{
    std::vector<double> coeffs;
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 1.0);
    BOOST_CHECK_EQUAL(static_cast<int>(result.status), static_cast<int>(RootStatus::EmptyPolynomial));
    BOOST_CHECK(!result.converged());
}

BOOST_AUTO_TEST_CASE(InvalidInterval)
{
    std::vector<double> coeffs = {-1.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    // lo > hi
    auto result1 = finder.findRoot(coeffs, 5.0, 3.0);
    BOOST_CHECK_EQUAL(static_cast<int>(result1.status), static_cast<int>(RootStatus::InvalidInterval));
    BOOST_CHECK(!result1.converged());

    // lo == hi
    auto result2 = finder.findRoot(coeffs, 3.0, 3.0);
    BOOST_CHECK_EQUAL(static_cast<int>(result2.status), static_cast<int>(RootStatus::InvalidInterval));
    BOOST_CHECK(!result2.converged());
}

BOOST_AUTO_TEST_CASE(NoRealRootInInterval)
{
    // p(x) = x^2 + 1, no real roots (complex: ±i)
    std::vector<double> coeffs = {1.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, -10.0, 10.0);
    BOOST_CHECK_EQUAL(static_cast<int>(result.status), static_cast<int>(RootStatus::NoRealRoot));
    BOOST_CHECK(result.noRealRoot());
    BOOST_CHECK(!result.converged());
}

BOOST_AUTO_TEST_CASE(NoRealRootQuartic)
{
    // p(x) = x^4 + x^2 + 1, no real roots
    std::vector<double> coeffs = {1.0, 0.0, 1.0, 0.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, -100.0, 100.0);
    BOOST_CHECK(result.noRealRoot());
    BOOST_CHECK(!result.converged());
}

BOOST_AUTO_TEST_CASE(RealRootOutsideInterval)
{
    // p(x) = x - 10, root at x = 10, but interval [0, 5] doesn't contain it
    std::vector<double> coeffs = {-10.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 5.0);
    BOOST_CHECK(result.noRealRoot());  // No sign change in interval
    BOOST_CHECK(!result.converged());
}

BOOST_AUTO_TEST_CASE(InvalidTolerance)
{
    BOOST_CHECK_THROW(PolynomialRootFinder<>(0.0), std::invalid_argument);
    BOOST_CHECK_THROW(PolynomialRootFinder<>(-1e-10), std::invalid_argument);
}

BOOST_AUTO_TEST_CASE(ZeroMaxIterations)
{
    // With 0 max iterations, should immediately return MaxIterationsExceeded
    std::vector<double> coeffs = {-1.0, 1.0};  // x - 1
    PolynomialRootFinder<> finder(TOLERANCE, 0);

    auto result = finder.findRoot(coeffs, 0.0, 2.0);

    BOOST_CHECK(!result.converged());
    BOOST_CHECK_EQUAL(static_cast<int>(result.status),
                      static_cast<int>(RootStatus::MaxIterationsExceeded));
    BOOST_CHECK_EQUAL(result.iterations, 0u);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Uniqueness Requirement Tests
// ============================================================================

BOOST_AUTO_TEST_SUITE(UniquenessTests)

BOOST_AUTO_TEST_CASE(UniqueRootPasses)
{
    // p(x) = x - 2, single root at x = 2
    std::vector<double> coeffs = {-2.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 100, true);  // requireUniqueRoot = true

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 2.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(MultipleRootsDetected)
{
    // p(x) = (x-1)(x-3) = x^2 - 4x + 3, roots at x = 1 and x = 3
    std::vector<double> coeffs = {3.0, -4.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 100, true);  // requireUniqueRoot = true

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    BOOST_CHECK(!result.converged());
    BOOST_CHECK(result.multipleRoots());
    BOOST_CHECK_EQUAL(static_cast<int>(result.status),
                      static_cast<int>(RootStatus::MultipleRootsInInterval));
}

BOOST_AUTO_TEST_CASE(MultipleRootsAllowedByDefault)
{
    // p(x) = (x-1)(x-3) = x^2 - 4x + 3, roots at x = 1 and x = 3
    std::vector<double> coeffs = {3.0, -4.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);  // requireUniqueRoot = false (default)

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    // Should succeed and return one of the roots
    BOOST_CHECK(result.converged());
    BOOST_CHECK(!result.multipleRoots());
    // Root should be either 1 or 3
    bool isRoot1 = std::abs(result.root - 1.0) < 0.1;
    bool isRoot3 = std::abs(result.root - 3.0) < 0.1;
    BOOST_CHECK(isRoot1 || isRoot3);
}

BOOST_AUTO_TEST_CASE(ThreeRootsDetected)
{
    // p(x) = (x-1)(x-2)(x-3) = x^3 - 6x^2 + 11x - 6
    std::vector<double> coeffs = {-6.0, 11.0, -6.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 100, true);

    auto result = finder.findRoot(coeffs, 0.0, 4.0);

    BOOST_CHECK(!result.converged());
    BOOST_CHECK(result.multipleRoots());
}

BOOST_AUTO_TEST_CASE(DoubleRootHasMultiplicity)
{
    // p(x) = (x-2)^2, double root at x = 2 (multiplicity = 2)
    std::vector<double> coeffs = {4.0, -4.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 100, true);

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    // A double root has multiplicity > 1, so should fail uniqueness check
    BOOST_CHECK(!result.converged());
    BOOST_CHECK(result.hasMultiplicity());
    BOOST_CHECK_EQUAL(static_cast<int>(result.status),
                      static_cast<int>(RootStatus::RootHasMultiplicity));
    // Should still report the root location
    BOOST_CHECK_CLOSE(result.root, 2.0, 1e-4);
}

BOOST_AUTO_TEST_CASE(TripleRootHasMultiplicity)
{
    // p(x) = (x-1)^3 = x^3 - 3x^2 + 3x - 1, triple root at x = 1
    // Has sign change but still has multiplicity > 1
    std::vector<double> coeffs = {-1.0, 3.0, -3.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 100, true);

    auto result = finder.findRoot(coeffs, 0.0, 3.0);

    BOOST_CHECK(!result.converged());
    BOOST_CHECK(result.hasMultiplicity());
    BOOST_CHECK_CLOSE(result.root, 1.0, 1e-3);
}

BOOST_AUTO_TEST_CASE(DoubleRootAllowedByDefault)
{
    // p(x) = (x-2)^2, double root at x = 2
    std::vector<double> coeffs = {4.0, -4.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE);  // requireUniqueRoot = false (default)

    auto result = finder.findRoot(coeffs, 0.0, 5.0);

    // Should succeed when uniqueness not required
    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 2.0, 1e-4);
}

BOOST_AUTO_TEST_CASE(RootAtEndpointWithMultipleRoots)
{
    // p(x) = x(x-2) = x^2 - 2x, roots at x = 0 and x = 2
    std::vector<double> coeffs = {0.0, -2.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 100, true);

    auto result = finder.findRoot(coeffs, 0.0, 3.0);

    BOOST_CHECK(!result.converged());
    BOOST_CHECK(result.multipleRoots());
}

BOOST_AUTO_TEST_CASE(NarrowIntervalSingleRoot)
{
    // p(x) = (x-1)(x-3), but interval only contains one root
    std::vector<double> coeffs = {3.0, -4.0, 1.0};
    PolynomialRootFinder<> finder(TOLERANCE, 100, true);

    // Narrow interval around x = 1 only
    auto result = finder.findRoot(coeffs, 0.5, 1.5);

    BOOST_CHECK(result.converged());
    BOOST_CHECK(!result.multipleRoots());
    BOOST_CHECK_CLOSE(result.root, 1.0, LOOSE_TOL);
}

BOOST_AUTO_TEST_CASE(RequireUniqueRootAccessor)
{
    PolynomialRootFinder<> finderDefault;
    BOOST_CHECK(!finderDefault.requireUniqueRoot());

    PolynomialRootFinder<> finderTrue(1e-12, 100, true);
    BOOST_CHECK(finderTrue.requireUniqueRoot());

    PolynomialRootFinder<> finderFalse(1e-12, 100, false);
    BOOST_CHECK(!finderFalse.requireUniqueRoot());
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Float Type Tests
// ============================================================================

BOOST_AUTO_TEST_SUITE(FloatTypeTests)

BOOST_AUTO_TEST_CASE(SinglePrecision)
{
    // p(x) = x - 2
    std::vector<float> coeffs = {-2.0f, 1.0f};
    PolynomialRootFinder<float> finder(1e-6f);

    auto result = finder.findRoot(coeffs, 0.0f, 5.0f);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, 2.0f, 1e-4f);
}

BOOST_AUTO_TEST_CASE(LongDouble)
{
    // p(x) = x - pi
    std::vector<long double> coeffs = {-std::numbers::pi_v<long double>, 1.0L};
    PolynomialRootFinder<long double> finder(1e-15L);

    auto result = finder.findRoot(coeffs, 3.0L, 4.0L);

    BOOST_CHECK(result.converged());
    BOOST_CHECK_CLOSE(result.root, std::numbers::pi_v<long double>, 1e-12L);
}

BOOST_AUTO_TEST_SUITE_END()

// ============================================================================
// Convergence Behavior
// ============================================================================

BOOST_AUTO_TEST_SUITE(ConvergenceTests)

BOOST_AUTO_TEST_CASE(NewtonConvergesQuadratically)
{
    // For well-behaved polynomial, Newton should converge quickly
    std::vector<double> coeffs = {-1.0, 1.0};  // x - 1
    PolynomialRootFinder<> finder(TOLERANCE);

    auto result = finder.findRoot(coeffs, 0.0, 10.0);

    BOOST_CHECK(result.converged());
    // Should converge in very few iterations for linear
    BOOST_CHECK_LT(result.iterations, 10u);
}

BOOST_AUTO_TEST_CASE(MaxIterationsReached)
{
    // Force many iterations with very tight tolerance and limited iterations
    std::vector<double> coeffs = {-2.0, 0.0, 1.0};  // x^2 - 2
    PolynomialRootFinder<> finder(1e-50, 3);  // Impossibly tight tol, 3 iters

    auto result = finder.findRoot(coeffs, 1.0, 2.0);

    BOOST_CHECK(!result.converged());
    BOOST_CHECK_EQUAL(static_cast<int>(result.status), static_cast<int>(RootStatus::MaxIterationsExceeded));
    BOOST_CHECK_EQUAL(result.iterations, 3u);
    // Should still be close to root
    BOOST_CHECK_CLOSE(result.root, std::sqrt(2.0), 0.1);
}

BOOST_AUTO_TEST_SUITE_END()
