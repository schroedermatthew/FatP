---
doc_id: CG-POLYROOT-001
doc_type: "Companion Guide"
title: "Hybrid Bisection-Newton Polynomial Root Finding"
fatp_components: ["PolynomialRootFinder"]
topics: ["root finding", "Newton-Raphson", "bisection method", "polynomial evaluation", "Horner's method", "numerical stability", "multiple roots", "hybrid algorithms"]
constraints: ["derivative near zero", "bracket maintenance", "even multiplicity roots", "floating-point tolerance", "convergence guarantees"]
cxx_standard: "C++17"
std_equivalent: null
boost_equivalent: "Boost.Math root finding utilities"
last_verified: "2025-02-04"
audience: ["C++ developers", "numerical computing engineers", "AI assistants"]
status: "reviewed"
---

# Companion Guide - Hybrid Bisection-Newton Polynomial Root Finding

## Scope

This guide explains the design and implementation of `PolynomialRootFinder`, a hybrid algorithm that combines Newton-Raphson's quadratic convergence with bisection's guaranteed convergence. The focus is on **why** the algorithm makes specific decisions—when to trust Newton, when to fall back to bisection, and how to detect roots with even multiplicity that produce no sign change.

## Not covered

- General nonlinear root finding (arbitrary functions, not just polynomials)
- Complex root extraction (Durand-Kerner, Aberth, companion matrix methods)
- Polynomial deflation for finding all roots
- Interval arithmetic and verified computing
- Arbitrary-precision arithmetic

## Prerequisites

- Basic calculus: derivatives, tangent lines, fixed-point iteration
- Familiarity with floating-point representation and epsilon comparisons
- Understanding of algorithmic complexity (O(1), O(log n), O(n))

## Companion Guide Card

**Component:** PolynomialRootFinder  
**Design question:** How do we combine Newton's speed with bisection's reliability?  
**Key tradeoff:** Convergence rate vs. guaranteed termination  
**Decision made:** Newton-Raphson with bracket-constrained fallback to bisection  
**Rejected alternatives:** Pure Newton (can diverge), pure bisection (slow), Brent's method (more complex, similar performance for polynomials)  
**Historical context:** Hybrid methods became standard after numerical analysts observed Newton's sensitivity to initial guess and derivative magnitude in the 1960s-70s

---

## Table of Contents

- [Part I — The Problems](#part-i--the-problems)
  - [Chapter 1: The Newton Divergence Trap](#chapter-1-the-newton-divergence-trap)
  - [Chapter 2: The Bisection Crawl](#chapter-2-the-bisection-crawl)
  - [Chapter 3: The Invisible Root](#chapter-3-the-invisible-root)
- [Part II — The Solutions](#part-ii--the-solutions)
  - [Chapter 4: The Hybrid Strategy](#chapter-4-the-hybrid-strategy)
  - [Chapter 5: Bracket-Constrained Newton](#chapter-5-bracket-constrained-newton)
  - [Chapter 6: Multiple Root Detection](#chapter-6-multiple-root-detection)
- [Part III — Case Studies](#part-iii--case-studies)
  - [Case Study: The Wilkinson Polynomial](#case-study-the-wilkinson-polynomial)
  - [Case Study: The Double Root](#case-study-the-double-root)
- [Part IV — Foundations](#part-iv--foundations)
  - [Horner's Method](#horners-method)
  - [Convergence Analysis](#convergence-analysis)
  - [Design Rationale](#design-rationale)
  - [Rejected Alternatives](#rejected-alternatives)
  - [Guarantees and Non-Guarantees](#guarantees-and-non-guarantees)
- [Design Rules to Internalize](#design-rules-to-internalize)
- [What To Do Now](#what-to-do-now)

---

## Part I — The Problems

### Chapter 1: The Newton Divergence Trap

**The obvious approach:** Newton-Raphson iteration converges quadratically—the number of correct digits approximately doubles each iteration. For a polynomial p(x) with derivative p'(x), iterate:

```cpp
// THE TRAP: Newton-Raphson without safeguards
x_next = x - p(x) / p_prime(x);  // Quadratic convergence... when it works
```

This looks ideal. Starting from x₀ = 1.5 to find √2 (root of x² - 2), Newton converges in about 4 iterations to machine precision.

**The hidden constraint:** Newton-Raphson assumes the derivative is "well-behaved" near the root. When |p'(x)| is small, the step size p(x)/p'(x) becomes enormous. The iteration can overshoot the root entirely, landing far outside any reasonable search region. Worse, if the derivative happens to be zero, the method divides by zero.

Consider p(x) = x³ - 2x + 2 with initial guess x₀ = 0. The derivative p'(0) = -2 gives a Newton step of 2/(-2) = -1, landing at x₁ = 1. From there, p'(1) = 1, giving step 1/1 = 1, landing at x₂ = 0. The iteration cycles forever between 0 and 1, never approaching the actual root near x ≈ -1.77.

**The symptoms:** The iteration oscillates, diverges to infinity, or converges to the wrong root entirely. No error is raised—the algorithm simply returns garbage after exhausting its iteration budget.

**The cost:** Silent wrong answers in numerical pipelines. In trajectory optimization, this means physically impossible solutions. In financial modeling, this means mispriced derivatives.

**What FAT-P provides:** The hybrid algorithm maintains a bracket [lo, hi] that always contains the root. Newton steps are accepted only if they stay within the bracket. If Newton misbehaves, bisection takes over.

Part IV explains the mathematical conditions under which Newton is guaranteed to converge.

---

### Chapter 2: The Bisection Crawl

**The obvious approach:** If Newton is unreliable, use bisection. Given an interval [lo, hi] where p(lo) and p(hi) have opposite signs, the Intermediate Value Theorem guarantees a root exists. Repeatedly halve the interval:

```cpp
// THE TRAP: Bisection is reliable but slow
while (hi - lo > tolerance)
{
    T mid = (lo + hi) / 2;
    if (p(mid) * p(lo) < 0)
        hi = mid;
    else
        lo = mid;
}  // Gains exactly 1 bit per iteration
```

This always converges. The interval shrinks by half each iteration, so after k iterations the interval width is (hi₀ - lo₀) / 2^k.

**The hidden constraint:** Bisection's convergence is *linear*—each iteration gains exactly one bit of precision. To achieve 52 bits of precision (double's mantissa), bisection needs 52 iterations minimum. For a polynomial where Newton would converge in 5-6 iterations, this is a 10x slowdown.

**The symptoms:** Correct answers, but unacceptable latency. In real-time control systems or tight inner loops, this overhead is prohibitive.

**The cost:** For a polynomial root finder called millions of times (e.g., in a ray-tracer computing ray-surface intersections), the difference between 6 iterations and 52 iterations is the difference between interactive framerates and unwatchable slideshow.

**What FAT-P provides:** The hybrid algorithm uses bisection only as a fallback. When Newton is well-behaved (most iterations), we get quadratic convergence. When Newton misbehaves (occasional iterations), we get guaranteed progress via bisection.

Part IV quantifies the expected iteration count for typical polynomials.

---

### Chapter 3: The Invisible Root

**The obvious approach:** Both Newton and bisection rely on detecting a sign change. If p(lo) < 0 and p(hi) > 0, a root exists in [lo, hi]. Search within this bracket.

```cpp
// THE TRAP: Assumes sign change exists
if (p(lo) * p(hi) > 0)
    throw std::invalid_argument("No root in interval");  // Is this always true?
```

**The hidden constraint:** A polynomial can have a real root with *no sign change*. Consider p(x) = (x - 2)². This has a double root at x = 2, but p(x) ≥ 0 everywhere. The function touches zero without crossing it. The bracket-based approach sees p(1) = 1 > 0 and p(3) = 1 > 0, concludes "no sign change," and throws an error—despite a perfectly good real root sitting at x = 2.

Any root with even multiplicity exhibits this behavior: (x - r)², (x - r)⁴, etc. These are real roots that are algebraically valid and often physically meaningful (e.g., a tangent intersection point).

**The symptoms:** False negatives. The algorithm reports "no root" when a root exists. The user either gives up or manually searches for the root by other means.

**The cost:** Incorrect results in polynomial systems. If you're finding eigenvalues via characteristic polynomials, repeated eigenvalues (corresponding to double roots) are silently missed.

**What FAT-P provides:** When no sign change is detected, the algorithm searches for critical points where p'(x) = 0. At these points, if p(x) ≈ 0, we have a multiple root. The algorithm samples the interval, identifies minima of |p(x)|, and refines using Newton iteration.

Part IV explains the mathematical basis for detecting even-multiplicity roots.

---

## Part II — The Solutions

### Chapter 4: The Hybrid Strategy

Chapter 1 showed that Newton diverges when the derivative is small or the step overshoots. Chapter 2 showed that bisection is reliable but slow. The hybrid strategy combines both: use Newton when it's well-behaved, fall back to bisection when it's not.

The key insight is that we can *detect* when Newton misbehaves by checking whether its proposed step stays within the current bracket. If Newton proposes x_new and x_new ∉ (lo, hi), something has gone wrong—either the derivative was too small, or we overshot. In either case, bisection makes safe progress.

The mechanism works as follows. We maintain a bracket [lo, hi] that always contains the root, with the invariant p(lo) < 0 < p(hi) (swapping if necessary). Each iteration:

1. Compute Newton step: x_new = x - p(x) / p'(x)
2. If x_new ∈ (lo, hi) and the step is "reasonable," accept Newton
3. Otherwise, take bisection step: x_new = (lo + hi) / 2
4. Update bracket based on sign of p(x_new)

The "reasonable" check prevents Newton from making negligible progress when it's technically valid but essentially stuck. If the Newton step is less than 0.01% of the bracket width, we're better off bisecting.

| Guarantee | Provided | Notes |
|-----------|----------|-------|
| Termination | Yes | Bracket shrinks by ≥50% if bisection; often much more with Newton |
| Correct root | Yes | Final x is within tolerance of true root |
| Quadratic convergence | No | Only when Newton steps dominate; linear worst-case |

**Where it loses:** If the polynomial has extremely ill-conditioned roots (e.g., Wilkinson's polynomial at high degree), Newton may rarely be accepted, degrading to pure bisection performance.

---

### Chapter 5: Bracket-Constrained Newton

Chapter 4 described the hybrid strategy at a high level. This chapter details the bracket maintenance invariant that makes it work.

The fundamental requirement is that we always know the root lies in [lo, hi]. This requires p(lo) and p(hi) to have opposite signs. Rather than checking signs repeatedly, we normalize once at the start: if p(lo) > 0, swap lo and hi so that p(lo) < 0 < p(hi) always.

Now bracket updates are trivial. After computing p(x_new):
- If p(x_new) < 0, the root is in [x_new, hi], so set lo = x_new
- If p(x_new) > 0, the root is in [lo, x_new], so set hi = x_new
- If p(x_new) ≈ 0, we've found the root

This invariant is the source of guaranteed convergence. Even if Newton proposes garbage, we always make progress by shrinking the bracket. The worst case is bisection's linear convergence; the common case is Newton's quadratic convergence.

The implementation requires care with the derivative check. We accept Newton only when |p'(x)| > ε, where ε is machine epsilon. Division by values smaller than this produces results dominated by floating-point noise.

```cpp
// THE FIX: Bracket-constrained Newton with fallback
bool useNewton = false;
if (std::abs(df) > std::numeric_limits<T>::epsilon())
{
    T newtonStep = f / df;
    T xNew = x - newtonStep;
    
    // Accept Newton only if it stays in bracket and makes progress
    if (xNew > lo && xNew < hi)
    {
        T bracketSize = hi - lo;
        if (std::abs(newtonStep) > bracketSize * 1e-4)  // Not stalled
            useNewton = true;
    }
}
if (!useNewton)
    xNew = (lo + hi) / 2;  // Bisection fallback
```

| Guarantee | Provided | Notes |
|-----------|----------|-------|
| No division by zero | Yes | Derivative magnitude checked before division |
| Bracket maintained | Yes | Every iteration shrinks [lo, hi] |
| Newton never escapes | Yes | Out-of-bracket proposals rejected |

**Where it loses:** For polynomials with roots very close together, the bracket may contain multiple roots. The algorithm finds one of them, not necessarily the closest to the initial midpoint.

---

### Chapter 6: Multiple Root Detection

Chapter 3 showed that even-multiplicity roots produce no sign change, causing standard bracketing to fail. This chapter explains how PolynomialRootFinder detects and refines these roots.

The key observation is that a multiple root r of p(x) is also a root of p'(x). More precisely, if p(x) = (x - r)^m * q(x) where q(r) ≠ 0, then p'(x) = m(x - r)^(m-1) * q(x) + (x - r)^m * q'(x), which has r as a root of multiplicity m-1.

This means multiple roots are critical points of p(x). To find them:

1. Sample the interval to locate where |p(x)| is minimized
2. If the minimum is significantly lower than the endpoints, a root may exist there
3. Refine using Newton iteration on p(x), accepting convergence even if slow

The sampling uses 20 equally-spaced points. This is sufficient to identify approximate root locations for polynomials up to degree ~15 without excessive cost. For higher degrees, the sampling could miss roots between sample points, but such cases are rare in practice.

Newton iteration on multiple roots converges linearly rather than quadratically—the multiplicity m reduces the convergence order. Modified Newton methods (dividing by m or using p/p' recursively) can restore quadratic convergence, but require knowing m in advance. Our implementation accepts linear convergence as acceptable for the multiple-root fallback path.

```cpp
// THE FIX: Detect multiple roots via critical point search
// Sample to find minimum |p(x)|
T bestX = lo, bestF = std::abs(evaluate(coeffs, lo));
T step = (hi - lo) / 20;
for (std::size_t i = 0; i <= 20; ++i)
{
    T x = lo + i * step;
    T absF = std::abs(evaluate(coeffs, x));
    if (absF < bestF)
    {
        bestF = absF;
        bestX = x;
    }
}
// Refine with Newton if promising
if (bestF < endpointMinimum)
    // Newton iteration from bestX...
```

| Guarantee | Provided | Notes |
|-----------|----------|-------|
| Detects double roots | Yes | Sampling + refinement finds (x-r)² |
| Detects all multiplicities | Yes | Works for (x-r)^m for any even m |
| Distinguishes complex from multiple | Yes | Complex roots have |p(x)| > 0 everywhere; multiple roots have |p(x)| ≈ 0 at critical point |

**Where it loses:** If two distinct real roots are separated by less than the sampling interval, they may both be "seen" as a single minimum and only one will be returned. This is a fundamental limitation of the bracketing approach.

---

## Part III — Case Studies

### Case Study: The Wilkinson Polynomial

**Context:** Wilkinson's polynomial is the product (x-1)(x-2)...(x-20), expanded into standard form. Despite having simple integer roots, the expanded coefficients are large and alternating, making the polynomial notoriously ill-conditioned.

**Initial approach:** A pure Newton implementation starting from x₀ = 15.5 to find the root at 15.

```cpp
// THE TRAP: Pure Newton on Wilkinson polynomial
std::vector<double> wilkinson = computeWilkinsonCoeffs(20);
double x = 15.5;
for (int i = 0; i < 100; ++i)
{
    auto [f, df] = evaluateWithDerivative(wilkinson, x);
    x = x - f / df;  // Diverges due to ill-conditioning
}
```

**Symptoms:** The iteration oscillates wildly, producing values like x = 14.2, then x = 16.8, then x = 13.1. After 100 iterations, the result is nowhere near any root.

**The Fix:** Using PolynomialRootFinder with a bracket [14.5, 15.5]:

```cpp
// THE FIX: Hybrid method with bracket
PolynomialRootFinder<> finder(1e-12);
auto result = finder.findRoot(wilkinson, 14.5, 15.5);
// result.root ≈ 15.0, result.iterations ≈ 8
```

**Results:**

| Metric | Pure Newton | Hybrid |
|--------|-------------|--------|
| Converged | No | Yes |
| Iterations | 100 (limit) | 8 |
| Final error | ~2.3 | < 1e-12 |

**Components Used:**
- `PolynomialRootFinder` — Main solver
- `evaluateWithDerivative` — Simultaneous f and f' via Horner

**Transferable Lessons:** Ill-conditioned problems expose Newton's fragility. The hybrid approach succeeds because bisection provides guaranteed progress even when Newton's proposals are rejected. For degree-20 Wilkinson, approximately 40% of iterations used bisection fallback.

---

### Case Study: The Double Root

**Context:** A quadratic (x - 3)² arising from a trajectory optimization problem. The root represents a tangent point where two curves touch but don't cross.

**Initial approach:** Standard sign-change bracket detection.

```cpp
// THE TRAP: Assume sign change implies root existence
std::vector<double> coeffs = {9.0, -6.0, 1.0};  // (x-3)^2 = x^2 - 6x + 9
double fLo = evaluate(coeffs, 0.0);   // 9 > 0
double fHi = evaluate(coeffs, 5.0);   // 4 > 0
if (fLo * fHi > 0)
    throw std::invalid_argument("No root");  // Wrong! Root at x=3 exists
```

**Symptoms:** The algorithm throws an exception despite a valid real root at x = 3.

**The Fix:** Using PolynomialRootFinder which detects even-multiplicity roots:

```cpp
// THE FIX: Multiple root detection
PolynomialRootFinder<> finder(1e-12);
auto result = finder.findRoot(coeffs, 0.0, 5.0);
// result.converged() == true
// result.root ≈ 3.0
```

**Results:**

| Metric | Sign-change only | With multiple root detection |
|--------|------------------|------------------------------|
| Detected root | No | Yes |
| Status | Exception thrown | RootStatus::Converged |
| Root value | N/A | 3.0 ± 1e-10 |

**Components Used:**
- `PolynomialRootFinder` — Main solver with multiple-root path
- `derivativeCoefficients` — Computes p'(x) for critical point analysis

**Transferable Lessons:** Any system dealing with polynomials must account for repeated roots. Physical systems often produce them: repeated eigenvalues in vibration analysis, tangent intersections in geometry, optimal control problems with active constraints.

---

## Part IV — Foundations

### Horner's Method

Polynomial evaluation is the inner loop of root finding. Naïve evaluation of a₀ + a₁x + a₂x² + ... + aₙxⁿ requires computing powers of x separately, leading to O(n²) multiplications and potential overflow in intermediate powers.

Horner's method rewrites the polynomial as:

  a₀ + x(a₁ + x(a₂ + ... + x(aₙ₋₁ + x·aₙ)...))

This computes in O(n) multiplications with no intermediate power computation. The algorithm processes coefficients from highest to lowest degree:

```cpp
// Horner's method: O(n) multiplications, O(1) extra space
T result = coeffs.back();  // a_n
for (auto it = coeffs.rbegin() + 1; it != coeffs.rend(); ++it)
    result = result * x + *it;  // result = result * x + a_i
return result;
```

Simultaneous evaluation of p(x) and p'(x) uses a related recurrence. If we track both the polynomial value and its derivative during the Horner iteration:

```cpp
T f = coeffs.back();
T df = 0;
for (auto it = coeffs.rbegin() + 1; it != coeffs.rend(); ++it)
{
    df = df * x + f;      // Derivative accumulator
    f = f * x + *it;       // Function accumulator
}
return {f, df};
```

This computes both values in a single pass with 2n multiplications and 2n additions—the same cost as evaluating p(x) alone with the naïve approach.

### Convergence Analysis

**Newton-Raphson convergence:** For a simple root r (where p(r) = 0 and p'(r) ≠ 0), Newton-Raphson converges quadratically when sufficiently close to r. Specifically, if eₖ = |xₖ - r| is the error at iteration k, then:

  eₖ₊₁ ≤ C · eₖ²

for some constant C depending on p''(r) / p'(r). This means errors like 0.1, 0.01, 0.0001, 0.00000001—the decimal places approximately double each iteration.

**Bisection convergence:** Bisection converges linearly. Each iteration halves the bracket:

  eₖ₊₁ ≤ 0.5 · eₖ

This guarantees progress but is much slower: errors like 0.5, 0.25, 0.125, 0.0625, etc.

**Hybrid convergence:** The hybrid method achieves Newton's quadratic rate when Newton steps are accepted, and falls back to bisection's linear rate otherwise. For well-behaved polynomials, Newton dominates and total iterations are O(log log(1/ε)). For ill-conditioned polynomials, bisection may dominate and total iterations are O(log(1/ε)).

**Multiple root convergence:** For a root of multiplicity m, Newton converges only linearly with rate (m-1)/m. A double root (m=2) converges at rate 0.5—identical to bisection. Modified Newton methods can restore quadratic convergence but require knowing m.

### Design Rationale

**Why not pure Newton?** Newton fails silently on ill-conditioned problems. A library function cannot assume the user's polynomial is well-behaved.

**Why not Brent's method?** Brent's method combines bisection, secant, and inverse quadratic interpolation with sophisticated switching logic. It's excellent for general nonlinear functions but overkill for polynomials where we have exact derivative computation. The added complexity provides no benefit when p'(x) is available analytically via Horner.

**Why detect multiple roots at all?** Returning `NoRealRoot` for (x-3)² would be mathematically incorrect. Users expect to find real roots regardless of multiplicity. The sampling-based detection adds minimal overhead (20 function evaluations) only when the primary bracketing approach fails.

**Why 20 samples?** Empirically, 20 samples reliably detect roots for polynomials up to degree 15. Higher degrees may require more samples, but degree-15+ polynomials are rare in practice, and users needing them can adjust tolerance or preprocess to identify approximate root locations.

### Rejected Alternatives

**Deflation for multiple roots:** After finding one root r, divide out (x - r) and continue. This is standard for finding all roots but introduces numerical error in the deflated polynomial. Rejected because PolynomialRootFinder finds one root in an interval, not all roots.

**Sturm sequence for root counting:** Sturm's theorem counts roots in an interval without finding them. Could be used to validate that the interval contains exactly one root. Rejected due to implementation complexity and because the hybrid method handles multi-root intervals acceptably (finds one root).

**Arbitrary precision:** Using MPFR or similar for exact arithmetic would eliminate floating-point concerns. Rejected because the performance overhead is 100-1000x, and double precision suffices for nearly all applications.

### Guarantees and Non-Guarantees

| Guarantee | Provided | Mechanism |
|-----------|----------|-----------|
| Termination | Yes | Bracket shrinks every iteration |
| Correct root when converged | Yes | Final bracket width < tolerance |
| Multiple root detection | Yes | Critical point sampling + refinement |
| No division by zero | Yes | Derivative magnitude check |
| Distinct status for no-root | Yes | RootStatus::NoRealRoot when no root found |
| Multiplicity detection | Yes | Checks p'(r) ≈ 0 when requireUniqueRoot enabled |
| Multiple distinct roots detection | Yes | Checks remaining sub-intervals when requireUniqueRoot enabled |

| Non-Guarantee | Why |
|---------------|-----|
| Finds all roots | Single-root algorithm; use deflation externally |
| Specific root when multiple exist | Returns one root in interval; which one is unspecified (use `requireUniqueRoot` to detect) |
| Quadratic convergence | Falls back to linear (bisection) when Newton rejected |
| Works for non-polynomials | Requires coefficient-based Horner evaluation |

### The Uniqueness Flag

By default, if the interval contains multiple roots or a root with multiplicity > 1, PolynomialRootFinder returns the root without error. This matches typical use cases where any root suffices.

When `requireUniqueRoot = true` is passed to the constructor, the algorithm enforces that:

1. **Exactly one root** exists in the interval (no other distinct root locations)
2. **Multiplicity = 1** (a simple root where p'(r) ≠ 0)

If either condition fails, the algorithm returns an error status:

- `RootStatus::MultipleRootsInInterval` — more than one distinct root location
- `RootStatus::RootHasMultiplicity` — root has multiplicity > 1 (p(r) ≈ 0 and p'(r) ≈ 0)

Detection works by:

1. After finding a root r, checking if p'(r) ≈ 0 (indicates multiplicity > 1)
2. Checking for sign changes in [lo, r-ε] and [r+ε, hi] (indicates other roots)
3. Sampling both sub-intervals for potential even-multiplicity roots

This adds overhead proportional to the interval width but guarantees the caller knows when the result is ambiguous or degenerate.

```cpp
// Default: accepts multiple roots and multiplicity > 1
PolynomialRootFinder<> finderDefault;
auto r1 = finderDefault.findRoot(doubleRoot, 0.0, 5.0);
// r1.converged() == true

// Strict: error if multiple roots OR multiplicity > 1
PolynomialRootFinder<> finderStrict(1e-12, 100, true);
auto r2 = finderStrict.findRoot(doubleRoot, 0.0, 5.0);
// r2.hasMultiplicity() == true, r2.converged() == false

auto r3 = finderStrict.findRoot(twoDistinctRoots, 0.0, 5.0);
// r3.multipleRoots() == true, r3.converged() == false
```

---

## Design Rules to Internalize

1. **Never trust Newton alone.** Quadratic convergence is contingent on good behavior; always have a fallback.

2. **Brackets are invariants.** If you maintain [lo, hi] such that the root is always inside, convergence is guaranteed.

3. **Sign change ≠ root existence.** Even-multiplicity roots produce no sign change. Check for critical points when bracketing fails.

4. **Compute f and f' together.** Horner's method evaluates both in one pass—never compute them separately.

5. **Status codes over exceptions for expected failures.** "No root in interval" is a valid outcome, not an exceptional condition.

6. **Linear convergence is acceptable for fallback paths.** Perfect is the enemy of working; bisection's reliability beats Newton's speed when Newton fails.

7. **Make uniqueness requirements explicit.** If your algorithm assumes one root in the interval, use `requireUniqueRoot = true` rather than hoping the input is well-formed.

---

## What To Do Now

**To use PolynomialRootFinder:**

1. Construct with desired tolerance, iteration limit, and uniqueness requirement
2. Call `findRoot(coefficients, lo, hi)` with coefficient vector and interval
3. Check `result.converged()` before using `result.root`
4. If `result.noRealRoot()`, the interval contains no real root (may be complex or outside interval)
5. If `result.multipleRoots()`, the interval contains more than one distinct root (only when `requireUniqueRoot = true`)
6. If `result.hasMultiplicity()`, the root has multiplicity > 1 (only when `requireUniqueRoot = true`)

**Constructor options:**
```cpp
// Default: tolerant of multiple roots and multiplicity
PolynomialRootFinder<> finder(tolerance, maxIterations);

// Strict: error if multiple roots OR multiplicity > 1
PolynomialRootFinder<> finder(tolerance, maxIterations, true);
```

**Pitfalls to avoid:**

- **Forgetting coefficient order:** Coefficients are [a₀, a₁, a₂, ...] for a₀ + a₁x + a₂x² + ...
- **Ignoring status codes:** Always check `converged()` or `status` before using the root
- **Assuming simple root without the flag:** If your algorithm requires multiplicity = 1, use `requireUniqueRoot = true`
- **Expecting complex root detection:** This finds real roots only; complex roots require different algorithms

---

## Read Next

- [User Manual - PolynomialRootFinder] — API reference and usage recipes
- [Case Study - Numerical Stability in Polynomial Evaluation] — Deep dive on Horner's method and condition numbers
- [Foundations - Floating-Point Arithmetic] — Understanding epsilon, ULP, and tolerance selection
