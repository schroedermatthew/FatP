#ifndef POLYNOMIAL_ROOT_FINDER_HPP
#define POLYNOMIAL_ROOT_FINDER_HPP

#include <vector>
#include <cmath>
#include <stdexcept>
#include <limits>
#include <algorithm>
#include <utility>

namespace FatP
{

/// Status codes for root finding
enum class RootStatus
{
    Converged,              ///< Root found within tolerance
    MaxIterationsExceeded,  ///< Did not converge within iteration limit
    NoRealRoot,             ///< No sign change in interval (root may be complex)
    InvalidInterval,        ///< lo >= hi
    EmptyPolynomial,        ///< No coefficients provided
    MultipleRootsInInterval,///< More than one distinct root exists (when uniqueness required)
    RootHasMultiplicity,    ///< Root has multiplicity > 1 (when uniqueness required)
    NonFiniteValue          ///< Evaluation produced NaN or Inf (overflow or degenerate input)
};

/// Result of polynomial root finding
template <typename T>
struct RootResult
{
    T root;
    T functionValue;
    std::size_t iterations;
    RootStatus status;

    /// Convenience check for successful convergence
    bool converged() const { return status == RootStatus::Converged; }

    /// Check if failure was due to no real root in interval
    bool noRealRoot() const { return status == RootStatus::NoRealRoot; }

    /// Check if failure was due to multiple distinct roots when uniqueness required
    bool multipleRoots() const { return status == RootStatus::MultipleRootsInInterval; }

    /// Check if failure was due to root having multiplicity > 1 when uniqueness required
    bool hasMultiplicity() const { return status == RootStatus::RootHasMultiplicity; }

    /// Check if evaluation produced NaN or Inf
    bool nonFinite() const { return status == RootStatus::NonFiniteValue; }
};

/// Hybrid Bisection/Newton-Raphson polynomial root finder
///
/// Given polynomial coefficients [a0, a1, a2, ..., an] representing:
///   p(x) = a0 + a1*x + a2*x^2 + ... + an*x^n
///
/// and a closed interval [lo, hi] known to bracket a root (sign change),
/// finds the root using Newton-Raphson with bisection fallback.
template <typename T = double>
class PolynomialRootFinder
{
public:
    /// Construct with tolerance, iteration limit, and uniqueness requirement
    /// @param tolerance Convergence tolerance (must be positive)
    /// @param maxIterations Maximum iterations before giving up
    /// @param requireUniqueRoot If true, returns MultipleRootsInInterval when interval contains more than one root
    explicit PolynomialRootFinder(
        T tolerance = static_cast<T>(1e-12),
        std::size_t maxIterations = 100,
        bool requireUniqueRoot = false)
        : tolerance_(tolerance)
        , maxIterations_(maxIterations)
        , requireUniqueRoot_(requireUniqueRoot)
    {
        if (tolerance <= T{0})
        {
            throw std::invalid_argument("Tolerance must be positive");
        }
    }

    /// Find root in [lo, hi] for polynomial with given coefficients
    /// Coefficients are ordered: [a0, a1, a2, ...] for a0 + a1*x + a2*x^2 + ...
    ///
    /// Returns RootResult with status indicating success or failure mode:
    /// - Converged: root found within tolerance
    /// - NoRealRoot: no sign change in interval (roots may be complex or outside interval)
    /// - MaxIterationsExceeded: did not converge in time
    /// - InvalidInterval: lo >= hi
    /// - EmptyPolynomial: no coefficients provided
    RootResult<T> findRoot(
        std::vector<T> const& coefficients,
        T lo,
        T hi) const
    {
        if (coefficients.empty())
        {
            return {T{0}, T{0}, 0, RootStatus::EmptyPolynomial};
        }
        if (lo >= hi)
        {
            return {T{0}, T{0}, 0, RootStatus::InvalidInterval};
        }

        // Evaluate at endpoints
        T fLo = evaluate(coefficients, lo);
        T fHi = evaluate(coefficients, hi);

        // Guard against NaN/Inf from overflow or degenerate coefficients.
        // Non-finite endpoint values make sign checks and convergence tests unreliable.
        if (!std::isfinite(fLo) || !std::isfinite(fHi))
        {
            T mid = (lo + hi) / T{2};
            return {mid, std::numeric_limits<T>::quiet_NaN(), 0, RootStatus::NonFiniteValue};
        }

        // Check for root at endpoints
        if (std::abs(fLo) <= tolerance_)
        {
            if (requireUniqueRoot_)
            {
                if (rootHasMultiplicity(coefficients, lo))
                {
                    return {lo, fLo, 0, RootStatus::RootHasMultiplicity};
                }
                if (hasAdditionalRoots(coefficients, lo, hi, lo))
                {
                    return {lo, fLo, 0, RootStatus::MultipleRootsInInterval};
                }
            }
            return {lo, fLo, 0, RootStatus::Converged};
        }
        if (std::abs(fHi) <= tolerance_)
        {
            if (requireUniqueRoot_)
            {
                if (rootHasMultiplicity(coefficients, hi))
                {
                    return {hi, fHi, 0, RootStatus::RootHasMultiplicity};
                }
                if (hasAdditionalRoots(coefficients, lo, hi, hi))
                {
                    return {hi, fHi, 0, RootStatus::MultipleRootsInInterval};
                }
            }
            return {hi, fHi, 0, RootStatus::Converged};
        }

        // If bracket exists (opposite signs), use standard bisection/Newton
        // Use sign comparison instead of multiplication to avoid overflow
        bool hasBracket = (fLo < T{0} && fHi > T{0}) || (fLo > T{0} && fHi < T{0});
        if (hasBracket)
        {
            // Save original bounds for uniqueness check
            T origLo = lo, origHi = hi;
            auto result = findRootBracketed(coefficients, lo, hi, fLo, fHi);

            // If uniqueness required and we found a root, check for multiplicity and additional roots
            if (requireUniqueRoot_ && result.status == RootStatus::Converged)
            {
                if (rootHasMultiplicity(coefficients, result.root))
                {
                    return {result.root, result.functionValue, result.iterations,
                            RootStatus::RootHasMultiplicity};
                }
                if (hasAdditionalRoots(coefficients, origLo, origHi, result.root))
                {
                    return {result.root, result.functionValue, result.iterations,
                            RootStatus::MultipleRootsInInterval};
                }
            }

            return result;
        }

        // No sign change - check for even-multiplicity root by finding critical points
        // A root with even multiplicity is a local min/max where f(x) = 0
        auto result = findMultipleRoot(coefficients, lo, hi);

        // No sign change does NOT imply even multiplicity.
        // Example: (x-1)(x-3) on [0,5] has same-sign endpoints but two simple roots.
        // Run the same uniqueness checks used for the bracketed path.
        if (requireUniqueRoot_ && result.status == RootStatus::Converged)
        {
            if (rootHasMultiplicity(coefficients, result.root))
            {
                return {result.root, result.functionValue, result.iterations,
                        RootStatus::RootHasMultiplicity};
            }
            if (hasAdditionalRoots(coefficients, lo, hi, result.root))
            {
                return {result.root, result.functionValue, result.iterations,
                        RootStatus::MultipleRootsInInterval};
            }
        }

        return result;
    }

private:
    /// Standard bracketed root finding (sign change exists)
    /// Maintains invariant: lo < hi throughout, tracks which endpoint is negative
    RootResult<T> findRootBracketed(
        std::vector<T> const& coefficients,
        T lo,
        T hi,
        T fLo,
        T fHi) const
    {
        // Track which side is negative (don't swap lo/hi to preserve lo < hi)
        // negSide: true means fLo < 0, false means fHi < 0
        bool loIsNegative = (fLo < T{0});

        // Start Newton from midpoint
        T x = (lo + hi) / T{2};
        T fx = T{0};

        for (std::size_t iter = 0; iter < maxIterations_; ++iter)
        {
            auto [f, df] = evaluateWithDerivative(coefficients, x);
            fx = f;

            // Check convergence on function value
            if (std::abs(fx) <= tolerance_)
            {
                return {x, fx, iter + 1, RootStatus::Converged};
            }

            // Attempt Newton step
            T xNew = x;
            bool useNewton = false;

            // Use scaled threshold for derivative check
            T const dfThreshold = std::numeric_limits<T>::epsilon() *
                                  std::max(T{1}, std::abs(x));

            if (std::abs(df) > dfThreshold)
            {
                T newtonStep = fx / df;
                xNew = x - newtonStep;

                // Accept Newton if it stays strictly within bracket
                if (xNew > lo && xNew < hi)
                {
                    useNewton = true;
                }
            }

            if (!useNewton)
            {
                // Fall back to bisection
                xNew = (lo + hi) / T{2};
            }

            // Evaluate at new point
            T fNew = evaluate(coefficients, xNew);

            // Guard against overflow in intermediate evaluations.
            // Fall back to bisection midpoint; if that also overflows, bail out.
            if (!std::isfinite(fNew))
            {
                xNew = (lo + hi) / T{2};
                fNew = evaluate(coefficients, xNew);
                if (!std::isfinite(fNew))
                {
                    return {xNew, fNew, iter + 1, RootStatus::NonFiniteValue};
                }
            }

            // Check convergence on function value
            if (std::abs(fNew) <= tolerance_)
            {
                return {xNew, fNew, iter + 1, RootStatus::Converged};
            }

            // Update bracket maintaining lo < hi
            // Root is between the negative side and positive side
            bool fNewIsNegative = (fNew < T{0});

            if (fNewIsNegative == loIsNegative)
            {
                // fNew has same sign as fLo, so root is in [xNew, hi]
                lo = xNew;
                fLo = fNew;
            }
            else
            {
                // fNew has same sign as fHi, so root is in [lo, xNew]
                hi = xNew;
                fHi = fNew;
            }

            x = xNew;
            fx = fNew;

            // Check bracket convergence with safe scaling
            T const scale = std::max(T{1}, std::max(std::abs(lo), std::abs(hi)));
            if ((hi - lo) <= tolerance_ * scale)
            {
                return {x, fx, iter + 1, RootStatus::Converged};
            }
        }

        return {x, fx, maxIterations_, RootStatus::MaxIterationsExceeded};
    }

    /// Find root with even multiplicity (no sign change)
    /// Searches for critical points where f(x) ≈ 0
    RootResult<T> findMultipleRoot(
        std::vector<T> const& coefficients,
        T lo,
        T hi) const
    {
        // Constant polynomial has no root unless already found at endpoints
        if (coefficients.size() <= 1)
        {
            T mid = (lo + hi) / T{2};
            return {mid, evaluate(coefficients, mid), 0, RootStatus::NoRealRoot};
        }

        // Use sampling + refinement approach
        constexpr std::size_t numSamples = 20;
        T step = (hi - lo) / static_cast<T>(numSamples);

        T bestX = lo;
        T bestF = std::abs(evaluate(coefficients, lo));

        // Sample to find approximate location of minimum |f(x)|
        for (std::size_t i = 0; i <= numSamples; ++i)
        {
            T x = lo + static_cast<T>(i) * step;
            T absF = std::abs(evaluate(coefficients, x));
            if (absF < bestF)
            {
                bestF = absF;
                bestX = x;
            }
        }

        // Refine using Newton on f(x) if we found a promising point
        // For multiple roots, Newton converges linearly but still works
        if (bestF < std::abs(evaluate(coefficients, lo)) &&
            bestF < std::abs(evaluate(coefficients, hi)))
        {
            T x = bestX;
            for (std::size_t iter = 0; iter < maxIterations_; ++iter)
            {
                auto [f, df] = evaluateWithDerivative(coefficients, x);

                if (!std::isfinite(f) || !std::isfinite(df))
                {
                    break;  // Overflow during refinement; abandon this candidate
                }

                if (std::abs(f) <= tolerance_)
                {
                    return {x, f, iter + 1, RootStatus::Converged};
                }

                // For multiple roots, use modified Newton: x -= m * f/f'
                // where m is multiplicity. Since we don't know m, use f*f'/(f'^2 - f*f'')
                // Simplified: just use regular Newton, it converges slower but works
                T const dfThreshold = std::numeric_limits<T>::epsilon() *
                                      std::max(T{1}, std::abs(x));
                if (std::abs(df) > dfThreshold)
                {
                    T xNew = x - f / df;
                    // Keep within bounds
                    xNew = std::max(lo, std::min(hi, xNew));
                    if (std::abs(xNew - x) < tolerance_)
                    {
                        // Positional convergence with relaxed function-value check.
                        // Multiple roots flatten |f| near the root, so we accept
                        // values up to 100× the nominal tolerance here.
                        if (std::abs(f) <= tolerance_ * static_cast<T>(100))
                        {
                            return {x, f, iter + 1, RootStatus::Converged};
                        }
                        break;  // Stuck, not a root
                    }
                    x = xNew;
                }
                else
                {
                    // At critical point with near-zero derivative.
                    // Relaxed tolerance: multiple roots flatten |f|, accept 100× nominal.
                    if (std::abs(f) <= tolerance_ * static_cast<T>(100))
                    {
                        return {x, f, iter + 1, RootStatus::Converged};
                    }
                    break;
                }
            }
        }

        // No real root found
        T mid = (lo + hi) / T{2};
        return {mid, evaluate(coefficients, mid), 0, RootStatus::NoRealRoot};
    }

    /// Compute coefficients of derivative polynomial
    static std::vector<T> derivativeCoefficients(std::vector<T> const& coeffs)
    {
        if (coeffs.size() <= 1)
        {
            return {};
        }

        std::vector<T> deriv;
        deriv.reserve(coeffs.size() - 1);

        for (std::size_t i = 1; i < coeffs.size(); ++i)
        {
            deriv.push_back(coeffs[i] * static_cast<T>(i));
        }
        return deriv;
    }

    /// Check if interval [a, b] contains a sign change (potential root)
    static bool hasSignChange(std::vector<T> const& coeffs, T a, T b, T tol)
    {
        T fa = evaluate(coeffs, a);
        T fb = evaluate(coeffs, b);

        // If either endpoint is essentially zero, not a sign change for our purposes
        if (std::abs(fa) <= tol || std::abs(fb) <= tol)
        {
            return false;
        }

        // Use sign comparison instead of multiplication to avoid overflow
        return (fa < T{0} && fb > T{0}) || (fa > T{0} && fb < T{0});
    }

    /// Check if there are additional roots in [origLo, origHi] besides the one near foundRoot
    bool hasAdditionalRoots(
        std::vector<T> const& coeffs,
        T origLo,
        T origHi,
        T foundRoot) const
    {
        // Create small exclusion zone around found root.
        // Use a fraction of the interval width rather than root-magnitude × tolerance,
        // which produces excessively large exclusion zones for large-magnitude roots
        // (e.g., root≈1e12, tol=1e-12 would give exclusion≈10, swallowing nearby roots).
        T intervalWidth = origHi - origLo;
        T exclusion = std::max(tolerance_ * static_cast<T>(10),
                               intervalWidth * static_cast<T>(0.01));

        T leftHi = foundRoot - exclusion;
        T rightLo = foundRoot + exclusion;

        // Check left interval [origLo, leftHi]
        if (leftHi > origLo && hasSignChange(coeffs, origLo, leftHi, tolerance_))
        {
            return true;
        }

        // Check right interval [rightLo, origHi]
        if (rightLo < origHi && hasSignChange(coeffs, rightLo, origHi, tolerance_))
        {
            return true;
        }

        // Also sample for potential double roots in remaining intervals.
        // A double root won't have a sign change but will have |f(x)| ≈ 0.
        // Use endpoint magnitude as a scale reference to avoid false positives
        // on polynomials with uniformly small |f| (small coefficients) or
        // false negatives on polynomials with large coefficients.
        constexpr std::size_t numSamples = 10;
        T endpointMag = std::max(std::abs(evaluate(coeffs, origLo)),
                                 std::abs(evaluate(coeffs, origHi)));
        T probeTol = std::max(tolerance_ * static_cast<T>(100),
                              endpointMag * tolerance_);

        // Check left interval for potential multiple roots
        if (leftHi > origLo)
        {
            T step = (leftHi - origLo) / static_cast<T>(numSamples);
            for (std::size_t i = 0; i <= numSamples; ++i)
            {
                T x = origLo + static_cast<T>(i) * step;
                if (std::abs(evaluate(coeffs, x)) <= probeTol)
                {
                    return true;
                }
            }
        }

        // Check right interval for potential multiple roots
        if (rightLo < origHi)
        {
            T step = (origHi - rightLo) / static_cast<T>(numSamples);
            for (std::size_t i = 0; i <= numSamples; ++i)
            {
                T x = rightLo + static_cast<T>(i) * step;
                if (std::abs(evaluate(coeffs, x)) <= probeTol)
                {
                    return true;
                }
            }
        }

        return false;
    }

    /// Check if root has multiplicity > 1 (both f(r) ≈ 0 and f'(r) ≈ 0)
    bool rootHasMultiplicity(std::vector<T> const& coeffs, T root) const
    {
        auto [f, df] = evaluateWithDerivative(coeffs, root);

        // First verify we're convincingly at a root. Bracket-width convergence
        // can return Converged at a point where |f| is not actually small
        // (e.g., steep function with collapsed bracket). In that case we cannot
        // reliably assess multiplicity from the derivative.
        T fTol = tolerance_ * static_cast<T>(100);
        if (std::abs(f) > fTol)
        {
            return false;
        }

        // Root has multiplicity > 1 if derivative is also near zero
        // Use a relaxed tolerance for derivative check since numerical errors accumulate
        T derivTol = tolerance_ * static_cast<T>(1000) +
                     std::abs(root) * tolerance_ * static_cast<T>(100);

        return std::abs(df) <= derivTol;
    }

public:

    /// Evaluate polynomial at x using Horner's method
    static T evaluate(std::vector<T> const& coeffs, T x)
    {
        if (coeffs.empty())
        {
            return T{0};
        }

        T result = coeffs.back();
        for (auto it = coeffs.rbegin() + 1; it != coeffs.rend(); ++it)
        {
            result = result * x + *it;
        }
        return result;
    }

    /// Evaluate polynomial and its derivative simultaneously (Horner's method)
    static std::pair<T, T> evaluateWithDerivative(std::vector<T> const& coeffs, T x)
    {
        if (coeffs.empty())
        {
            return {T{0}, T{0}};
        }
        if (coeffs.size() == 1)
        {
            return {coeffs[0], T{0}};
        }

        T f = coeffs.back();
        T df = T{0};

        for (auto it = coeffs.rbegin() + 1; it != coeffs.rend(); ++it)
        {
            df = df * x + f;
            f = f * x + *it;
        }
        return {f, df};
    }

    T tolerance() const { return tolerance_; }
    std::size_t maxIterations() const { return maxIterations_; }
    bool requireUniqueRoot() const { return requireUniqueRoot_; }

private:
    T tolerance_;
    std::size_t maxIterations_;
    bool requireUniqueRoot_;
};

} // namespace FatP

#endif // POLYNOMIAL_ROOT_FINDER_HPP
