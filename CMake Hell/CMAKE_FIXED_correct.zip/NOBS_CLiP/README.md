# NOBS-CLiP CMake Structure - Fixed Version

This is a complete rewrite of the CMake build system that fixes the chronic link failures with Boost and MKL.

## What Was Wrong (and How It's Fixed)

### 1. MKL Never Reached the Executable

**Problem:** `boltMathBackend` is a STATIC library. The original code used `PRIVATE` linking for MKL, which means the MKL libraries were not propagated to the final executable. Static libraries don't link anything - they're just archives. The executable does all the linking.

**Fix:** Changed to `PUBLIC` linking in `BOLT/us/mkl/CMakeLists.txt`:
```cmake
# OLD (broken):
target_link_options(boltMathBackend PRIVATE ${MKL_LIBS})

# NEW (works):
target_link_options(boltMathBackend PUBLIC ${MKL_LIBS_LIST})
```

### 2. MKL Flags Were One Giant String

**Problem:** `mkl_link_tool` outputs something like:
```
-Wl,--start-group /path/to/libmkl_intel_ilp64.a ... -Wl,--end-group -lpthread
```
The original code passed this as `${MKL_LIBS}` which CMake treated as ONE argument (including the spaces).

**Fix:** Convert to a proper CMake list:
```cmake
separate_arguments(MKL_LIBS_LIST UNIX_COMMAND "${MKL_LIBS_STR}")
```

### 3. CMAKE_BUILD_TYPE on Visual Studio

**Problem:** Code like this:
```cmake
if (NOT CMAKE_BUILD_TYPE STREQUAL "Debug")
```
Always evaluates to TRUE on Visual Studio because `CMAKE_BUILD_TYPE` is empty (VS is multi-config).

**Fix:** Removed all `CMAKE_BUILD_TYPE` checks. Use generator expressions for config-specific behavior:
```cmake
$<$<CONFIG:Debug>:something>
$<$<CONFIG:Release>:something_else>
```

### 4. /MT vs /MD CRT Mismatch

**Problem:** Hardcoded `/MT` (static CRT) but Boost is usually built with `/MD` (dynamic CRT). This causes `LNK2038: mismatch detected for 'RuntimeLibrary'`.

**Fix:** Use `CMAKE_MSVC_RUNTIME_LIBRARY` with an option:
```cmake
option(NOBS_USE_STATIC_CRT "Use static CRT (/MT)" OFF)
if(NOBS_USE_STATIC_CRT)
    set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
else()
    set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL")
endif()
```

### 5. include_directories() Abuse

**Problem:** This doesn't work:
```cmake
include_directories(nobs PRIVATE "${PROJECT_SOURCE_DIR}")
```
`include_directories()` doesn't take target names or PRIVATE/PUBLIC. This literally adds directories named "nobs" and "PRIVATE" to the include path.

**Fix:** Use `target_include_directories()` or directory-scoped `include_directories()` without keywords.

### 6. Option Name Collisions

**Problem:** Both NOBS and BOLT defined `BUILD_TESTS`. CMake options are cache-global, so one stomps the other.

**Fix:** Prefixed all options: `NOBS_BUILD_TESTS`, `BOLT_BUILD_TESTS`, etc.

---

## Quick Start

### Prerequisites
- CMake 3.15+
- Intel MKL (set `MKLROOT` environment variable)
- Boost headers (set `BOOST_ROOT` or `NOBS_BOOST_INCLUDE_DIR`)
- C++17 compiler (MSVC 2017+, GCC 7+, Clang 5+)

### Linux Build

```bash
# Source Intel oneAPI environment
source /opt/intel/oneapi/setvars.sh

# Configure
cmake -B build -S . \
    -DCMAKE_BUILD_TYPE=Release \
    -DNOBS_BUILD_TESTS=ON

# Build
cmake --build build -j$(nproc)

# Run tests
ctest --test-dir build
```

### Windows Build (Visual Studio)

```powershell
# Open Intel oneAPI command prompt (or run setvars.bat)

# Configure (VS 2019)
cmake -B build -S . -G "Visual Studio 16 2019" -A x64

# Build Release
cmake --build build --config Release

# Build Debug
cmake --build build --config Debug
```

### Key Options

| Option | Default | Description |
|--------|---------|-------------|
| `NOBS_BUILD_TESTS` | ON | Build unit tests |
| `NOBS_BUILD_BENCHMARKS` | ON | Build benchmarks |
| `NOBS_THREADED` | ON | Enable multi-threading |
| `NOBS_USE_STATIC_CRT` | OFF | Use /MT instead of /MD (Windows) |
| `NOBS_ENABLE_OPTIMIZERS` | ON | Enable SNOPT support |
| `NOBS_SIMULATE_SNOPT` | ON | Use simulated SNOPT |
| `BOLT_MKL_THREADING` | auto | MKL threading: gomp, iomp5, tbb |

### Troubleshooting

**"undefined reference to mkl_..."**
- MKL isn't propagating. Check that `boltMathBackend` uses `PUBLIC` linking.
- Verify `MKLROOT` is set correctly.

**"LNK2038: mismatch detected for 'RuntimeLibrary'"**
- CRT mismatch. Set `NOBS_USE_STATIC_CRT` to match your Boost build.
- If Boost was built with vcpkg, use `NOBS_USE_STATIC_CRT=OFF` (default).

**"cannot find -lgomp" or OpenMP errors**
- Install OpenMP: `sudo apt install libomp-dev` (Linux)
- Or switch to Intel OpenMP: `-DBOLT_MKL_THREADING=iomp5`

**Build succeeds but crashes at runtime**
- Likely threading mismatch. Make sure MKL threading model matches your OpenMP.
- Check `BOLT_MKL_THREADING` setting.

---

## Directory Structure

```
NOBS_CLiP/
├── CMakeLists.txt          # Top-level build
├── BOLT/                   # Math library
│   ├── CMakeLists.txt
│   ├── us/mkl/             # MKL backend
│   │   └── CMakeLists.txt  # ← Critical MKL linking happens here
│   └── tests/
├── core/                   # Main executable (nobs-clip)
│   └── CMakeLists.txt      # ← Links boltMathBackend (MKL propagates automatically)
├── modules/                # Various modules and tests
├── common/                 # Shared utilities
├── testutils/              # Test helpers
├── FAT_P/                  # Additional tests
└── sim/snopt/              # Simulated SNOPT
```

---

## Migration from Old Build

1. Delete your old `build/` directory completely
2. Replace CMakeLists.txt files with the new versions
3. Re-run CMake configure
4. If you had custom BOOST_INCLUDES, use `NOBS_BOOST_INCLUDE_DIR` instead
5. If you need static CRT, set `NOBS_USE_STATIC_CRT=ON`

The main executable is now just called `nobs-clip` (unchanged).
