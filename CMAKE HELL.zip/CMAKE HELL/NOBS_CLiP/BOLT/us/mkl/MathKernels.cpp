/**
 * -----------------------------------------------------------------------------
 * @file  MathKernels.cpp
 *
 * @brief Description:
 * The contents of this file belong to bolt::math namespace, and
 * bolt::math::internal_ namespace. They are both used for math kernel
 * operation[s] translation between the host and the backend. See
 * MathKernels.hpp for more details.
 *
 * @copyright
 * (c) 2023-2024 Northrop Grumman Systems Corporation
 * @date
 * 2024-11-11
 * @version
 * 0.1
 * @author
 * William Yessen
 *
 * -----------------------------------------------------------------------------
 */
#include "bolt/MathKernels.hpp"

#include <mkl.h>

#if defined BOLT_USE_DOUBLE_PRECISION
#define BOLT_MKL_CONSTRUCT_FUNC_NAME(prefix, postfix) prefix##d##postfix
#define BOLT_MKL_CONSTRUCT_FUNC_NAME_I(prefix, postfix) prefix##d##postfix##I
#else
#define BOLT_MKL_CONSTRUCT_FUNC_NAME(prefix, postfix) prefix##s##postfix
#define BOLT_MKL_CONSTRUCT_FUNC_NAME_I(prefix, postfix) prefix##s##postfix##I
#endif

// FIXME: kill openmp - revisit this later (MKL parallelizes internally, we
// don't want to oversaturate)
#define BOLT_OMP_PARALLEL
#define BOLT_OMP_REDUCE(op, var)

// #if defined(BOLT_THREADED_MATH) && defined(_MSC_VER)
// #define BOLT_OMP_PARALLEL __pragma(omp parallel for)
// #elif defined(BOLT_THREADED_MATH)
// #define BOLT_OMP_PARALLEL _Pragma("omp parallel for")
// #else
// #define BOLT_OMP_PARALLEL
// #define BOLT_OMP_REDUCE(op, var)
// #endif
/**
 * @typedef BOLT_MKL_VEC_BINARY_OP_IMPL(name, prefix, postfix)
 * defines a calling interface for Vector Binary Operations between the backend
 * and frontend
 *
 * @param name: Frontend function name for vector binary operation
 * @param prefix: Backend function name prefix
 * @param postfix: Backend function name postfix
 */
// BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__add_, v, Add)
#define BOLT_MKL_VEC_BINARY_OP_IMPL(name, prefix, postfix)                     \
  BOLT_KERNEL_SIGNATURE(name) {                                                \
    if (inca != 1 || incb != 1 || incc != 1) {                                 \
      BOLT_OMP_PARALLEL                                                        \
      for (int ii = 0; ii < nhops; ++ii)                                       \
        BOLT_MKL_CONSTRUCT_FUNC_NAME_I(prefix, postfix)                        \
      (colsa, a + ii * hopa, inca, b + ii * hopb, incb, c + ii * hopc, incc);  \
    } else {                                                                   \
      BOLT_OMP_PARALLEL                                                        \
      for (int ii = 0; ii < nhops; ++ii)                                       \
        BOLT_MKL_CONSTRUCT_FUNC_NAME(prefix, postfix)                          \
      (colsa, a + ii * hopa, b + ii * hopb, c + ii * hopc);                    \
    }                                                                          \
  }

/**
 * @typedef BOLT_MKL_VEC_UNARY_OP_IMPL(name, prefix, postfix)
 * defines a calling interface for Vector Unary Operations between the backend
 * and frontend
 *
 * @param name: Frontend function name for vector unary operation
 * @param prefix: Backend function name prefix
 * @param postfix: Backend function name postfix
 */
#define BOLT_MKL_VEC_UNARY_OP_IMPL(name, prefix, postfix)                      \
  BOLT_KERNEL_SIGNATURE(name) {                                                \
    if (inca != 1 || incc != 1) {                                              \
      BOLT_OMP_PARALLEL                                                        \
      for (int ii = 0; ii < nhops; ++ii)                                       \
        BOLT_MKL_CONSTRUCT_FUNC_NAME_I(prefix, postfix)                        \
      (colsa, a + ii * hopa, inca, c + ii * hopc, incc);                       \
    } else {                                                                   \
      BOLT_OMP_PARALLEL                                                        \
      for (int ii = 0; ii < nhops; ++ii)                                       \
        BOLT_MKL_CONSTRUCT_FUNC_NAME(prefix, postfix)                          \
      (colsa, a + ii * hopa, c + ii * hopc);                                   \
    }                                                                          \
  }

/**
 * @typedef BOLT_MKL_BLAS_MAT_BINARY_OP_IMPL(name, prefix, postfix)
 * defines a calling interface for BLAS Matrix Binary Operations between the
 * backend and frontend
 *
 * @param name: Frontend function name for matrix binary operation
 * @param prefix: Backend function name prefix
 * @param postfix: Backend function name postfix
 */
#define BOLT_MKL_BLAS_MAT_BINARY_OP_IMPL(name, prefix, postfix)                \
  BOLT_KERNEL_SIGNATURE(name) {                                                \
    BOLT_OMP_PARALLEL                                                          \
    for (int ii = 0; ii < nhops; ++ii)                                         \
      BOLT_MKL_CONSTRUCT_FUNC_NAME(prefix, postfix)                            \
    (CBLAS_LAYOUT::CblasRowMajor, CBLAS_TRANSPOSE::CblasNoTrans,               \
     CBLAS_TRANSPOSE::CblasNoTrans, rowsa, colsb, colsa, 1.0, a + ii * hopa,   \
     lda, b + ii * hopb, ldb, 0.0, c + ii * hopc, ldc);                        \
  }

/**
 * @typedef BOLT_MKL_OUR_SIMPLE_BINARY_OP_IMPL(name, prefix, postfix)
 * defines a calling interface for Simple Binary Operations between the
 * backend and frontend
 *
 * @param name: Frontend function signature for simple binary operation
 * @param func: Function name for the operation to be performed:
 * i.e add, sub, mul
 */
#define BOLT_MKL_OUR_SIMPLE_BINARY_OP_IMPL(name, func)                         \
  BOLT_KERNEL_SIGNATURE(name) {                                                \
    for (int ii = 0; ii < nhops; ++ii) {                                       \
      auto curra = a + ii * hopa;                                              \
      auto currb = b + ii * hopb;                                              \
      auto currc = c + ii * hopc;                                              \
      for (int jj = 0; jj < colsa; ++jj)                                       \
        currc[jj * incc] = func(curra[jj * inca], currb[jj * incb]);           \
    }                                                                          \
  }

namespace bolt::math {
namespace internal_ {

/**
 * @brief A helper function to do a less than comparison between two numbers
 *
 * @param a the first number to compare
 * @param b the second number to compare
 * @return returns 1 if a < b, returns 0 otherwise
 */
inline static types::real_t bolt__kernel_helper_LESS_(types::real_t a,
                                                      types::real_t b) {
  return a < b;
}
/**
 * @brief A helper function to do greater than comparison between two numbers
 *
 * @param a the first number to compare
 * @param b the second number to compare
 * @return returns 1 if a > b, returns 0 otherwise
 */
inline static types::real_t bolt__kernel_helper_GREATER_(types::real_t a,
                                                         types::real_t b) {
  return a > b;
}
/**
 * @brief Helper function to do less than or equal comparison between two
 * numbers
 *
 * @param a the first number to compare
 * @param b the second number to compare
 * @return returns 1 if a <= b, returns 0 otherwise
 */
// FIXME: floating point comparison must be fixed in the following three...
inline static types::real_t bolt__kernel_helper_LESSEQ_(types::real_t a,
                                                        types::real_t b) {
  return a <= b;
}
/**
 * @brief Helper function to do greater than or equal comparison between two
 * numbers
 *
 * @param a the first number to compare
 * @param b the second number to compare
 * @return returns 1 if a >= b, returns 0 otherwise
 */
inline static types::real_t bolt__kernel_helper_GREATEREQ_(types::real_t a,
                                                           types::real_t b) {
  return a >= b;
}
/**
 * @brief Helper function to do equals comparison between two numbers
 *
 * @param a the first number to compare
 * @param b the second number to compare
 * @return returns 1 if a == b, returns 0 otherwise
 */
inline static types::real_t bolt__kernel_helper_EQUAL_(types::real_t a,
                                                       types::real_t b) {
  return a == b;
}

BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__add_, v, Add)
BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__sub_, v, Sub)
BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__mul_, v, Mul)
BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__div_, v, Div)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__inv_, v, Inv)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__abs_, v, Abs)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__sin_, v, Sin)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__cos_, v, Cos)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__tan_, v, Tan)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__asin_, v, Asin)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__acos_, v, Acos)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__atan_, v, Atan)
BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__atan2_, v, Atan2)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__sinh_, v, Sinh)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__cosh_, v, Cosh)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__tanh_, v, Tanh)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__asinh_, v, Asinh)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__acosh_, v, Acosh)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__atanh_, v, Atanh)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__exp_, v, Exp)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__exp10_, v, Exp10)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__exp2_, v, Exp2)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__ln_, v, Ln)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__log2_, v, Log2)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__log10_, v, Log10)
BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__pow_, v, Pow)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__square_, v, Sqr)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__sqrt_, v, Sqrt)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__floor_, v, Floor)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__ceil_, v, Ceil)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__trunc_, v, Trunc)
BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__round_, v, Round)

BOLT_MKL_VEC_UNARY_OP_IMPL(kernel__gamma_, v, TGamma)

/**
 * Defines the frontend signature function for the dot product of two vectors
 * and it interfaces with the backend dot product function
 */
BOLT_KERNEL_SIGNATURE(kernel__dot_) {
  BOLT_OMP_PARALLEL
  for (int ii = 0; ii < nhops; ++ii)
    c[ii * hopc] = BOLT_MKL_CONSTRUCT_FUNC_NAME(cblas_, dot)(
        colsa, a + ii * hopa, inca, b + ii * hopb, incb);
}

BOLT_MKL_BLAS_MAT_BINARY_OP_IMPL(kernel__matmul_, cblas_, gemm)

/**
 * Defines the frontend function signature for the matrix inversion
 * and it interfaces with the backend to perform the matrix inversion
 */
// FIXME: This must be tested!
BOLT_KERNEL_SIGNATURE(kernel__matinv_) {
  lapack_int *ipiv = new lapack_int[rowsa];

  BOLT_OMP_PARALLEL
  for (int ii = 0; ii < nhops; ++ii)
    BOLT_MKL_CONSTRUCT_FUNC_NAME(LAPACKE_, getrf)
  (LAPACK_ROW_MAJOR, rowsa, colsa, (types::real_t *)(a + ii * hopa), lda, ipiv);

  BOLT_OMP_PARALLEL
  for (int ii = 0; ii < nhops; ++ii)
    BOLT_MKL_CONSTRUCT_FUNC_NAME(LAPACKE_, getri)
  (LAPACK_ROW_MAJOR, rowsa, (types::real_t *)(a + ii * hopa), lda, ipiv);

  delete[] ipiv;
}

BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__min_, v, Fmin)
BOLT_MKL_VEC_BINARY_OP_IMPL(kernel__max_, v, Fmax)

/**
 * Defines the frontend function signature for the sum of the elements
 * of a given vector
 */
BOLT_KERNEL_SIGNATURE(kernel__sum_) {
  // FIXME: When not using OMP, or even when using OMP but in the context of an
  // OMP thread, MSVC++ will not vectorize reductions but GCC/Clang should.
  for (int ii = 0; ii < nhops; ++ii) {
    types::real_t ssum{};
#if defined(BOLT_THREADED_MATH) && defined(_MSC_VER)
    __pragma(omp parallel for reduction(+ : ssum))
#elif defined(BOLT_THREADED_MATH)
    _Pragma("omp parallel for reduction(+ : ssum)")
#endif
    for (int jj = 0; jj < colsa; ++jj)
      ssum += a[jj];

    *c += ssum;

    a += hopa;
    c += hopc;
  }
}

BOLT_MKL_OUR_SIMPLE_BINARY_OP_IMPL(kernel__lt_, bolt__kernel_helper_LESS_)
BOLT_MKL_OUR_SIMPLE_BINARY_OP_IMPL(kernel__gt_, bolt__kernel_helper_GREATER_)
BOLT_MKL_OUR_SIMPLE_BINARY_OP_IMPL(kernel__lte_, bolt__kernel_helper_LESSEQ_)
BOLT_MKL_OUR_SIMPLE_BINARY_OP_IMPL(kernel__gte_, bolt__kernel_helper_GREATEREQ_)
BOLT_MKL_OUR_SIMPLE_BINARY_OP_IMPL(kernel__eq_, bolt__kernel_helper_EQUAL_)

} // namespace internal_
} // namespace bolt::math
