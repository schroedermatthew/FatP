#include "Main.hpp"

#include <filesystem>

#include "common/BoltMathNamespaceAliases.hpp"
#include "common/BoltMathTestNamespaceAliases.hpp"
#include "common/CommonTypes.hpp"
#include "modules/config_parsers/xml/construct_params.ipp"
#include "modules/sok/search_optimization.ipp"
#include "modules/utils/parameters/scaling/default_scale_parameters.ipp"

std::pair<nobs::ParamStructure, nobs::ParamStructure>
load_params(const std::string &file, const std::string &dir,
            std::shared_ptr<nobsmain::Logger> logger) {

  using namespace nobs::modules::utils::parameters::scaling;
  using namespace nobs::parsing;
  auto params = construct_params(file, dir, logger);
  auto scale_params = default_scale_parameters(params);

  return {params, scale_params};
}

int main(int argc, char **argv) {
  try {
    auto progname = std::string(argv[0]);
    if (argc < 4 || argc > 6) {
      std::cerr << progname << ": \n";
      std::cerr << "*** required (in this order): <input dir> "
                   "<input xml> <output dir> <loglevel> \n";
      std::cerr << "*** optionally: <log file> (if not given, stdout/stderr "
                   "used).\n";
      std::cerr
          << "*** allowed log levels are 0 = CRIT, 1 = ERROR, 2 = WARN, 3 = "
             "INFO, 4 = DEBUG."
          << std::endl;
      return -1;
    }

    auto indir = std::string(argv[1]);
    auto infile = std::string(argv[2]);
    auto outdir = std::string(argv[3]); // FIXME: we're not using this anymore
    auto logint = std::stoi(argv[4]);

    if (logint < 0 || logint > 4) {
      std::cerr << "allowed log levels are 0 - 4." << std::endl;
      return -1;
    }

    auto loglvl = static_cast<nobsmain::LogLevel>(logint);

    std::ofstream flog{};
    auto logger = std::shared_ptr<nobsmain::Logger>{};

    if (argc == 6) {
      flog.open(argv[5], std::ofstream::out);
      logger = std::make_shared<nobsmain::Logger>(loglvl, flog, flog);
    } else
      logger = std::make_shared<nobsmain::Logger>(loglvl);

    auto [params, scale_params] = load_params(infile, indir, logger);

    nobs::modules::sok::SO_return so_ret{};
    NOBS_TRY_ELSE_RETHROW(so_ret = nobs::modules::sok::search_optimization(
                              params, scale_params, false, logger),
                          nobsmain::Status::UNEXPECTED_ERROR,
                          "search optimization failed", logger);

    auto [soln, PD, timing, pblm, pblmArgs, out_params, used_guesses] = so_ret;

    NOBS_INFO_LOG(logger, "finished running SOK. PD = " +
                              std::to_string(PD[0][{0, 0}]) + "%");

    NOBS_INFO_LOG(logger, "timer: problem init   : " +
                              timing[0].time_to_initialize_problem.format());
    NOBS_INFO_LOG(logger, "timer: optimizer init : " +
                              timing[0].time_to_initialize_optimizer.format());
    NOBS_INFO_LOG(logger, "timer: optimizer exec : " +
                              timing[0].time_to_execute_optimization.format());
    NOBS_INFO_LOG(logger, "timer: myfg exec      : " +
                              timing[0].time_to_execute_myfg.format());

  } catch (const std::exception &e) {
    std::cerr << "NOBS encountered a fatal exception: " << e.what()
              << std::endl;
  }

  return 0;
}
