#pragma once

#include "common/All.hpp"
#include "modules/config_parsers/processors/Processors.hpp"

namespace nobsmain {

using namespace nobs::errors;
using namespace nobs::io;

} // namespace nobsmain
