#include "md_array_view.hpp"
#include <cstdio>
#include <numeric>

// =====================================================================
// Compile-time checks
// =====================================================================

// --- 1D ---
using V1 = md_array_view<int, 1, 5>;
static_assert(V1::rank()      == 1);
static_assert(V1::size()      == 5);
static_assert(V1::extent(0)   == 5);
static_assert(V1::stride(0)   == 1);
static_assert(!V1::empty());

// --- 2D ---
using V2 = md_array_view<float, 2, 3, 4>;
static_assert(V2::rank()      == 2);
static_assert(V2::size()      == 12);
static_assert(V2::extent(0)   == 3);
static_assert(V2::extent(1)   == 4);
static_assert(V2::stride(0)   == 4);
static_assert(V2::stride(1)   == 1);

// --- 3D ---
using V3 = md_array_view<double, 3, 2, 3, 5>;
static_assert(V3::rank()      == 3);
static_assert(V3::size()      == 30);
static_assert(V3::stride(0)   == 15);
static_assert(V3::stride(1)   == 5);
static_assert(V3::stride(2)   == 1);

// --- const element type ---
using VC = md_array_view<const int, 2, 4, 4>;
static_assert(std::is_same_v<VC::element_type, const int>);
static_assert(std::is_same_v<VC::reference, const int&>);
static_assert(std::is_same_v<VC::pointer, const int*>);

// --- trait checks ---
static_assert(std::is_same_v<
    detail::md_view_for<int[3][4][5]>,
    md_array_view<int, 3, 3, 4, 5>>);

static_assert(std::is_same_v<
    detail::md_view_for<const double[8][8]>,
    md_array_view<const double, 2, 8, 8>>);

static_assert(std::is_same_v<
    detail::build_array_t<int, 3, 4, 5>,
    int[3][4][5]>);

// --- Concept enforcement: wrong index count must not compile ---
// Uncomment any line to verify the concept fires:
//
// void bad_too_few() {
//     int arr[2][3] = {};
//     md_array_view v(arr);
//     v(1);              // Error: sizeof...(Indices) != Rank
// }
// void bad_too_many() {
//     int arr[2][3] = {};
//     md_array_view v(arr);
//     v(1, 2, 3);       // Error: sizeof...(Indices) != Rank
// }

// --- Concept enforcement: Dims must match Rank ---
// Uncomment to verify compile error:
// using Bad = md_array_view<int, 2, 3, 4, 5>;  // 3 dims != rank 2

// --- constexpr rank-1 (pointer stays within a single flat array) ---
constexpr bool test_constexpr_1d()
{
    int arr[5] = {10, 20, 30, 40, 50};
    md_array_view v(arr);
    if (v(0) != 10) return false;
    if (v(4) != 50) return false;
    v(2) = 99;
    return v(2) == 99;
}
static_assert(test_constexpr_1d(), "constexpr rank-1 must work");

// =====================================================================
// Runtime checks
// =====================================================================

void test_1d()
{
    int arr[6] = {10, 20, 30, 40, 50, 60};
    md_array_view v(arr);

    static_assert(std::is_same_v<decltype(v), md_array_view<int, 1, 6>>);
    assert(v(0) == 10);
    assert(v(5) == 60);

    v(2) = 99;
    assert(arr[2] == 99);

    std::printf("  1D: OK\n");
}

void test_2d()
{
    int arr[3][4];
    std::iota(&arr[0][0], &arr[0][0] + 12, 0);
    // arr[i][j] == i*4 + j

    md_array_view v(arr);
    static_assert(std::is_same_v<decltype(v), md_array_view<int, 2, 3, 4>>);

    assert(v(0, 0) == 0);
    assert(v(1, 2) == 6);   // 1*4 + 2
    assert(v(2, 3) == 11);  // 2*4 + 3

    v(1, 1) = -1;
    assert(arr[1][1] == -1);

    std::printf("  2D: OK\n");
}

void test_3d()
{
    int arr[2][3][5];
    std::iota(&arr[0][0][0], &arr[0][0][0] + 30, 0);
    // arr[i][j][k] == i*15 + j*5 + k

    md_array_view v(arr);
    static_assert(std::is_same_v<decltype(v), md_array_view<int, 3, 2, 3, 5>>);

    assert(v(0, 0, 0) == 0);
    assert(v(1, 0, 0) == 15);
    assert(v(1, 2, 4) == 29);
    assert(v(0, 2, 3) == 13);

    std::printf("  3D: OK\n");
}

void test_4d()
{
    int arr[2][3][4][5];
    std::iota(&arr[0][0][0][0], &arr[0][0][0][0] + 120, 0);

    auto v = make_md_view(arr);
    static_assert(std::is_same_v<decltype(v), md_array_view<int, 4, 2, 3, 4, 5>>);

    // arr[i][j][k][l] = i*60 + j*20 + k*5 + l
    assert(v(0, 0, 0, 0) == 0);
    assert(v(1, 2, 3, 4) == 119);  // 60 + 40 + 15 + 4

    std::printf("  4D: OK\n");
}

void test_const_array()
{
    const int arr[2][3] = {{1, 2, 3}, {4, 5, 6}};
    md_array_view v(arr);

    static_assert(std::is_same_v<decltype(v), md_array_view<const int, 2, 2, 3>>);
    static_assert(std::is_same_v<decltype(v(0, 0)), const int&>);

    assert(v(0, 0) == 1);
    assert(v(1, 2) == 6);

    std::printf("  const: OK\n");
}

void test_make_md_view()
{
    double arr[4][4];
    auto v = make_md_view(arr);

    static_assert(std::is_same_v<decltype(v), md_array_view<double, 2, 4, 4>>);

    v(3, 3) = 3.14;
    assert(arr[3][3] == 3.14);

    std::printf("  make_md_view: OK\n");
}

void test_pointer_construction()
{
    int flat[12];
    std::iota(flat, flat + 12, 0);

    auto v = md_array_view<int, 2, 3, 4>::from_pointer(flat);

    assert(v(0, 0) == 0);
    assert(v(1, 2) == 6);
    assert(v(2, 3) == 11);

    std::printf("  from_pointer: OK\n");
}

void test_data_aliasing()
{
    int arr[2][3] = {{10, 20, 30}, {40, 50, 60}};
    md_array_view v(arr);

    // Writes through the view are visible through the original array
    v(0, 2) = 999;
    assert(arr[0][2] == 999);

    // Writes through the array are visible through the view
    arr[1][0] = -42;
    assert(v(1, 0) == -42);

    // data() returns pointer to first element
    assert(v.data() == &arr[0][0]);

    std::printf("  aliasing: OK\n");
}

void test_array_subscript()
{
    int arr[2][3][4];
    std::iota(&arr[0][0][0], &arr[0][0][0] + 24, 0);
    // arr[i][j][k] == i*12 + j*4 + k

    md_array_view v(arr);

    // Basic access via std::array index
    // (Extra parens needed: preprocessor sees brace-list commas as macro args)
    assert((v[{0, 0, 0}] == 0));
    assert((v[{1, 0, 0}] == 12));
    assert((v[{1, 2, 3}] == 23));

    // Write through operator[]
    v[{0, 1, 2}] = -1;
    assert(arr[0][1][2] == -1);

    // operator[] and operator() agree
    for (std::size_t i = 0; i < 2; ++i)
        for (std::size_t j = 0; j < 3; ++j)
            for (std::size_t k = 0; k < 4; ++k)
                assert((v(i, j, k) == v[{i, j, k}]));

    // Programmatic index construction — the main use case
    std::array<std::size_t, 3> idx = {1, 1, 1};
    assert(v[idx] == 1*12 + 1*4 + 1);

    std::printf("  operator[]: OK\n");
}

void test_signed_indices()
{
    int arr[3][4] = {};
    md_array_view v(arr);

    // Signed int indices should work when non-negative
    int i = 2, j = 3;
    v(i, j) = 42;
    assert(arr[2][3] == 42);

    // Various signed types
    short s = 1;
    long l = 2;
    v(s, l) = 99;
    assert(arr[1][2] == 99);

    std::printf("  signed indices: OK\n");
}

int main()
{
    std::printf("md_array_view tests:\n");

    test_1d();
    test_2d();
    test_3d();
    test_4d();
    test_const_array();
    test_make_md_view();
    test_pointer_construction();
    test_data_aliasing();
    test_array_subscript();
    test_signed_indices();

    std::printf("All tests passed.\n");
    return 0;
}
