#include "md_array_view.hpp"
#include <cmath>
#include <cstdio>

// =====================================================================
// Example 1: 3x3 Gaussian blur on a fixed-size grayscale image
//
// The point: a 2D stencil operation with a 2D kernel is *readable*
// with md_array_view.  Compare:
//     img[y * W + x]          -- flat buffer, manual stride
//     img[y][x]               -- C array, but can't pass generically
//     img(y, x)               -- md_array_view: clear, bounds-checked, passable
// =====================================================================

static constexpr std::size_t H = 8;
static constexpr std::size_t W = 12;

// Gaussian 3x3 kernel (σ ≈ 0.85), unnormalized weights
static constexpr double kernel[3][3] =
{
    {1.0, 2.0, 1.0},
    {2.0, 4.0, 2.0},
    {1.0, 2.0, 1.0}
};
static constexpr double kernel_sum = 16.0;

void gaussian_blur(md_array_view<const double, 2, H, W> src,
                   md_array_view<double, 2, H, W>       dst)
{
    auto k = make_md_view(kernel);

    // Interior pixels only (skip 1-pixel border)
    for (std::size_t y = 1; y + 1 < H; ++y)
    {
        for (std::size_t x = 1; x + 1 < W; ++x)
        {
            double acc = 0.0;
            for (int ky = -1; ky <= 1; ++ky)
            {
                for (int kx = -1; kx <= 1; ++kx)
                {
                    acc += src(y + ky, x + kx)
                         * k(static_cast<std::size_t>(ky + 1),
                             static_cast<std::size_t>(kx + 1));
                }
            }
            dst(y, x) = acc / kernel_sum;
        }
    }

    // Copy border pixels unchanged
    for (std::size_t x = 0; x < W; ++x)
    {
        dst(0, x)     = src(0, x);
        dst(H - 1, x) = src(H - 1, x);
    }
    for (std::size_t y = 0; y < H; ++y)
    {
        dst(y, 0)     = src(y, 0);
        dst(y, W - 1) = src(y, W - 1);
    }
}

void demo_blur()
{
    std::printf("=== Gaussian blur (8x12 image) ===\n\n");

    double image[H][W] = {};
    double blurred[H][W] = {};

    // Plant a bright spot in the center
    image[4][6] = 255.0;

    md_array_view src(image);
    md_array_view dst(blurred);

    gaussian_blur(src, dst);

    // Show the 5x5 region around the spot
    std::printf("  Original (rows 3-5, cols 5-8):\n  ");
    for (std::size_t y = 3; y <= 5; ++y)
    {
        for (std::size_t x = 5; x <= 8; ++x)
            std::printf("%7.1f", src(y, x));
        std::printf("\n  ");
    }

    std::printf("\n  Blurred:\n  ");
    for (std::size_t y = 3; y <= 5; ++y)
    {
        for (std::size_t x = 5; x <= 8; ++x)
            std::printf("%7.1f", dst(y, x));
        std::printf("\n  ");
    }
    std::printf("\n");
}

// =====================================================================
// Example 2: In-place LU decomposition (Doolittle, no pivoting)
//
// Operates on a fixed NxN matrix through md_array_view.  Shows how a
// numerical algorithm reads naturally with (i, j) indexing and how the
// view can be passed to subroutines without templates on raw arrays.
// =====================================================================

static constexpr std::size_t N = 4;

/// Doolittle LU decomposition in-place.
/// On exit A contains L (unit lower, diagonal implied 1) and U (upper).
void lu_decompose(md_array_view<double, 2, N, N> A)
{
    for (std::size_t k = 0; k < N; ++k)
    {
        // U row k (already in place for j >= k)
        // L column k
        for (std::size_t i = k + 1; i < N; ++i)
        {
            A(i, k) /= A(k, k);                         // L(i,k)
            for (std::size_t j = k + 1; j < N; ++j)
                A(i, j) -= A(i, k) * A(k, j);           // Schur complement
        }
    }
}

/// Forward-substitute  L y = b  (L has unit diagonal, stored below diag of LU).
void forward_sub(md_array_view<const double, 2, N, N> LU,
                 md_array_view<const double, 1, N>     b,
                 md_array_view<double, 1, N>           y)
{
    for (std::size_t i = 0; i < N; ++i)
    {
        double s = b(i);
        for (std::size_t j = 0; j < i; ++j)
            s -= LU(i, j) * y(j);
        y(i) = s;
    }
}

/// Back-substitute  U x = y  (U stored on/above diagonal of LU).
void back_sub(md_array_view<const double, 2, N, N> LU,
              md_array_view<const double, 1, N>     y,
              md_array_view<double, 1, N>           x)
{
    for (std::size_t i = N; i-- > 0; )
    {
        double s = y(i);
        for (std::size_t j = i + 1; j < N; ++j)
            s -= LU(i, j) * x(j);
        x(i) = s / LU(i, i);
    }
}

void demo_lu()
{
    std::printf("=== LU solve (4x4 system) ===\n\n");

    //  A x = b
    //
    //  A = | 2  3  1  5 |    b = | 10 |
    //      | 6 13  5  19|        | 38 |
    //      | 2 19 10  23|        | 51 |
    //      | 4 10  7  11|        | 22 |
    //
    //  Solution: x = (1, 1, 1, 1)

    double A[N][N] =
    {
        { 2,  3,  1,  5},
        { 6, 13,  5, 19},
        { 2, 19, 10, 23},
        { 4, 10,  7, 11}
    };
    double b[N] = {11, 43, 54, 32};
    double y[N] = {};
    double x[N] = {};

    // Create views — the algorithm doesn't need to know about raw arrays
    md_array_view mA(A);
    lu_decompose(mA);

    // After LU, mA holds both L and U in-place
    std::printf("  LU (combined):\n");
    for (std::size_t i = 0; i < N; ++i)
    {
        std::printf("    ");
        for (std::size_t j = 0; j < N; ++j)
            std::printf("%8.3f", mA(i, j));
        std::printf("\n");
    }

    forward_sub(mA, make_md_view(b), make_md_view(y));
    back_sub(mA, make_md_view(y), make_md_view(x));

    std::printf("\n  Solution:\n    ");
    auto vx = make_md_view(x);
    for (std::size_t i = 0; i < N; ++i)
        std::printf("x[%zu] = %.6f  ", i, vx(i));
    std::printf("\n\n");

    // Verify
    for (std::size_t i = 0; i < N; ++i)
    {
        if (std::fabs(vx(i) - 1.0) > 1e-10)
        {
            std::printf("  FAIL: x[%zu] = %f, expected 1.0\n", i, vx(i));
            return;
        }
    }
    std::printf("  Verified: all components == 1.0\n\n");
}

// =====================================================================
// Example 3: 3D finite-difference Laplacian (7-point stencil)
//
// A 3D scalar field on a small grid.  The view makes the triple-nested
// loop with neighbor offsets read exactly like the math:
//     ∇²u ≈ (u[i±1,j,k] + u[i,j±1,k] + u[i,j,k±1] - 6·u[i,j,k]) / h²
// =====================================================================

static constexpr std::size_t NX = 6;
static constexpr std::size_t NY = 6;
static constexpr std::size_t NZ = 6;

void laplacian_3d(md_array_view<const double, 3, NX, NY, NZ> u,
                  md_array_view<double, 3, NX, NY, NZ>       lap,
                  double h)
{
    const double inv_h2 = 1.0 / (h * h);

    for (std::size_t i = 1; i + 1 < NX; ++i)
    {
        for (std::size_t j = 1; j + 1 < NY; ++j)
        {
            for (std::size_t k = 1; k + 1 < NZ; ++k)
            {
                lap(i, j, k) = (u(i+1, j, k) + u(i-1, j, k)
                              + u(i, j+1, k) + u(i, j-1, k)
                              + u(i, j, k+1) + u(i, j, k-1)
                              - 6.0 * u(i, j, k)) * inv_h2;
            }
        }
    }
}

void demo_laplacian()
{
    std::printf("=== 3D Laplacian (6x6x6, 7-point stencil) ===\n\n");

    double field[NX][NY][NZ] = {};
    double lap[NX][NY][NZ]   = {};

    // Initialize with u(x,y,z) = x² + y² + z²
    // Analytic Laplacian: ∇²u = 2 + 2 + 2 = 6 everywhere
    const double h = 1.0;
    auto u = make_md_view(field);
    for (std::size_t i = 0; i < NX; ++i)
        for (std::size_t j = 0; j < NY; ++j)
            for (std::size_t k = 0; k < NZ; ++k)
                u(i, j, k) = static_cast<double>(i*i + j*j + k*k);

    laplacian_3d(u, make_md_view(lap), h);

    // Check interior: should all be exactly 6.0 for this quadratic field
    auto vl = make_md_view(lap);
    double max_err = 0.0;
    for (std::size_t i = 1; i + 1 < NX; ++i)
        for (std::size_t j = 1; j + 1 < NY; ++j)
            for (std::size_t k = 1; k + 1 < NZ; ++k)
                max_err = std::fmax(max_err, std::fabs(vl(i, j, k) - 6.0));

    std::printf("  Field: u(i,j,k) = i*i + j*j + k*k\n");
    std::printf("  Analytic Laplacian: 6.0 everywhere\n");
    std::printf("  Max |computed - analytic|: %.1e\n", max_err);
    std::printf("  Sample lap(2,3,4) = %.6f\n\n", vl(2, 3, 4));
}

// =====================================================================

int main()
{
    demo_blur();
    demo_lu();
    demo_laplacian();
}
