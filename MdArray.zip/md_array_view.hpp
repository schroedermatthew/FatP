#pragma once

// md_array_view.hpp
//
// A non-owning, zero-overhead view into fixed-size multidimensional C arrays.
// Deduces rank and dimensions from the array type via CTAD.
// Uses concepts to enforce that the number of indices matches the rank.
//
// Usage:
//     int arr[3][4][5] = {};
//     md_array_view v(arr);          // deduces md_array_view<int, 3, 3, 4, 5>
//     v(2, 1, 0) = 42;
//
//     const double m[8][8] = {};
//     auto cv = make_md_view(m);     // md_array_view<const double, 2, 8, 8>
//
// Note: constexpr element access works for rank-1 arrays.  For rank > 1,
// the language does not permit pointer arithmetic across sub-array boundaries
// in constant expressions, so operator() is usable only at runtime.

#include <array>
#include <cassert>
#include <concepts>
#include <cstddef>
#include <type_traits>
#include <utility>

// =====================================================================
// Forward declaration
// =====================================================================
template<typename T, std::size_t Rank, std::size_t... Dims>
    requires (sizeof...(Dims) == Rank)
class md_array_view;

// =====================================================================
// detail
// =====================================================================
namespace detail
{

// ----- flat_ptr: follow nested [0] subscripts to the first scalar -----
template<typename T>
constexpr auto flat_ptr(T& val) noexcept
    -> std::remove_all_extents_t<T>*
{
    if constexpr (std::is_array_v<T>)
        return flat_ptr(val[0]);
    else
        return &val;
}

// ----- build_array_t: reconstruct the C array type from element + dims -----
//       build_array_t<int, 3, 4, 5>  ==  int[3][4][5]
template<typename T, std::size_t... Dims>
struct build_array_type;

template<typename T>
struct build_array_type<T>
{
    using type = T;
};

template<typename T, std::size_t First, std::size_t... Rest>
struct build_array_type<T, First, Rest...>
{
    using type = typename build_array_type<T, Rest...>::type[First];
};

template<typename T, std::size_t... Dims>
using build_array_t = typename build_array_type<T, Dims...>::type;

// ----- extract_dims: peel dimensions off a C array type -----
//       md_view_for<int[3][4][5]>  ==  md_array_view<int, 3, 3, 4, 5>
template<typename Array, std::size_t... Accumulated>
struct extract_dims
{
    using type = md_array_view<Array, sizeof...(Accumulated), Accumulated...>;
};

template<typename T, std::size_t N, std::size_t... Accumulated>
struct extract_dims<T[N], Accumulated...>
    : extract_dims<T, Accumulated..., N>
{};

template<typename Array>
using md_view_for = typename extract_dims<Array>::type;

} // namespace detail

// =====================================================================
// md_array_view
// =====================================================================
template<typename T, std::size_t Rank, std::size_t... Dims>
    requires (sizeof...(Dims) == Rank)
class md_array_view
{
    static_assert(Rank > 0,
        "md_array_view requires at least one dimension");
    static_assert(((Dims > 0) && ...),
        "All dimensions must be non-zero");

public:
    // ----- type aliases -----
    using element_type  = T;
    using value_type    = std::remove_cv_t<T>;
    using pointer       = T*;
    using const_pointer = const T*;
    using reference     = T&;
    using size_type     = std::size_t;
    using rank_type     = std::size_t;

    /// The C array type that this view maps onto.
    using array_type = detail::build_array_t<element_type, Dims...>;

    // ----- construction -----

    md_array_view() = delete;

    /// Construct from a matching C array.
    constexpr md_array_view(array_type& arr) noexcept
        : data_{detail::flat_ptr(arr)}
    {}

    /// Construct from a raw pointer (caller guarantees at least size() elements).
    /// Static factory avoids ambiguity with the array constructor for rank-1
    /// arrays, where array_type decays to pointer.
    static constexpr md_array_view from_pointer(pointer p) noexcept
    {
        return md_array_view{p, ctor_tag{}};
    }

    constexpr md_array_view(const md_array_view&) noexcept            = default;
    constexpr md_array_view& operator=(const md_array_view&) noexcept = default;

    /// Converting constructor: md_array_view<T,...> → md_array_view<const T,...>
    template<typename U>
        requires (std::is_same_v<T, const U> && !std::is_const_v<U>)
    constexpr md_array_view(md_array_view<U, Rank, Dims...> other) noexcept
        : data_{other.data()}
    {}

    // ----- static queries -----

    static constexpr rank_type rank() noexcept { return Rank; }

    static constexpr size_type extent(rank_type r) noexcept
    {
        return dims_array[r];
    }

    /// Product of all dimensions.
    static constexpr size_type size() noexcept
    {
        return (Dims * ...);
    }

    /// Row-major stride for dimension r.
    static constexpr size_type stride(rank_type r) noexcept
    {
        return strides_array[r];
    }

    /// Always false — zero-extent dimensions are rejected at compile time.
    static constexpr bool empty() noexcept { return false; }

    // ----- element access -----

    /// Multi-index access.  Number of indices must equal Rank (concept-enforced).
    /// Requires std::integral to reject pointers and floating-point types;
    /// signed negative values are caught by the bounds check in debug builds.
    template<std::integral... Indices>
        requires (sizeof...(Indices) == Rank)
    constexpr reference operator()(Indices... indices) const noexcept
    {
        assert(((indices >= Indices{0}) && ...) &&
               "md_array_view: negative index");
        const std::array<size_type, Rank> idx{static_cast<size_type>(indices)...};
        check_bounds(idx);
        return data_[linear_offset(std::make_index_sequence<Rank>{}, idx)];
    }

    /// Array-index access for generic code that builds index packs
    /// programmatically rather than expanding parameter packs.
    constexpr reference operator[](const std::array<size_type, Rank>& idx) const noexcept
    {
        check_bounds(idx);
        return data_[linear_offset(std::make_index_sequence<Rank>{}, idx)];
    }

    // ----- observers -----

    constexpr pointer data() const noexcept { return data_; }

private:
    pointer data_;

    struct ctor_tag {};
    constexpr md_array_view(pointer p, ctor_tag) noexcept : data_{p} {}

    // ----- compile-time tables -----

    static constexpr std::array<size_type, Rank> dims_array{Dims...};

    static constexpr std::array<size_type, Rank> make_strides() noexcept
    {
        std::array<size_type, Rank> s{};
        s[Rank - 1] = 1;
        for (size_type i = Rank - 1; i > 0; --i)
            s[i - 1] = s[i] * dims_array[i];
        return s;
    }

    static constexpr std::array<size_type, Rank> strides_array = make_strides();

    // ----- offset computation -----

    template<std::size_t... Is>
    static constexpr size_type linear_offset(
        std::index_sequence<Is...>,
        const std::array<size_type, Rank>& idx) noexcept
    {
        return ((idx[Is] * strides_array[Is]) + ...);
    }

    static constexpr void check_bounds(
        [[maybe_unused]] const std::array<size_type, Rank>& idx) noexcept
    {
        for ([[maybe_unused]] size_type i = 0; i < Rank; ++i)
            assert(idx[i] < dims_array[i] && "md_array_view: index out of bounds");
    }
};

// =====================================================================
// CTAD — explicit deduction guides for ranks 1 through 8
//
// The !is_array_v<T> constraint ensures only the guide matching the
// exact rank fires (e.g. int[2][3] won't match the rank-1 guide with
// T deduced as int[3]).
// =====================================================================

template<typename T, std::size_t A>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A])
    -> md_array_view<T, 1, A>;

template<typename T, std::size_t A, std::size_t B>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A][B])
    -> md_array_view<T, 2, A, B>;

template<typename T, std::size_t A, std::size_t B, std::size_t C>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A][B][C])
    -> md_array_view<T, 3, A, B, C>;

template<typename T, std::size_t A, std::size_t B, std::size_t C, std::size_t D>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A][B][C][D])
    -> md_array_view<T, 4, A, B, C, D>;

template<typename T, std::size_t A, std::size_t B, std::size_t C, std::size_t D,
         std::size_t E>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A][B][C][D][E])
    -> md_array_view<T, 5, A, B, C, D, E>;

template<typename T, std::size_t A, std::size_t B, std::size_t C, std::size_t D,
         std::size_t E, std::size_t F>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A][B][C][D][E][F])
    -> md_array_view<T, 6, A, B, C, D, E, F>;

template<typename T, std::size_t A, std::size_t B, std::size_t C, std::size_t D,
         std::size_t E, std::size_t F, std::size_t G>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A][B][C][D][E][F][G])
    -> md_array_view<T, 7, A, B, C, D, E, F, G>;

template<typename T, std::size_t A, std::size_t B, std::size_t C, std::size_t D,
         std::size_t E, std::size_t F, std::size_t G, std::size_t H>
    requires (!std::is_array_v<T>)
md_array_view(T(&)[A][B][C][D][E][F][G][H])
    -> md_array_view<T, 8, A, B, C, D, E, F, G, H>;

// =====================================================================
// Factory (works for any rank via the extract_dims trait)
// =====================================================================
template<typename Array>
    requires std::is_array_v<Array>
constexpr auto make_md_view(Array& arr) noexcept
{
    return detail::md_view_for<Array>{arr};
}
