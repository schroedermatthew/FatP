# ServiceLocator Comprehensive Analysis (Corrected)

**Component:** `fat_p::ServiceLocator`  
**Version:** API stability "in_work"  
**Analysis Date:** January 2026  
**Benchmark Platform:** Windows, 24 threads, 3686 MHz base clock

---

## Executive Summary

The `fat_p::ServiceLocator` is a policy-based service locator. Measured performance: 2.75 ns/op unnamed resolve (no stats), 1.44 ns/op MRU cache hit, on Windows/24-thread/3686 MHz. Compare against EnTT static global baseline of 1.19 ns/op. This analysis is based on the provided `ServiceLocator.h` and `benchmark_results_ServiceLocator.txt`.

### Measured Performance Characteristics

| Operation | Latency | Notes |
|-----------|---------|-------|
| Unnamed resolve (no stats) | 2.75 ns | End-to-end `tryResolve<T>()` |
| Unnamed resolve (atomic stats) | 5.20 ns | +2.45 ns for atomic increments |
| Thread-safe resolve (no stats) | 11.11 ns | SharedMutexPolicy overhead |
| Named resolve | 24.56 ns | No cache support |
| MRU cache hit | 1.44 ns | Bypasses hash lookup |
| Direct pointer (baseline) | 1.19 ns | Absolute lower bound |
| StableHashMap lookup floor | 1.24 ns | Benchmark item #27 |

### Key Strengths
- Two-level storage separates unnamed (fast) from named (flexible) services
- Thread-local MRU cache bypasses locks entirely on hit
- Singleton factory serialization with cycle detection
- Policy-based architecture with 5 orthogonal extension points

### Primary Gaps

| Gap | Impact | Effort |
|-----|--------|--------|
| DSO/plugin instability | Blocks plugin architectures | **High** (requires key-type redesign) |
| ~80 lines resolution duplication | Maintenance burden | Medium |
| Named services bypass MRU cache | 17x slower than cached unnamed | Medium |
| `const_cast` in `writeLock() const` | Potential UB | Low |

### Critical Contract: Thread-Safe Cached Variants

**`ThreadSafeHotLoopServiceLocator` users must understand:**

Cache hits bypass the `shared_mutex` entirely. This is safe **only if** registration/unregistration/clear operations are:
1. Performed during startup/shutdown, OR
2. Quiesced (no concurrent resolves)

Violating this contract causes data races. This is documented in the header but must be prominent in any usage guide.

---

## Table of Contents

1. [Migration Checklist Alignment](#1-migration-checklist-alignment)
2. [Architecture Review](#2-architecture-review)
3. [Performance Analysis](#3-performance-analysis)
4. [MRU Cache Deep Dive](#4-mru-cache-deep-dive)
5. [Proposed Improvements](#5-proposed-improvements)

---

## 1. Migration Checklist Alignment

This section evaluates ServiceLocator against the C→Modern C++ migration checklist defined in `procedure.md` (provided separately). Item numbers correspond to that document's execution order.

### 1.1 Compliance Matrix

| # | Checklist Item | Implementation | Assessment |
|---|----------------|----------------|------------|
| 1 | **C-API boundaries** | N/A (pure C++) | — |
| 2 | **Service Locator strategy** | Policy-based with scoped overrides | Meets requirement |
| 3 | **Namespace hierarchy** | `fat_p::` with `detail::` internal | Meets requirement |
| 4 | **Error handling** | `Expected<T, ServiceErrorInfo>` with `[[nodiscard]]` | Meets requirement |
| 5 | **Contracts** | `FATP_ENFORCE` macros, `static_assert` | Meets requirement |
| 6 | **Memory/RAII** | `Scope`, `Registration` RAII helpers | Meets requirement |
| 7 | **Concurrency** | Policy-driven, documented thread-safety matrix | Meets requirement |
| 8 | **Feature selection** | `std::function` for factories, `shared_ptr` for ownership | Meets requirement |
| 9 | **Tooling** | Not evaluated | Unknown |
| 10 | **Testing** | `test_ServiceLocator.cpp` referenced | Exists |
| 11 | **Performance loop** | Comprehensive benchmarks provided | Meets requirement |
| 14 | **Avoidances** | No raw `new`/`delete`, explicit casts | Meets requirement |

---

## 2. Architecture Review

### 2.1 Policy-Based Design

```cpp
template <
    typename ConcurrencyPolicy = SingleThreadedPolicy,
    typename RegistrationPolicy = ServicePreventOverwritePolicy,
    typename StatisticsPolicy = NoServiceLocatorStatisticsPolicy,
    typename TypeKeyPolicy = detail::DefaultServiceTypeKeyPolicy,
    typename ResolveCachePolicy = NoServiceLocatorResolveCachePolicy
>
class ServiceLocator;
```

| Policy | Purpose | Default |
|--------|---------|---------|
| `ConcurrencyPolicy` | Lock strategy | `SingleThreadedPolicy` |
| `RegistrationPolicy` | Overwrite behavior | `ServicePreventOverwritePolicy` |
| `StatisticsPolicy` | Usage counters | `NoServiceLocatorStatisticsPolicy` |
| `TypeKeyPolicy` | Type identification | `DefaultServiceTypeKeyPolicy` |
| `ResolveCachePolicy` | Hot-path cache | `NoServiceLocatorResolveCachePolicy` |

### 2.2 Two-Level Storage

```cpp
using UnnamedRegistry = StableHashMap<const void*, ServiceEntry, TypeIdHash>;
using NamedRegistry = StableHashMap<ServiceKey, ServiceEntry, ServiceKeyHash, ServiceKeyEq>;
```

**Design rationale:** Unnamed services (majority case) avoid string allocation and use a simpler hash. Named services pay for composite key overhead only when needed.

### 2.3 Ownership Model

| Mode | Storage | Ownership | Use Case |
|------|---------|-----------|----------|
| `registerInstance<T>(T&)` | Raw pointer | Caller owns | Stack/static objects |
| `registerShared<T>(shared_ptr<T>)` | `shared_ptr<void>` | Shared | Heap objects |
| `registerFactory<T>(F, Lifetime)` | `std::function` | Locator creates | Lazy init, transient |

### 2.4 Singleton Factory Gate

The `SingletonFactoryGate` (lines 572-636) provides:
- Exactly-once execution per registration
- Re-entrancy: factory can resolve other services
- Cycle detection: returns `ServiceError::CircularDependency`
- Cross-thread serialization via mutex + condition variable

---

## 3. Performance Analysis

### 3.1 End-to-End Resolution Latency

From `benchmark_results_ServiceLocator.txt`, SINGLE-TYPE RESOLUTION section:

```
fat_p::DefaultServiceLocator (no stats):       2.75 ns/op
fat_p::DefaultServiceLocator (atomic stats):   5.20 ns/op
fat_p::ThreadSafeServiceLocator (no stats):   11.11 ns/op
fat_p::ThreadSafeServiceLocator (atomic stats):14.15 ns/op
entt::locator (static global):                 1.19 ns/op
std::unordered_map<type_index>:               12.06 ns/op
Direct pointers (baseline):                    1.19 ns/op
```

### 3.2 Component Costs (Microbenchmarks)

From OVERHEAD ISOLATION section:

| Component | Time (ns) | Notes |
|-----------|-----------|-------|
| Direct pointer access | 1.27 | Absolute baseline |
| TypeKeyPolicy (static addr) | 1.26 | Type ID computation |
| **StableHashMap&lt;void*&gt; find** | **1.20** | Unnamed lookup component |
| **StableHashMap&lt;ServiceKey&gt; find** | **5.71** | Named lookup component |
| std::type_index construction | 9.87 | RTTI overhead |
| SharedMutexPolicy lock_shared() | 10.90 | Lock acquisition |
| std::shared_ptr copy | 8.96 | Atomic refcount |

**Important:** The 1.20 ns and 5.71 ns figures are **StableHashMap find costs**, not end-to-end resolve. End-to-end unnamed resolve is 2.75 ns; end-to-end named resolve is 24.56 ns.

### 3.3 Named Service Overhead Breakdown

Named resolve at 24.56 ns vs unnamed at 2.75 ns (8.9x ratio).

**Likely contributors** (inferred from design; not individually benchmarked):
- ServiceKey construction with string copy
- Composite hash computation (type + string)
- String comparison on hash collision
- No MRU cache support

### 3.4 MRU Cache Impact

```
Pattern          | Default (ns) | MRU2 (ns) | Speedup
─────────────────────────────────────────────────────
AAAA (repeat)    |    2.37      |   1.44    |  1.65x
ABAB (alternate) |    2.33      |   1.48    |  1.57x
```

The 0.04 ns difference between patterns confirms the ABAB-friendly index flip works.

---

## 4. MRU Cache Deep Dive

### 4.1 Structure

```cpp
struct Entry {
    const void* owner;    // 8 bytes
    const void* typeId;   // 8 bytes
    const void* service;  // 8 bytes
    std::uint64_t epoch;  // 8 bytes
};  // 32 bytes per entry

struct Cache {
    Entry e0{};           // 32 bytes
    Entry e1{};           // 32 bytes
    std::uint8_t mruIndex; // 1 byte + 7 padding
};  // ~72 bytes total per thread
```

### 4.2 Design Decisions

| Decision | Rationale |
|----------|-----------|
| Thread-local storage | Zero contention on cache access |
| Epoch invalidation | O(1) invalidation regardless of cache population |
| 2-slot limit | Covers AAAA and ABAB patterns; more slots add overhead |
| Index flip vs entry swap | ABAB pattern doesn't thrash cache |
| `constinit` (C++20) | Avoids TLS init guard overhead |

### 4.3 Limitation: Named Services

The cache keys on `(owner, typeId)` only. Named services always miss cache, paying 24.56 ns vs 1.44 ns. This is documented behavior, not a bug.

**Extension opportunity:** Hash-based named cache (see §5.2).

### 4.4 Safety Contract

For `ThreadSafeHotLoopServiceLocator`:

```
┌─────────────────────────────────────────────────────────────────┐
│ CRITICAL: Cache hits bypass shared_mutex.                       │
│                                                                 │
│ Safe usage requires ONE of:                                     │
│   1. Registration only at startup (before concurrent resolves)  │
│   2. Quiesce all resolve threads before registration changes    │
│                                                                 │
│ Concurrent registration + cached resolve = DATA RACE            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 5. Proposed Improvements

### 5.1 DSO-Safe TypeKeyPolicy — REDESIGN REQUIRED

**Problem:** `DefaultServiceTypeKeyPolicy` returns `&kServiceTypeToken<T>`, a template variable address. Different DSOs have different addresses for the same type.

**Why a simple policy swap doesn't work:**

The `UnnamedRegistry` is:
```cpp
StableHashMap<const void*, ServiceEntry, TypeIdHash>
```

`TypeIdHash` hashes the **pointer value**:
```cpp
size_t operator()(const void* p) const noexcept {
    return hashPtr(p);  // Hashes the address, not pointed-to content
}
```

If a DSO-safe policy returns a pointer to a `std::type_index` or `TypeGuid`, the map still hashes that **pointer's address**, not its contents. Different DSOs → different pointers → lookup fails.

**Required changes for true DSO safety:**

| Option | Change Required | Tradeoff |
|--------|-----------------|----------|
| A. Value-type key | Change `UnnamedRegistry` to `StableHashMap<TypeGuid, ...>` or `StableHashMap<std::type_index, ...>` | Larger key, different hash/eq |
| B. Interned handles | Global registry that maps type identifiers to stable handles | Additional indirection, init order issues |
| C. RTTI with `type_info::hash_code()` | Use hash directly as key (not pointer) | RTTI required, hash collision handling |

**Effort estimate:** Medium-to-high. This is a structural change to ServiceLocator, not a policy swap.

**Recommendation:** File as separate design ticket. Document current limitation clearly.

### 5.2 Named Service MRU Cache — PROPOSAL

**Goal:** Reduce named resolve from 24.56 ns to ~3-5 ns on cache hit.

**Approach:** Hash-based keying without storing the name string:

```cpp
struct NamedCacheEntry {
    const void* owner;       // 8 bytes
    const void* typeId;      // 8 bytes
    std::uint64_t nameHash;  // 8 bytes (FNV-1a)
    std::uint32_t nameLen;   // 4 bytes (collision reduction)
    std::uint32_t epoch;     // 4 bytes (narrowed)
    const void* service;     // 8 bytes
};  // 40 bytes per entry
```

**API change (backward compatible):**
```cpp
// Add default parameter to existing interface
static T* tryGet(..., std::string_view name = {});
static void put(..., std::string_view name = {});
```

**Status:** Proposal. Requires implementation, testing, and benchmarking.

### 5.3 Resolution Method Refactor — PROPOSAL

**Problem:** `tryResolve`, `resolveExpected`, `resolveSharedExpected` duplicate ~80 lines each.

**Proposed solution:** Single `resolveInternal<T>()` returning a result struct, with thin public wrappers.

**Status:** Proposal. Before implementation:
1. Define behavioral equivalence test suite covering:
   - All entry kinds (Instance, Shared, Factory)
   - All lifetimes (Singleton, Transient)
   - All error conditions
   - Cache behavior (hit, miss, invalidation)
   - Parent chain traversal
2. Implement refactor
3. Verify all tests pass
4. Benchmark to confirm no regression (claim of "~0.3 ns" is **unproven** until measured)

### 5.4 Fix `const_cast` UB — LOW EFFORT

**Location:** Line 1636

```cpp
[[nodiscard]] auto writeLock() const {
    auto& policy = const_cast<ConcurrencyPolicy&>(...);  // UB if *this is const
    return policy.lock();
}
```

**Fix:** Remove this const overload. Mutation paths (singleton creation) should use non-const `this`. The only caller is `resolveOrCreateSingleton`, which can be restructured.

---

## Appendix A: Benchmark Reference

### A.1 End-to-End Resolution (Primary Metrics)

| Configuration | Median (ns/op) |
|---------------|----------------|
| Direct pointer baseline | 1.19 |
| EnTT static global | 1.19 |
| MRU cache hit | 1.44 |
| DefaultServiceLocator (no stats) | 2.75 |
| DefaultServiceLocator (atomic stats) | 5.20 |
| ThreadSafeServiceLocator (no stats) | 11.11 |
| std::unordered_map<type_index> | 12.06 |
| Named resolve | 24.56 |

### A.2 Component Costs (For Analysis Only)

| Component | Time (ns) |
|-----------|-----------|
| StableHashMap&lt;void*&gt; find | 1.20 |
| StableHashMap&lt;ServiceKey&gt; find | 5.71 |
| TypeKeyPolicy | 1.26 |
| SharedMutexPolicy lock_shared | 10.90 |

### A.3 MRU Cache Patterns

| Pattern | Without Cache (ns) | With MRU2 (ns) |
|---------|-------------------|----------------|
| AAAA | 2.37 | 1.44 |
| ABAB | 2.33 | 1.48 |

---

## Appendix B: Code Locations

| Feature | Lines in ServiceLocator.h |
|---------|---------------------------|
| `ServiceError` enum | 155-166 |
| Statistics policies | 230-327 |
| MRU cache policy | 385-504 |
| `DefaultServiceTypeKeyPolicy` | 512-520 |
| `SingletonFactoryGate` | 572-636 |
| Registration methods | 704-836 |
| `tryResolve` | 929-1063 |
| `ServiceEntry` struct | 1589-1607 |
| `Scope` RAII helper | 1907-1943 |
| `Registration` RAII helper | 1949-2063 |

---

## Appendix C: Dependency Verification (Updated)

The dependencies have been **verified against actual source code**:

### ConcurrencyPolicies.h (2502 lines)

**19 total policies**, not just 2:
- `SingleThreadedPolicy` — Empty `LockGuard` struct (true zero-cost)
- `SharedMutexPolicy` — Custom nested guard types (not raw `std::unique_lock`)
- Plus: MutexSynchronizationPolicy, SpinlockSynchronizationPolicy, TicketLockPolicy, MCSLockPolicy, SeqLockPolicy, RCUPolicy, HazardPointerPolicy, AdaptiveLockPolicy, RecursiveMutexPolicy, TimedMutexPolicy, SharedTimedMutexPolicy, and more

**Key features verified:**
- `try_lock()` and `try_lock_shared()` methods present
- Contention tracking interface (`get_contention()`)
- Comprehensive trait system (`is_shared_policy_v`, `supports_try_lock_v`, etc.)
- C++20 concept definition

### StableHashMap.h (1613 lines)

**Reference stability guarantee verified:**
- Nodes are separately allocated, never moved on rehash
- `erase()` invalidates only the erased entry's pointer
- SIMD acceleration: SSE2, AVX2, NEON, scalar fallback
- H2 extraction uses high bits (avoids correlation with bucket index)

**See:** `ServiceLocator_DependencyReview_Verified.md` for full details.

---

## Appendix D: Open Questions (Remaining)

1. **Benchmark reproducibility** — Numbers are from a single Windows run. Cross-platform validation recommended.

2. **ASan/TSan integration** — Unknown whether sanitizers are part of CI. Recommended for concurrency validation.

---

*End of Corrected Analysis*
