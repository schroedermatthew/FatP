/**
 * @file ServiceLocator_DsoSafeTypeKeyPolicy_Proposal.h
 * @brief DSO-Safe Type Identification — DESIGN PROPOSAL (NOT DROP-IN)
 *
 * ============================================================================
 * IMPORTANT: THIS IS A DESIGN PROPOSAL, NOT A DROP-IN POLICY FILE
 * ============================================================================
 *
 * The current ServiceLocator cannot be made DSO-safe by simply swapping
 * TypeKeyPolicy. This document explains why and proposes architectural changes.
 *
 * PROBLEM STATEMENT
 * =================
 *
 * DefaultServiceTypeKeyPolicy uses template variable addresses:
 *
 *     template <typename T>
 *     inline constexpr unsigned char kServiceTypeToken = 0;
 *
 *     template <typename T>
 *     static const void* typeId() { return &kServiceTypeToken<T>; }
 *
 * Different DSOs (shared libraries) get different addresses for the same type.
 * Service registered in libA.so cannot be resolved from libB.so.
 *
 * WHY A SIMPLE POLICY SWAP DOESN'T WORK
 * =====================================
 *
 * The UnnamedRegistry is defined as:
 *
 *     StableHashMap<const void*, ServiceEntry, TypeIdHash>
 *
 * TypeIdHash hashes the POINTER VALUE:
 *
 *     size_t operator()(const void* p) const noexcept {
 *         return hashPtr(p);  // Hashes the address itself
 *     }
 *
 * If we create a "DSO-safe policy" that returns a pointer to a std::type_index
 * or TypeGuid, the map still hashes that pointer's ADDRESS, not its CONTENTS.
 *
 * Example of what DOESN'T work:
 *
 *     // In libA.so:
 *     static std::type_index idx_A{typeid(ILogger)};
 *     locator.registerShared<ILogger>(impl);  // key = &idx_A
 *
 *     // In libB.so:
 *     static std::type_index idx_B{typeid(ILogger)};  // DIFFERENT ADDRESS
 *     locator.tryResolve<ILogger>();  // looks for &idx_B, not &idx_A → MISS
 *
 * Even though idx_A == idx_B (same type_index value), &idx_A != &idx_B.
 *
 * ARCHITECTURAL OPTIONS
 * =====================
 *
 * To achieve true DSO safety, one of these changes is required:
 */

#pragma once

#include <cstdint>
#include <typeindex>
#include <typeinfo>

namespace fat_p
{
namespace dso_proposal
{

// ============================================================================
// OPTION A: Change UnnamedRegistry Key Type to std::type_index
// ============================================================================
//
// CHANGE REQUIRED IN ServiceLocator.h:
//
//     // Before:
//     using UnnamedRegistry = StableHashMap<const void*, ServiceEntry, TypeIdHash>;
//
//     // After:
//     using UnnamedRegistry = StableHashMap<std::type_index, ServiceEntry>;
//
// Then the policy returns type_index by VALUE:
//
//     struct TypeIndexKeyPolicy {
//         template <typename T>
//         static std::type_index typeId() {
//             return std::type_index{typeid(T)};
//         }
//     };
//
// TRADEOFFS:
//   + Simplest change
//   + std::type_index comparison commonly works across DSOs on mainstream ABIs
//     (GCC/Clang/MSVC on Linux/Windows/macOS); validate on target platforms
//   - Requires RTTI (-fno-rtti breaks this)
//   - type_index is larger than void* (typically 8 bytes, but involves vtable lookup)
//   - Benchmark shows type_index construction costs ~9.87 ns
//
// PERFORMANCE IMPACT:
//   Unnamed resolve would go from 2.75 ns to ~12+ ns (type_index construction
//   + hash + comparison). Significant regression.

// ============================================================================
// OPTION B: Use Hash-as-Key (Avoid Pointer Comparison Entirely)
// ============================================================================
//
// CHANGE REQUIRED IN ServiceLocator.h:
//
//     using TypeHash = std::uint64_t;
//     using UnnamedRegistry = StableHashMap<TypeHash, ServiceEntry>;
//
// Policy computes a stable hash from type identity:
//
//     struct HashKeyPolicy {
//         template <typename T>
//         static std::uint64_t typeId() {
//             // Option B1: Use RTTI hash_code (DSO-stable on most ABIs)
//             return typeid(T).hash_code();
//
//             // Option B2: Use compile-time string hash of __PRETTY_FUNCTION__
//             // (GCC/Clang) or __FUNCSIG__ (MSVC)
//             return fnv1a(__PRETTY_FUNCTION__);
//         }
//     };
//
// TRADEOFFS:
//   + No pointer comparison—hash IS the key
//   + hash_code() is typically fast (~1-2 ns)
//   - Hash collisions become silent bugs (different types with same hash)
//   - Collision handling requires secondary check (store type_index alongside?)
//   - __PRETTY_FUNCTION__ approach is compiler-specific
//
// COLLISION RISK:
//   std::type_info::hash_code() is NOT guaranteed collision-free by the standard.
//   In practice, collisions are rare, but possible. A production implementation
//   should store the full type_index and compare on hash collision.

// ============================================================================
// OPTION C: GUID-Based with Value Key
// ============================================================================
//
// CHANGE REQUIRED IN ServiceLocator.h:
//
//     struct TypeGuid { uint64_t high; uint64_t low; };
//     using UnnamedRegistry = StableHashMap<TypeGuid, ServiceEntry, GuidHash, GuidEq>;
//
// Policy requires explicit GUID declaration per service:
//
//     class ILogger {
//     public:
//         static constexpr TypeGuid kTypeGuid{0x550e8400e29b41d4, 0xa716446655440000};
//     };
//
//     struct GuidKeyPolicy {
//         template <typename T>
//         static TypeGuid typeId() {
//             return T::kTypeGuid;  // Returns by VALUE
//         }
//     };
//
// TRADEOFFS:
//   + Fastest option (16-byte value comparison)
//   + No RTTI required
//   + Zero collision risk with proper GUID generation
//   - Requires explicit GUID on every service type
//   - Migration burden for existing code

struct TypeGuid
{
    std::uint64_t high;
    std::uint64_t low;

    constexpr bool operator==(const TypeGuid& other) const noexcept
    {
        return high == other.high && low == other.low;
    }
};

struct GuidHash
{
    std::size_t operator()(const TypeGuid& g) const noexcept
    {
        // XOR high and low; apply finalizer
        std::uint64_t h = g.high ^ g.low;
        h ^= h >> 33;
        h *= 0xff51afd7ed558ccdULL;
        h ^= h >> 33;
        return static_cast<std::size_t>(h);
    }
};

// ============================================================================
// OPTION D: Interned Handle Registry (Most Complex)
// ============================================================================
//
// A global registry maps type identifiers to stable handles:
//
//     class TypeRegistry {
//         std::unordered_map<std::type_index, uint32_t> mTypeToHandle;
//         std::mutex mMutex;
//         std::atomic<uint32_t> mNextHandle{1};
//     public:
//         static TypeRegistry& instance();
//
//         template <typename T>
//         uint32_t getHandle() {
//             static uint32_t handle = registerType<T>();
//             return handle;
//         }
//     };
//
// ServiceLocator uses uint32_t as key:
//
//     using UnnamedRegistry = StableHashMap<uint32_t, ServiceEntry>;
//
// TRADEOFFS:
//   + Smallest key size (4 bytes)
//   + Works across DSOs (handles are program-global)
//   - Requires RTTI for initial registration
//   - Global state + mutex for registration
//   - Static init order issues if services registered at static init time
//   - Handle exhaustion after 4B types (theoretical, not practical)

// ============================================================================
// RECOMMENDATION
// ============================================================================
//
// For most use cases: OPTION A (type_index key) or OPTION C (GUID key)
//
// Decision matrix:
//
// | Scenario                      | Recommended Option |
// |-------------------------------|--------------------|
// | RTTI available, simplicity    | A (type_index)     |
// | No RTTI, willing to add GUIDs | C (GUID)           |
// | Maximum performance needed    | C (GUID)           |
// | Existing large codebase       | A (type_index)     |
//
// IMPLEMENTATION STEPS
// ====================
//
// 1. Choose option based on constraints
//
// 2. Modify ServiceLocator.h:
//    - Change UnnamedRegistry key type
//    - Update hash/equality functors
//    - Update TypeKeyPolicy to return value (not pointer)
//
// 3. Update NamedRegistry similarly (ServiceKey needs same treatment)
//
// 4. Add static_assert or SFINAE to enforce policy compatibility
//
// 5. Provide migration aliases:
//    using DsoSafeServiceLocator = ServiceLocator<..., TypeIndexKeyPolicy, ...>;
//
// 6. Benchmark to measure performance impact
//
// 7. Document new constraints (RTTI requirement, GUID requirement, etc.)
//
// EFFORT ESTIMATE: Medium-to-High (2-4 days implementation + testing)
//
// This is not a policy swap—it's a ServiceLocator key-type redesign.

// ============================================================================
// PLACEHOLDER: Example Policy Interfaces (for future implementation)
// ============================================================================

// These are INTERFACE SKETCHES, not working code.
// They show what the policies would look like after the registry changes.

namespace future
{

// After Option A is implemented:
struct TypeIndexKeyPolicy
{
    template <typename T>
    static std::type_index typeId()
    {
        return std::type_index{typeid(T)};
    }
};

// After Option C is implemented:
struct GuidKeyPolicy
{
    template <typename T>
    static TypeGuid typeId()
    {
        // T must have: static constexpr TypeGuid kTypeGuid
        return T::kTypeGuid;
    }
};

} // namespace future

} // namespace dso_proposal
} // namespace fat_p

// ============================================================================
// MACRO PLACEHOLDERS (for future Option C implementation)
// ============================================================================

// Usage: FATP_DECLARE_SERVICE_GUID(ILogger, 0x550e8400e29b41d4, 0xa716446655440000)
#define FATP_DECLARE_SERVICE_GUID(Type, high_val, low_val) \
    static constexpr ::fat_p::dso_proposal::TypeGuid kTypeGuid{high_val, low_val}
