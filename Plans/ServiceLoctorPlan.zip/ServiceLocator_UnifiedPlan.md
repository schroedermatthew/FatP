# ServiceLocator — Unified Implementation Plan

**Scope:** Code improvements + procedure.md alignment  
**Principle:** Documentation describes what exists; code delivers what's promised  
**Status:** Phase 1 COMPLETE

---

## Completed Items ✅

| ID | Item | Status |
|----|------|--------|
| D1 | Fix "runtime linker" → "centralized registry" | ✅ Done |
| D2 | Replace "Runtime flexibility" with "Test/config substitution" | ✅ Done |
| D3 | Compress SL vs DI table to 4 migration-relevant rows | ✅ Done |
| D4 | Add migration-specific anti-DI paragraph | ✅ Done |
| D5 | Fix Step 12 (remove "tutorial" language) | ✅ Done |
| A1 | Document const_cast rationale in writeLock() | ✅ Done |
| A2 | Add policy trait static_asserts | ✅ Done |

---

## Remaining Items

| ID | Item | Track | Risk | Effort | Value |
|----|------|-------|------|--------|-------|
| **B1** | Resolution method refactor | Code | Medium | 1 week | Maintainability |
| **B2** | Named service MRU cache | Code | Medium | 1 week | 7x named lookup speedup |
| **C1** | DSO-safe TypeKeyPolicy | Code | High | 2-4 days | Plugin support (if needed) |

---

## Analysis: How the Two Plans Interact

| Code Plan Item | Doc Plan Implication |
|----------------|---------------------|
| DSO-safe TypeKeyPolicy | Doc plan removes "runtime linker" language → **DSO-safe is only needed if you actually have plugins**, not because the doc promises it |
| Named MRU cache | Doc plan narrows to "test/config substitution" → **cache is a performance win**, not a "runtime flexibility" feature |
| Resolution refactor | Doc plan doesn't mention internals → **pure code quality**, proceed as planned |
| const_cast fix | Doc plan doesn't mention → **correctness**, proceed as planned |

**Key insight:** The doc plan's removal of "runtime hot swap" language means C1 (DSO-safe) is correctly deferred unless there's a concrete plugin use case. The doc shouldn't promise what the code doesn't deliver.

---

## Merged Priority Matrix

| ID | Item | Track | Risk | Effort | Value |
|----|------|-------|------|--------|-------|
| **D1** | Fix "runtime linker" / "hot swap" language | Doc | Low | 0.5 day | Removes false promises |
| **D2** | Compress SL vs DI table | Doc | Low | 0.5 day | Focuses on migration value |
| **D3** | Add migration-specific anti-DI paragraph | Doc | Low | 0.5 day | Strengthens argument |
| **D4** | Remove "how-to add service" from Step 12 | Doc | Low | 0.25 day | Prevents scope creep |
| **A1** | Fix `const_cast` UB | Code | Low | 0.5 day | Correctness |
| **A2** | Add policy trait static_asserts | Code | Low | 0.5 day | Compile-time safety |
| **B1** | Resolution method refactor | Code | Medium | 1 week | Maintainability |
| **B2** | Named service MRU cache | Code | Medium | 1 week | 7x named lookup speedup |
| **C1** | DSO-safe TypeKeyPolicy | Code | High | 2-4 days | Plugin support (if needed) |

---

## Phase 1: Alignment (Week 1, Days 1-2)

**Goal:** Make documentation and code consistent. Remove promises code doesn't keep.

### D1. Fix "Runtime Linker" Language

**Location:** procedure.md, Step 2

**Before:**
> "acts as a runtime linker for dependencies"

**After:**
> "acts as a centralized registry to avoid signature churn during migration"

**Rationale:** "Runtime linker" implies dynamic rebinding. The actual value is avoiding constructor parameter explosion.

---

### D2. Replace "Runtime Flexibility" Row in SL vs DI Table

**Location:** procedure.md, SL vs DI comparison table

**Before:**
> "Runtime flexibility… replaced at runtime by re-registering"

**After:**
| Aspect | Service Locator | Dependency Injection |
|--------|-----------------|---------------------|
| Test/config substitution | Register mocks at test setup or configure at startup | Thread through constructors or use DI container |

**Rationale:** Preserves the only swapping that matters (test mocks, startup config) without promising production hot-swap.

---

### D3. Compress SL vs DI Table

**Keep only migration-relevant rows:**
1. Signature bloat
2. Migration surface area / churn
3. Visibility / auditability (phrased as "auditable via code search")
4. Test/config substitution
5. Performance (careful phrasing)

**Remove or inline:**
- "Ownership & lifetime" → too design-spec-ish
- "Ravioli code trap" → keep as one-liner warning, not full row

---

### D4. Add Migration-Specific Anti-DI Paragraph

**Location:** procedure.md, after SL vs DI table

**Add:**
> DI in legacy migrations frequently causes:
> - Signature explosion across large call chains
> - Widespread construction/wiring refactors before behavior is stabilized
> - Pressure toward interface/virtualization everywhere (indirection in hot paths)
> - Friction when the codebase is not yet modularized (Step 3 comes later)
>
> Reserve DI for tight, local couplings where the dependency graph is already clean.

---

### D5. Fix Step 12 Deliverable

**Location:** procedure.md, Step 12

**Before:**
> "a 'how-to add a service to the locator' tutorial"

**After:**
> "Document dependency registration/construction at a high level (one page), sufficient for contributors to follow project conventions."

**Rationale:** A tutorial is a user manual. The migration guide should describe process and constraints, not become a subsystem handbook.

---

### A1. Fix `const_cast` UB

**Location:** ServiceLocator.h, line ~1636

**Change:** Remove `const` overload of `writeLock()`.

**Test:** Compile with `-Wcast-qual`, verify no warnings.

---

### A2. Add Policy Trait Static Asserts

**Location:** ServiceLocator.h, near class definition

**Add:**
```cpp
static_assert(is_concurrency_policy_v<ConcurrencyPolicy>,
              "ConcurrencyPolicy must satisfy concurrency policy requirements");
```

---

## Phase 2: Code Quality (Week 1-2)

### B1. Resolution Method Refactor

**Prerequisite:** Behavioral equivalence test suite (25+ scenarios from ResolutionRefactor_Proposal.h)

**Steps:**
1. Write test suite against current implementation
2. Record baseline performance
3. Implement `resolveInternal<T>()` + `ResolutionResult<T>`
4. Replace public methods with thin wrappers
5. Verify tests pass, benchmark within 5%

---

## Phase 3: Performance (Week 3)

### B2. Named Service MRU Cache

**Design:** Hash-based keying (FNV-1a + length check)

**Targets:**
- Named cache hit: 24.56 ns → ~3.5 ns
- Unnamed regression: 0 ns

---

## Phase 4: Structural (Deferred — Requires Concrete Use Case)

### C1. DSO-Safe TypeKeyPolicy

**Trigger:** Only implement if you have a concrete plugin/DSO use case.

**Why deferred:**
1. Doc plan removes "runtime linker" language → no longer promised
2. Requires structural change to `UnnamedRegistry` key type
3. High effort (2-4 days) for speculative benefit

**If needed:** Start with Option A (type_index key), validate on target platforms.

---

## Execution Schedule

```
Week 1, Days 1-2: Alignment
├── D1: Fix "runtime linker" language (0.5 day)
├── D2: Replace "runtime flexibility" row (0.5 day)
├── D3: Compress SL vs DI table (0.25 day)
├── D4: Add anti-DI paragraph (0.25 day)
├── D5: Fix Step 12 deliverable (0.25 day)
├── A1: Fix const_cast UB (0.5 day)
└── A2: Add static_asserts (0.25 day)

Week 1, Days 3-5: Test Infrastructure
└── B1: Write behavioral equivalence test suite (3 days)

Week 2: Refactor
├── B1: Implement resolution refactor (2 days)
└── B1: Verify + benchmark (1 day)

Week 3: Performance
└── B2: Named MRU cache (design review + implementation)

Future (if plugin use case arises):
└── C1: DSO-safe TypeKeyPolicy
```

---

## Acceptance Criteria

### Documentation (D1-D5)

| ID | Criterion |
|----|-----------|
| D1 | "runtime linker" phrase removed |
| D2 | "replaced at runtime by re-registering" removed or rewritten to "test/config substitution" |
| D3 | SL vs DI table has ≤5 rows, all migration-relevant |
| D4 | Anti-DI paragraph present with 4 migration-specific bullet points |
| D5 | Step 12 does not mention "tutorial" or "how-to" |

### Code (A1-B2)

| ID | Criterion |
|----|-----------|
| A1 | Zero warnings with `-Wcast-qual` |
| A2 | Invalid policy rejected at compile time with clear message |
| B1 | 100% behavioral equivalence tests pass; performance within 5% of baseline |
| B2 | Named cache hit < 5 ns; unnamed regression = 0 |

---

## Why This Merge Works

| Concern | Resolution |
|---------|------------|
| Doc promises "runtime linker" but code doesn't deliver | D1 fixes the doc |
| DSO-safe seems low priority but doc implies it | D1 removes implication; C1 correctly deferred |
| SL section is becoming a design doc | D3 compresses to migration-relevant rows only |
| Code has correctness issue (const_cast) | A1 fixes immediately |
| Named services are slow | B2 addresses (performance, not "runtime flexibility") |

The merged plan ensures **documentation describes what code delivers** and **code improvements are prioritized by actual value, not speculative features**.
