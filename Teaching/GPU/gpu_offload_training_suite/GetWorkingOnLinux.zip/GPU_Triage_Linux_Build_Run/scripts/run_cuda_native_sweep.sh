#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"

build_dir="${HOT_LOOP_BUILD_ROOT}/cuda_native"
[[ -d "${build_dir}" ]] || die "Missing ${build_dir}; run scripts/build_cuda_native.sh first"

list_targets() {
  find "${build_dir}" -maxdepth 2 -type f -perm -111 \
    \( -name 'cuda_*' -o -name 'split_*' -o -name 'gfull_*' -o -name 'mega_*' -o -name 'persist_*' \) \
    -printf '%f\n' | sort
}

cmd="${1:-list}"
if [[ "${cmd}" == "list" ]]; then list_targets; exit 0; fi
mkdir -p "${HOT_LOOP_BUILD_ROOT}/results"
out="${HOT_LOOP_BUILD_ROOT}/results/cuda_native_${cmd}.txt"
: > "${out}"

run_target() {
  local name="$1" path
  path="$(find "${build_dir}" -maxdepth 2 -type f -perm -111 -name "${name}" | head -n 1)"
  [[ -n "${path}" ]] || die "Target not found: ${name}. Use '$0 list'."
  msg "Running ${name}"
  { echo "===== ${name} ====="; "${path}"; echo; } | tee -a "${out}"
}

if [[ "${cmd}" == "all" ]]; then
  while read -r t; do run_target "${t}"; done < <(list_targets)
else
  run_target "${cmd}"
fi
msg "Wrote ${out}"
