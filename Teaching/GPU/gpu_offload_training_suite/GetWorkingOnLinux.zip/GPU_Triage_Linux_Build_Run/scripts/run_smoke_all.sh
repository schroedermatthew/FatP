#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"

"${HOT_LOOP_PACKAGE_ROOT}/scripts/run_cpu_sweep.sh" smoke

if [[ -d "${HOT_LOOP_BUILD_ROOT}/cuda_native" ]]; then
  "${HOT_LOOP_PACKAGE_ROOT}/scripts/run_cuda_native_sweep.sh" list
  if [[ -x "${HOT_LOOP_BUILD_ROOT}/cuda_native/gfull_224" ]]; then
    "${HOT_LOOP_PACKAGE_ROOT}/scripts/run_cuda_native_sweep.sh" gfull_224
  else
    warn "gfull_224 not found; skipping CUDA smoke run."
  fi
fi

if [[ -d "${HOT_LOOP_BUILD_ROOT}/kokkos_variants" ]]; then
  "${HOT_LOOP_PACKAGE_ROOT}/scripts/run_kokkos_variants.sh" list
fi
