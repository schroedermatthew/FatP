#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "${_script_dir}/common.sh"

if [[ -d "${HOT_LOOP_SOURCE_DIR}" ]]; then
  msg "Source tree already exists: ${HOT_LOOP_SOURCE_DIR}"
  exit 0
fi

zip_path="${HOT_LOOP_PACKAGE_ROOT}/GPU_Triage_Source.zip"
[[ -f "${zip_path}" ]] || die "Missing ${zip_path}. Put GPU_Triage_Source.zip next to this package or set HOT_LOOP_SOURCE_DIR."
have unzip || die "unzip is required to extract GPU_Triage_Source.zip"

mkdir -p "${HOT_LOOP_BUILD_ROOT}"
msg "Extracting ${zip_path} into ${HOT_LOOP_BUILD_ROOT}"
unzip -q -o "${zip_path}" -d "${HOT_LOOP_BUILD_ROOT}"

if [[ ! -d "${HOT_LOOP_SOURCE_DIR}" && -d "${HOT_LOOP_BUILD_ROOT}/GPU_Triage_Source" ]]; then
  export HOT_LOOP_SOURCE_DIR="${HOT_LOOP_BUILD_ROOT}/GPU_Triage_Source"
fi

[[ -d "${HOT_LOOP_SOURCE_DIR}" ]] || die "Expected source tree at ${HOT_LOOP_SOURCE_DIR}"
msg "Source tree ready: ${HOT_LOOP_SOURCE_DIR}"
