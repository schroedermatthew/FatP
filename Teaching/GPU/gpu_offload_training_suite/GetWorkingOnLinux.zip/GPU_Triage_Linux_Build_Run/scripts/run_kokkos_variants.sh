#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"

build_dir="${HOT_LOOP_BUILD_ROOT}/kokkos_variants"
[[ -d "${build_dir}" ]] || die "Missing ${build_dir}; run scripts/build_kokkos_variants.sh first"

list_targets() {
  find "${build_dir}" -maxdepth 2 -type f -perm -111 \
    \( -name 'kokkos_*' -o -name 'flat_naive_*' -o -name 'team_libs_*' -o -name 'kokkos_libs_graph_*' \) \
    -printf '%f\n' | sort
}

cmd="${1:-list}"
if [[ "${cmd}" == "list" ]]; then list_targets; exit 0; fi
mkdir -p "${HOT_LOOP_BUILD_ROOT}/results"
out="${HOT_LOOP_BUILD_ROOT}/results/kokkos_${cmd}.txt"
: > "${out}"

run_target() {
  local name="$1" path
  path="$(find "${build_dir}" -maxdepth 2 -type f -perm -111 -name "${name}" | head -n 1)"
  [[ -n "${path}" ]] || die "Target not found: ${name}. Use '$0 list'."
  msg "Running ${name}"
  { echo "===== ${name} ====="; "${path}"; echo; } | tee -a "${out}"
}

if [[ "${cmd}" == "all" ]]; then
  warn "Running all Kokkos targets can take a long time because sources are full training sweeps."
  while read -r t; do run_target "${t}"; done < <(list_targets)
else
  run_target "${cmd}"
fi
msg "Wrote ${out}"
