#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"
ensure_source_tree
have nvcc || die "nvcc not found. Kokkos CUDA variants need CUDA Toolkit."

if [[ -z "${Kokkos_DIR:-}" && -d "${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/Kokkos" ]]; then export Kokkos_DIR="${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/Kokkos"; fi
if [[ -z "${KokkosKernels_DIR:-}" && -d "${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/KokkosKernels" ]]; then export KokkosKernels_DIR="${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/KokkosKernels"; fi
[[ -n "${Kokkos_DIR:-}" ]] || warn "Kokkos_DIR is not set; CMake will search CMAKE_PREFIX_PATH and system locations."

msg "Configuring Kokkos variants"
mapfile -t gen_args < <(cmake_generator_args)
cmake_args=( -S "${HOT_LOOP_PACKAGE_ROOT}/cmake/linux_kokkos_variants" -B "${HOT_LOOP_BUILD_ROOT}/kokkos_variants" "${gen_args[@]}" -DCMAKE_BUILD_TYPE=Release -DHOT_LOOP_SOURCE_DIR="${HOT_LOOP_SOURCE_DIR}" -DHOT_LOOP_CUDA_ARCH="${HOT_LOOP_CUDA_ARCH}" )
[[ -n "${Kokkos_DIR:-}" ]] && cmake_args+=( -DKokkos_DIR="${Kokkos_DIR}" )
[[ -n "${KokkosKernels_DIR:-}" ]] && cmake_args+=( -DKokkosKernels_DIR="${KokkosKernels_DIR}" )
cmake "${cmake_args[@]}"

msg "Building Kokkos variants"
cmake --build "${HOT_LOOP_BUILD_ROOT}/kokkos_variants" --parallel "${HOT_LOOP_JOBS}"

msg "Kokkos variants build complete"
find "${HOT_LOOP_BUILD_ROOT}/kokkos_variants" -maxdepth 2 -type f -perm -111 \
  \( -name 'kokkos_*' -o -name 'flat_naive_*' -o -name 'team_libs_*' -o -name 'kokkos_libs_graph_*' \) -print | sort
