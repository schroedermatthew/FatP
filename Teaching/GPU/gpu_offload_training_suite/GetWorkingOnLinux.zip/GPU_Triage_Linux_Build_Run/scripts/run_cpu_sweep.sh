#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"

mode="${1:-smoke}"
case "${mode}" in
  smoke) points=("100 224 4096") ;;
  full) points=("50000 224 4096" "5000 512 8192" "1000 1024 32768") ;;
  *) die "Usage: $0 [smoke|full]" ;;
esac

cpu_bin="${HOT_LOOP_BUILD_ROOT}/cpu/hot_loop_cpu"
mkl_bin="${HOT_LOOP_BUILD_ROOT}/cpu/hot_loop_mkl"
[[ -x "${cpu_bin}" ]] || die "Missing ${cpu_bin}; run scripts/build_cpu.sh first"
mkdir -p "${HOT_LOOP_BUILD_ROOT}/results"
out="${HOT_LOOP_BUILD_ROOT}/results/cpu_${mode}.txt"
: > "${out}"

run_one() {
  local bin="$1" label="$2" args="$3"
  msg "${label}: ${args}"
  { echo "===== ${label} ${args} ====="; "${bin}" ${args}; echo; } | tee -a "${out}"
}

for p in "${points[@]}"; do
  run_one "${cpu_bin}" "hot_loop_cpu" "${p}"
  if [[ -x "${mkl_bin}" ]]; then
    MKL_THREADING_LAYER="${MKL_THREADING_LAYER:-SEQUENTIAL}" run_one "${mkl_bin}" "hot_loop_mkl" "${p}"
  fi
done
msg "Wrote ${out}"
