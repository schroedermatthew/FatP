#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"

clone=0
if [[ "${1:-}" == "--clone" ]]; then clone=1; fi
mkdir -p "${HOT_LOOP_BUILD_ROOT}" "$(dirname "${HOT_LOOP_KOKKOS_PREFIX}")"

if [[ -z "${KOKKOS_SRC:-}" ]]; then
  if [[ ${clone} -eq 1 ]]; then
    KOKKOS_SRC="${HOT_LOOP_BUILD_ROOT}/kokkos-src"
    [[ -d "${KOKKOS_SRC}" ]] || { have git || die "git is required for --clone"; git clone --depth 1 https://github.com/kokkos/kokkos.git "${KOKKOS_SRC}"; }
  else
    die "Set KOKKOS_SRC=/path/to/kokkos or run $0 --clone"
  fi
fi
if [[ -z "${KOKKOS_KERNELS_SRC:-}" ]]; then
  if [[ ${clone} -eq 1 ]]; then
    KOKKOS_KERNELS_SRC="${HOT_LOOP_BUILD_ROOT}/kokkos-kernels-src"
    [[ -d "${KOKKOS_KERNELS_SRC}" ]] || { have git || die "git is required for --clone"; git clone --depth 1 https://github.com/kokkos/kokkos-kernels.git "${KOKKOS_KERNELS_SRC}"; }
  else
    die "Set KOKKOS_KERNELS_SRC=/path/to/kokkos-kernels or run $0 --clone"
  fi
fi

[[ -d "${KOKKOS_SRC}" ]] || die "KOKKOS_SRC not found: ${KOKKOS_SRC}"
[[ -d "${KOKKOS_KERNELS_SRC}" ]] || die "KOKKOS_KERNELS_SRC not found: ${KOKKOS_KERNELS_SRC}"
have nvcc || die "nvcc not found. Install CUDA Toolkit or load the CUDA module."
mapfile -t gen_args < <(cmake_generator_args)

msg "Building Kokkos with CUDA arch sm_${HOT_LOOP_CUDA_ARCH} / Kokkos_ARCH_${HOT_LOOP_KOKKOS_ARCH}"
cmake -S "${KOKKOS_SRC}" -B "${HOT_LOOP_BUILD_ROOT}/kokkos" \
  "${gen_args[@]}" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="${HOT_LOOP_KOKKOS_PREFIX}" \
  -DCMAKE_CXX_STANDARD=20 \
  -DCMAKE_CUDA_ARCHITECTURES="${HOT_LOOP_CUDA_ARCH}" \
  -DKokkos_ENABLE_SERIAL=ON \
  -DKokkos_ENABLE_CUDA=ON \
  -DKokkos_ENABLE_CUDA_LAMBDA=ON \
  -DKokkos_ENABLE_COMPILE_AS_CMAKE_LANGUAGE=ON \
  -DKokkos_ARCH_${HOT_LOOP_KOKKOS_ARCH}=ON
cmake --build "${HOT_LOOP_BUILD_ROOT}/kokkos" --parallel "${HOT_LOOP_JOBS}"
cmake --install "${HOT_LOOP_BUILD_ROOT}/kokkos"

msg "Building KokkosKernels with cuBLAS/cuSOLVER TPLs"
cmake -S "${KOKKOS_KERNELS_SRC}" -B "${HOT_LOOP_BUILD_ROOT}/kokkos-kernels" \
  "${gen_args[@]}" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="${HOT_LOOP_KOKKOS_PREFIX}" \
  -DCMAKE_CXX_STANDARD=20 \
  -DCMAKE_CUDA_ARCHITECTURES="${HOT_LOOP_CUDA_ARCH}" \
  -DKokkos_ROOT="${HOT_LOOP_KOKKOS_PREFIX}" \
  -DKokkos_DIR="${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/Kokkos" \
  -DKokkosKernels_ENABLE_TPL_CUBLAS=ON \
  -DKokkosKernels_ENABLE_TPL_CUSOLVER=ON
cmake --build "${HOT_LOOP_BUILD_ROOT}/kokkos-kernels" --parallel "${HOT_LOOP_JOBS}"
cmake --install "${HOT_LOOP_BUILD_ROOT}/kokkos-kernels"

msg "Kokkos install complete: ${HOT_LOOP_KOKKOS_PREFIX}"
echo "export Kokkos_DIR=${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/Kokkos"
echo "export KokkosKernels_DIR=${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/KokkosKernels"
