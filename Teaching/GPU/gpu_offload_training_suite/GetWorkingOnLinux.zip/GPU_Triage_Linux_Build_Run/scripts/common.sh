#!/usr/bin/env bash
set -euo pipefail

# Resolve package root from this script directory unless the caller overrides it.
if [[ -z "${HOT_LOOP_PACKAGE_ROOT:-}" ]]; then
  _common_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  export HOT_LOOP_PACKAGE_ROOT="$(cd "${_common_dir}/.." && pwd)"
fi

export HOT_LOOP_BUILD_ROOT="${HOT_LOOP_BUILD_ROOT:-${HOT_LOOP_PACKAGE_ROOT}/build-linux}"
export HOT_LOOP_CUDA_ARCH="${HOT_LOOP_CUDA_ARCH:-120}"
export HOT_LOOP_KOKKOS_ARCH="${HOT_LOOP_KOKKOS_ARCH:-BLACKWELL120}"
export HOT_LOOP_KOKKOS_PREFIX="${HOT_LOOP_KOKKOS_PREFIX:-${HOME}/opt/kokkos-cuda}"

if [[ -z "${HOT_LOOP_SOURCE_DIR:-}" ]]; then
  if [[ -d "${HOT_LOOP_PACKAGE_ROOT}/GPU_Triage_Source" ]]; then
    export HOT_LOOP_SOURCE_DIR="${HOT_LOOP_PACKAGE_ROOT}/GPU_Triage_Source"
  else
    export HOT_LOOP_SOURCE_DIR="${HOT_LOOP_BUILD_ROOT}/GPU_Triage_Source"
  fi
fi

nproc_default() {
  if command -v nproc >/dev/null 2>&1; then
    nproc
  else
    getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4
  fi
}
export HOT_LOOP_JOBS="${HOT_LOOP_JOBS:-$(nproc_default)}"

msg() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33mWARN:\033[0m %s\n' "$*" >&2; }
die() { printf '\033[1;31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

ensure_source_tree() {
  if [[ -d "${HOT_LOOP_SOURCE_DIR}" ]]; then
    return 0
  fi
  "${HOT_LOOP_PACKAGE_ROOT}/scripts/unpack_source.sh"
  [[ -d "${HOT_LOOP_SOURCE_DIR}" ]] || die "Source tree not found after unpack: ${HOT_LOOP_SOURCE_DIR}"
}

cmake_generator_args() {
  if have ninja; then
    printf '%s\n' -G Ninja
  fi
}
