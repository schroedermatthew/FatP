#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"
ensure_source_tree

msg "Generating portable Linux CPU sources"
mkdir -p "${HOT_LOOP_BUILD_ROOT}/generated_cpu"
python3 "${HOT_LOOP_PACKAGE_ROOT}/scripts/make_portable_cpu_sources.py" \
  --source-root "${HOT_LOOP_SOURCE_DIR}" \
  --out-dir "${HOT_LOOP_BUILD_ROOT}/generated_cpu"

msg "Configuring CPU baselines"
mapfile -t gen_args < <(cmake_generator_args)
cmake -S "${HOT_LOOP_PACKAGE_ROOT}/cmake/linux_cpu_baselines" \
  -B "${HOT_LOOP_BUILD_ROOT}/cpu" \
  "${gen_args[@]}" \
  -DCMAKE_BUILD_TYPE=Release \
  -DHOT_LOOP_GENERATED_SRC_DIR="${HOT_LOOP_BUILD_ROOT}/generated_cpu" \
  -DHOT_LOOP_ENABLE_MKL="${HOT_LOOP_ENABLE_MKL:-ON}"

msg "Building CPU baselines"
cmake --build "${HOT_LOOP_BUILD_ROOT}/cpu" --parallel "${HOT_LOOP_JOBS}"

msg "CPU build complete"
find "${HOT_LOOP_BUILD_ROOT}/cpu" -maxdepth 2 -type f -perm -111 -name 'hot_loop*' -print
