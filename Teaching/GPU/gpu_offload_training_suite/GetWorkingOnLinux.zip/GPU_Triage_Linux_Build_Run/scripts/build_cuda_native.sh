#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"
ensure_source_tree
have nvcc || die "nvcc not found. Install CUDA Toolkit or load the CUDA module."

msg "Generating native CUDA sweep sources"
mkdir -p "${HOT_LOOP_BUILD_ROOT}/generated_cuda"
python3 "${HOT_LOOP_PACKAGE_ROOT}/scripts/generate_cuda_sources.py" \
  --source-root "${HOT_LOOP_SOURCE_DIR}" \
  --out-dir "${HOT_LOOP_BUILD_ROOT}/generated_cuda"

msg "Configuring native CUDA variants for sm_${HOT_LOOP_CUDA_ARCH}"
mapfile -t gen_args < <(cmake_generator_args)
cmake -S "${HOT_LOOP_PACKAGE_ROOT}/cmake/linux_cuda_native" \
  -B "${HOT_LOOP_BUILD_ROOT}/cuda_native" \
  "${gen_args[@]}" \
  -DCMAKE_BUILD_TYPE=Release \
  -DHOT_LOOP_GENERATED_CUDA_DIR="${HOT_LOOP_BUILD_ROOT}/generated_cuda" \
  -DHOT_LOOP_CUDA_ARCH="${HOT_LOOP_CUDA_ARCH}"

msg "Building native CUDA variants"
cmake --build "${HOT_LOOP_BUILD_ROOT}/cuda_native" --parallel "${HOT_LOOP_JOBS}"

msg "CUDA native build complete"
find "${HOT_LOOP_BUILD_ROOT}/cuda_native" -maxdepth 2 -type f -perm -111 \
  \( -name 'cuda_*' -o -name 'split_*' -o -name 'gfull_*' -o -name 'mega_*' -o -name 'persist_*' \) -print | sort
