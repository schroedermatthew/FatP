#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_script_dir}/common.sh"

"${HOT_LOOP_PACKAGE_ROOT}/scripts/unpack_source.sh"
"${HOT_LOOP_PACKAGE_ROOT}/scripts/build_cpu.sh"

if have nvcc; then
  "${HOT_LOOP_PACKAGE_ROOT}/scripts/build_cuda_native.sh"
  if [[ -n "${Kokkos_DIR:-}" || -d "${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/Kokkos" ]]; then
    "${HOT_LOOP_PACKAGE_ROOT}/scripts/build_kokkos_variants.sh" || warn "Kokkos variant build failed; inspect logs above."
  else
    warn "Skipping Kokkos variants: Kokkos_DIR not set and ${HOT_LOOP_KOKKOS_PREFIX}/lib/cmake/Kokkos not found."
  fi
else
  warn "Skipping CUDA/Kokkos builds because nvcc was not found."
fi
