#!/usr/bin/env python3
from __future__ import annotations
import argparse
import re
from pathlib import Path

SWEEP = {
    224:  (50000, 224, 4096),
    512:  (5000, 512, 8192),
    1024: (1000, 1024, 32768),
}

VARIANTS = {
    'cuda':    ('hot_loop_cuda.cu', 'cuda'),
    'split':   ('hot_loop_cuda_graph.cu', 'split'),
    'gfull':   ('hot_loop_cuda_graph_full.cu', 'gfull'),
    'mega':    ('hot_loop_cuda_megakernel.cu', 'mega'),
    'persist': ('hot_loop_cuda_persistent.cu', 'persist'),
}


def replace_constants(text: str, n_outer: int, n_dim: int, buf_len: int) -> str:
    repls = {
        r'constexpr\s+int\s+N_OUTER\s*=\s*\d+\s*;': f'constexpr int N_OUTER = {n_outer};',
        r'constexpr\s+int\s+N_DIM\s*=\s*\d+\s*;':   f'constexpr int N_DIM   = {n_dim};',
        r'constexpr\s+int\s+BUF_LEN\s*=\s*\d+\s*;': f'constexpr int BUF_LEN = {buf_len};',
    }
    for pat, rep in repls.items():
        text, count = re.subn(pat, rep, text, count=1)
        if count != 1:
            raise RuntimeError(f'failed to replace constant pattern: {pat}')
    return text


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--source-root', type=Path, required=True)
    ap.add_argument('--out-dir', type=Path, required=True)
    args = ap.parse_args()

    cuda_dir = args.source_root / 'hot_loop_cuda_native'
    out = args.out_dir
    out.mkdir(parents=True, exist_ok=True)

    manifest = []
    for variant, (source_name, prefix) in VARIANTS.items():
        src_path = cuda_dir / source_name
        if not src_path.exists():
            raise FileNotFoundError(src_path)
        text0 = src_path.read_text(encoding='utf-8')
        for n, (n_outer, n_dim, buf_len) in SWEEP.items():
            generated = replace_constants(text0, n_outer, n_dim, buf_len)
            out_name = f'{prefix}_{n}.cu'
            out_path = out / out_name
            out_path.write_text(generated, encoding='utf-8')
            manifest.append((variant, f'{prefix}_{n}', out_name))
            print(f'wrote {out_path}')

    manifest_path = out / 'manifest.txt'
    manifest_path.write_text('\n'.join(f'{v},{t},{s}' for v, t, s in manifest) + '\n', encoding='utf-8')
    print(f'wrote {manifest_path}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
