#!/usr/bin/env bash
set -euo pipefail
_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "${_script_dir}/common.sh"

print_cmd() {
  local label="$1"; shift
  printf '%-24s : ' "${label}"
  if have "$1"; then
    "$@" 2>/dev/null | head -n 1 || true
  else
    echo "not found"
  fi
}

msg "Linux GPU triage build environment"
printf '%-24s : %s\n' "Package root" "${HOT_LOOP_PACKAGE_ROOT}"
printf '%-24s : %s\n' "Build root" "${HOT_LOOP_BUILD_ROOT}"
printf '%-24s : %s\n' "Source dir" "${HOT_LOOP_SOURCE_DIR}"
printf '%-24s : %s\n' "CUDA arch" "${HOT_LOOP_CUDA_ARCH}"
printf '%-24s : %s\n' "Kokkos arch" "${HOT_LOOP_KOKKOS_ARCH}"

print_cmd "python3" python3 --version
print_cmd "cmake" cmake --version
print_cmd "ninja" ninja --version
print_cmd "gcc" gcc --version
print_cmd "g++" g++ --version
print_cmd "nvcc" nvcc --version
print_cmd "nvidia-smi" nvidia-smi --query-gpu=name,driver_version --format=csv,noheader

printf '%-24s : %s\n' "MKLROOT" "${MKLROOT:-not set}"
printf '%-24s : %s\n' "Kokkos_DIR" "${Kokkos_DIR:-not set}"
printf '%-24s : %s\n' "KokkosKernels_DIR" "${KokkosKernels_DIR:-not set}"
printf '%-24s : %s\n' "KOKKOS_SRC" "${KOKKOS_SRC:-not set}"
printf '%-24s : %s\n' "KOKKOS_KERNELS_SRC" "${KOKKOS_KERNELS_SRC:-not set}"

if [[ -f "${HOT_LOOP_PACKAGE_ROOT}/GPU_Triage_Source.zip" ]]; then
  printf '%-24s : %s\n' "Source ZIP" "present"
else
  printf '%-24s : %s\n' "Source ZIP" "missing"
fi

if [[ -d "${HOT_LOOP_SOURCE_DIR}" ]]; then
  printf '%-24s : %s\n' "Source tree" "present"
else
  printf '%-24s : %s\n' "Source tree" "not extracted yet; run scripts/unpack_source.sh"
fi
