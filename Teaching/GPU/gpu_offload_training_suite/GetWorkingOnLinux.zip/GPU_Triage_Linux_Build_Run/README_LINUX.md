# GPU Triage Linux Build/Run Package

This package is a Linux companion for `GPU_Triage_Source.zip`. It does not replace the teaching document; it gives a Linux user the practical build/run path for the code behind the case study.

The original source bundle is Windows-oriented in a few places:

- the scalar CPU and MKL CPU baselines use `windows.h`, `QueryPerformanceCounter`, and `_aligned_malloc`;
- the native CUDA variants have `.bat` build scripts but no Linux CMake project;
- the Kokkos variants assume an already-installed Kokkos/KokkosKernels stack.

This package fills those gaps with portable source generation, Linux CMake projects, and bash helpers.

## Contents

```text
GPU_Triage_Linux_Build_Run/
  GPU_Triage_Source.zip              # original source implementation bundle
  README_LINUX.md                    # this guide
  env/linux.env.example              # editable environment template
  scripts/
    unpack_source.sh                 # extracts GPU_Triage_Source.zip
    check_env.sh                     # prints toolchain/GPU/library status
    make_portable_cpu_sources.py     # generates Linux CPU/MKL sources
    generate_cuda_sources.py         # generates CUDA sweep sources per N
    build_cpu.sh                     # builds scalar CPU and optional MKL baseline
    run_cpu_sweep.sh                 # runs CPU smoke/full sweep
    build_cuda_native.sh             # builds native CUDA/direct/graph variants
    run_cuda_native_sweep.sh         # lists/runs native CUDA targets
    build_kokkos_from_source.sh      # optional Kokkos + KokkosKernels source build
    build_kokkos_variants.sh         # builds Kokkos training variants
    run_kokkos_variants.sh           # lists/runs Kokkos targets
    build_all.sh                     # builds what the current machine can support
    run_smoke_all.sh                 # conservative smoke checks
  cmake/
    linux_cpu_baselines/             # CMake for generated CPU baselines
    linux_cuda_native/               # CMake for generated native CUDA variants
    linux_kokkos_variants/           # CMake for Kokkos source variants
    kokkos_probe/                    # tiny AXPY smoke test for installed Kokkos
```

## Requirements

Minimum useful CPU-only path:

- Linux x86_64
- bash
- Python 3
- CMake 3.21+
- GCC/Clang C/C++ toolchain

CUDA native path:

- NVIDIA driver
- CUDA Toolkit with `nvcc`
- CMake with CUDA language support

MKL CPU baseline path, optional:

- Intel oneAPI MKL or another installation exposing `mkl.h` and `libmkl_rt.so`
- set `MKLROOT` if CMake cannot find it automatically

Kokkos path, optional:

- installed Kokkos with CUDA enabled
- installed KokkosKernels with cuBLAS/cuSOLVER TPLs for the library-backed variants
- or local Kokkos/KokkosKernels source trees so `build_kokkos_from_source.sh` can install them

## First-time setup

```bash
cd GPU_Triage_Linux_Build_Run
cp env/linux.env.example env/linux.env
# edit env/linux.env for your GPU architecture, MKLROOT, and/or Kokkos paths
source env/linux.env

./scripts/unpack_source.sh
./scripts/check_env.sh
```

The default CUDA architecture is `120` because the Windows companion targets RTX 5080 / sm_120. Change it for your hardware:

```bash
export HOT_LOOP_CUDA_ARCH=80      # A100
export HOT_LOOP_KOKKOS_ARCH=AMPERE80
```

Other common pairs:

| GPU family | `HOT_LOOP_CUDA_ARCH` | Kokkos arch flag suffix |
| --- | ---: | --- |
| V100 | 70 | `VOLTA70` |
| A100 | 80 | `AMPERE80` |
| RTX 4090 | 89 | `ADA89` if your Kokkos release supports it; otherwise use the closest supported Ada/Ampere flag |
| H100 | 90 | `HOPPER90` |
| RTX 5080 / 5090 | 120 | `BLACKWELL120` if your Kokkos release supports it |

## CPU baseline quick start

This path does not need a GPU. It generates Linux versions of the two Windows CPU sources by replacing the Windows timer and aligned allocator with POSIX equivalents.

```bash
./scripts/build_cpu.sh
./scripts/run_cpu_sweep.sh smoke
```

A full sweep uses the training sizes and may take much longer:

```bash
./scripts/run_cpu_sweep.sh full
```

The scalar CPU binary accepts runtime dimensions:

```bash
build-linux/cpu/hot_loop_cpu 50000 224 4096
```

If MKL is found, `hot_loop_mkl` is built too:

```bash
MKL_THREADING_LAYER=SEQUENTIAL build-linux/cpu/hot_loop_mkl 50000 224 4096
```

## Native CUDA quick start

```bash
export HOT_LOOP_CUDA_ARCH=120   # change to your GPU, e.g. 80 for A100
./scripts/build_cuda_native.sh
./scripts/run_cuda_native_sweep.sh list
./scripts/run_cuda_native_sweep.sh gfull_224
```

The generated targets are:

```text
cuda_224,  cuda_512,  cuda_1024      # direct CUDA + cuSOLVER
split_224, split_512, split_1024     # split CUDA graph around library calls
gfull_224, gfull_512, gfull_1024     # full-capture CUDA graph
mega_224,  mega_512,  mega_1024      # cooperative megakernel
persist_224, persist_512, persist_1024 # cooperative persistent kernel
```

The cooperative megakernel and persistent targets are built with CUDA separable compilation and link `cudadevrt`, matching the Windows BAT intent.

## Kokkos quick start with an existing install

```bash
export Kokkos_DIR=/opt/kokkos/lib/cmake/Kokkos
export KokkosKernels_DIR=/opt/kokkos/lib/cmake/KokkosKernels
export HOT_LOOP_CUDA_ARCH=120

./scripts/build_kokkos_variants.sh
./scripts/run_kokkos_variants.sh list
./scripts/run_kokkos_variants.sh kokkos_libs_graph_224
```

The package also includes a tiny Kokkos AXPY probe:

```bash
cmake -S cmake/kokkos_probe -B build-linux/kokkos_probe \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CUDA_ARCHITECTURES=${HOT_LOOP_CUDA_ARCH} \
  -DKokkos_DIR=${Kokkos_DIR}
cmake --build build-linux/kokkos_probe --parallel
./build-linux/kokkos_probe/kokkos_axpy_probe
```

## Building Kokkos and KokkosKernels from local source

This script does **not** silently patch or guess your Kokkos checkout. It expects local source trees, or you can pass `--clone` to let it run shallow `git clone` commands if your Linux machine has internet access.

```bash
export KOKKOS_SRC=$HOME/src/kokkos
export KOKKOS_KERNELS_SRC=$HOME/src/kokkos-kernels
export HOT_LOOP_KOKKOS_PREFIX=$HOME/opt/kokkos-cuda
export HOT_LOOP_CUDA_ARCH=120
export HOT_LOOP_KOKKOS_ARCH=BLACKWELL120

./scripts/build_kokkos_from_source.sh
source env/linux.env
./scripts/build_kokkos_variants.sh
```

For an existing install, skip `build_kokkos_from_source.sh` and set `Kokkos_DIR` / `KokkosKernels_DIR` directly.


## Which training timing rows this package can reproduce

The training HTML now marks each timing row with a rerun status. Use this Linux package as follows:

| Timing family in the training HTML | Linux package status |
| --- | --- |
| Cross-variant CPU baseline sweep | Directly runnable with `scripts/build_cpu.sh` and `scripts/run_cpu_sweep.sh full`. |
| Part III / cross-variant MKL rows | Runnable only when MKL is installed. Sequential vs threaded rows require matching `MKL_THREADING_LAYER`, OpenMP, and thread-count settings. |
| Native CUDA direct / split graph / full graph / megakernel / persistent rows | Runnable with `scripts/build_cuda_native.sh` and `scripts/run_cuda_native_sweep.sh ...` when `nvcc`, a compatible NVIDIA driver/GPU, cuSOLVER, and cuBLAS are available. |
| Kokkos flat-naive and TeamPolicy + library rows | Runnable with `scripts/build_kokkos_variants.sh` and `scripts/run_kokkos_variants.sh ...` when CUDA-enabled Kokkos and KokkosKernels are installed. |
| Kokkos graph three-size summary row | Runnable with `scripts/build_kokkos_variants.sh` and `scripts/run_kokkos_variants.sh kokkos_libs_graph_224` / `512` / `1024` when CUDA-enabled Kokkos with graph capture support and CUDA 12+ cuSOLVER are available. The ArrayView/C++-tools graph source remains included but is not the training target. |
| Clean Intel Advisor export rows | Tooling-dependent/reference. Source and runbook are included in `GPU_Triage_Source.zip`, but the clean Advisor export projects are not bundled. |

Exact seconds are not expected to match the training tables unless the hardware, driver, compiler, library versions, architecture flags, and thread/runtime settings also match. Use the rerun labels to decide which comparisons are fair.

## Output locations

All generated and built artifacts go under:

```text
build-linux/
  generated_cpu/
  generated_cuda/
  cpu/
  cuda_native/
  kokkos/
  kokkos-kernels/
  kokkos_variants/
  results/
```

## Validation expectation

This package was created in an environment without `nvcc`, Kokkos, KokkosKernels, MKL, or a visible NVIDIA GPU, so the CUDA/Kokkos paths were statically generated and syntax-checked where possible, but not compiled here. The CPU-only Linux generation/build path was designed to compile with GCC/Clang on Linux.

Always start with:

```bash
./scripts/check_env.sh
./scripts/build_cpu.sh
./scripts/run_cpu_sweep.sh smoke
```

Then build CUDA/Kokkos paths only after the toolchain checks are green.
