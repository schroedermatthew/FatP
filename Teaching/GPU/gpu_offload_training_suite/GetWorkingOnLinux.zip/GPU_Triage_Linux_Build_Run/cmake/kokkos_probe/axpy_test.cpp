#include <Kokkos_Core.hpp>
#include <cstdio>

int main(int argc, char **argv)
{
    Kokkos::initialize(argc, argv);
    {
        const int n = 1 << 20;
        Kokkos::View<double *> x("x", n);
        Kokkos::View<double *> y("y", n);

        Kokkos::parallel_for("init", n, KOKKOS_LAMBDA(const int i)
        {
            x(i) = 1.0;
            y(i) = 2.0;
        });

        Kokkos::parallel_for("axpy", n, KOKKOS_LAMBDA(const int i)
        {
            y(i) = 2.0 * x(i) + y(i);
        });

        double sum = 0.0;
        Kokkos::parallel_reduce("sum", n,
            KOKKOS_LAMBDA(const int i, double &acc)
            {
                acc += y(i);
            }, sum);

        std::printf("Execution space: %s\n", Kokkos::DefaultExecutionSpace::name());
        std::printf("Sum: %.1f expected %.1f\n", sum, 4.0 * (double)n);
    }
    Kokkos::finalize();
    return 0;
}
