#include <Kokkos_Core.hpp>
#include <cstdio>

int main(int argc, char* argv[]) {
    Kokkos::initialize(argc, argv);
    {
        const int N = 1 << 20;
        Kokkos::View<double*> x("x", N), y("y", N);
        const double a = 2.0;

        Kokkos::parallel_for("init", N, KOKKOS_LAMBDA(int i) {
            x(i) = 1.0; y(i) = 2.0;
        });
        Kokkos::parallel_for("axpy", N, KOKKOS_LAMBDA(int i) {
            y(i) = a * x(i) + y(i);
        });

        double sum = 0.0;
        Kokkos::parallel_reduce("reduce", N,
            KOKKOS_LAMBDA(int i, double& s) { s += y(i); }, sum);

        std::printf("Execution space: %s\n",
                    Kokkos::DefaultExecutionSpace::name());
        std::printf("Sum: %g (expected %d)\n", sum, 4*N);
    }
    Kokkos::finalize();
    return 0;
}
