# Building Kokkos 5.1.1 Native on Windows 11 with CUDA 13.2 and RTX 5080 (sm_120)

This document captures the full build procedure for a configuration that is **not part of the Kokkos team's tested matrix**: native Windows + MSVC + CUDA + Blackwell consumer GPU. Every step works as of May 2026, but each requires a non-default flag or a source patch. Read the issue summary before starting so the patches make sense; copying commands without context is how this configuration breaks again on the next minor version bump.

---

## Tested configuration

| Component | Version |
| --- | --- |
| OS | Windows 11 Pro (build 26200) |
| GPU | NVIDIA GeForce RTX 5080 (Blackwell consumer, sm_120, 16 GB GDDR7) |
| Driver | NVIDIA 581.95 |
| Visual Studio | 2026 Professional, MSVC 14.50.35717 (cl 19.50.35724) |
| CUDA Toolkit | 13.2.78 |
| CMake | 4.1.1 |
| Kokkos | 5.1.1 |
| C++ standard | C++20 |
| Backends | Serial + CUDA |
| Architecture flag | `Kokkos_ARCH_BLACKWELL120` |

---

## Why this configuration needs patches

The Kokkos team's "Primary Tested Compilers" lists MSVC 19.29 (VS 2022 baseline). MSVC 14.50 (VS 2026) is well ahead of that, and CUDA 13.2 + sm_120 + Blackwell consumer is a brand-new combination NVIDIA itself only fully supported as of CUDA 13.2. The result: the out-of-the-box `cmake --build` hits five classes of issue in succession.

1. **`__CUDACC__` macro not defined when MSVC compiles a Kokkos-using TU.** Kokkos 5.x's CUDA backend expects nvcc-as-the-compiler semantics; on Windows nvcc is invoked per-TU as a CUDA-language object via CMake's first-class CUDA support. The fix is the CMake option `Kokkos_ENABLE_COMPILE_AS_CMAKE_LANGUAGE=ON` (documented but easy to miss).
2. **CUDA 13.x's CCCL headers require MSVC's standard-conforming preprocessor.** The traditional preprocessor is still MSVC's default, and CCCL emits `#error: MSVC traditional preprocessor not supported` from `cuda/std/__cccl/preprocessor.h` at the first translation unit. The fix is the flag `/Zc:preprocessor`, threaded through both host and CUDA host-side compilation paths.
3. **`__int128` is undefined.** desul (Kokkos's bundled atomics TPL) emits 16-byte atomic exchange / compare-exchange specializations for sm_90+ targets using GCC/Clang's `__int128` extension type. MSVC has never implemented `__int128`. On sm_120 (which is `>= 9.0`), every TU that pulls in atomics fails. **Source patch required.**
4. **`error C3520: 'P': parameter pack must be expanded`** in `Kokkos_ViewCtor.hpp(255)`. MSVC 14.50 conflates the literal class-name reference `ViewCtorProp<void, ...>` with the current instantiation (which uses pack `P`), triggering C3520. The Kokkos team already worked around this elsewhere in the same file using a type alias; they missed two constructors. **Source patch required.**
5. **Silent process death (`STATUS_STACK_BUFFER_OVERRUN`, `0xC0000409`) on the first kernel launch in downstream consumer projects.** This is a *runtime* failure, not a build error, and the most insidious of the five — the executable returns no stdout, no stderr, no message box, just an empty PowerShell prompt. Cause: nvcc's default on Windows is `-cudart static`, which links the static CUDA runtime built with `/MT` (LIBCMT). The Kokkos library and downstream test are built with `/MD` (MSVCRT). Two C runtimes initialize in the same process, and the conflict is detected by the CRT's fastfail handler before `main()` runs. Fix: explicitly select the shared CUDA runtime in downstream consumer CMakeLists with `set(CMAKE_CUDA_RUNTIME_LIBRARY Shared)`. **Required for every downstream project, not just polish.**

---

## Step-by-step

### Step 1: Install Visual Studio 2026 first

Visual Studio must be installed **before** the CUDA Toolkit, otherwise CUDA's Visual Studio Integration component silently fails to install and you get cryptic CMake errors later.

Install **Visual Studio 2026 Community/Professional** with the **"Desktop development with C++"** workload. Confirm MSVC ≥ 14.50 (Help → About).

### Step 2: Install CUDA Toolkit 13.2

Download from <https://developer.nvidia.com/cuda-downloads> (Windows → x86_64 → 11 → exe local).

In the installer, choose **Custom install** and **leave every component checked**. As of CUDA 13.1+ NVIDIA no longer bundles the display driver, so there is no driver downgrade to worry about — your existing 581.95 driver is untouched. Do NOT skip the Visual Studio Integration component.

Close all open shells after the install completes (PATH won't pick up nvcc until you open a fresh shell).

### Step 3: Verify the environment

Open a fresh PowerShell:

```powershell
nvcc --version    # Expect: release 13.2, V13.2.78
nvidia-smi        # Expect: GeForce RTX 5080, driver 581.95+
cmake --version   # Expect: 3.21+ (this guide tested with 4.1.1)
```

### Step 4: Clone Kokkos 5.1.1

```powershell
mkdir C:\KOKKOS
cd C:\KOKKOS
git clone --branch 5.1.1 --depth 1 https://github.com/kokkos/kokkos.git
```

Working tree will be at `C:\KOKKOS\kokkos`.

### Step 5: Apply patch 1 — desul `__int128` workaround

**File to replace:** `C:\KOKKOS\kokkos\tpls\desul\include\desul\atomics\cuda\cuda_cc9_asm_exchange_op.inc`

The patched file (`cuda_cc9_asm_exchange_op.inc`) is shipped alongside this document. It preserves the original GCC/Clang `__int128` + nvcc inline-asm path unchanged, and adds an `#if defined(_MSC_VER)` branch that provides a non-atomic stub for the 16-byte specializations. The stub satisfies the type system at the `pair_int_t` call site in `Kokkos_HostThreadTeam.cpp` (which is `Kokkos::pair<int64_t, int64_t>`, 16 bytes) and is dead device-side code in this Serial+CUDA configuration — instantiated by nvcc's host/device dual parsing but never called at runtime.

Backup and replace:

```powershell
$desul = "C:\KOKKOS\kokkos\tpls\desul\include\desul\atomics\cuda"
Copy-Item "$desul\cuda_cc9_asm_exchange_op.inc" "$desul\cuda_cc9_asm_exchange_op.inc.bak"
Copy-Item -Force "<download-dir>\cuda_cc9_asm_exchange_op.inc" "$desul\cuda_cc9_asm_exchange_op.inc"
```

### Step 6: Apply patch 2 — `Kokkos_ViewCtor.hpp` C3520 workaround

**File to replace:** `C:\KOKKOS\kokkos\core\src\View\Kokkos_ViewCtor.hpp`

Two edits inside the `ViewCtorProp<P...>` class body:

- **Line 241** — replace `ViewCtorProp<void, P>(std::forward<Args>(args))...` with `view_ctor_prop_base<P>(std::forward<Args>(args))...`.
- **Line 256** — replace `ViewCtorProp<void, pointer_type>(arg0)` with `view_ctor_prop_base<pointer_type>(arg0)`.

Both replacements route through the type alias `view_ctor_prop_base<T> = ViewCtorProp<void, T>` defined at line 191. The Kokkos team already used this exact workaround on the constructor at lines 248-252 (with an explanatory comment at lines 243-247: *"Using the alias view_ctor_prop_base here as below fixes the issue"*) and on the constructor at lines 263-270. They missed applying it to the two constructors above. MSVC 14.50 hits the C3520 where 14.41 didn't.

The patched file (`Kokkos_ViewCtor.hpp`) is shipped alongside this document. Replace:

```powershell
$viewdir = "C:\KOKKOS\kokkos\core\src\View"
Copy-Item "$viewdir\Kokkos_ViewCtor.hpp" "$viewdir\Kokkos_ViewCtor.hpp.bak"
Copy-Item -Force "<download-dir>\Kokkos_ViewCtor.hpp" "$viewdir\Kokkos_ViewCtor.hpp"
```

### Step 7: Configure the build

Open the **x64 Native Tools Command Prompt for VS 2026** (a normal `cmd.exe` or PowerShell will not have `cl.exe` on PATH). Then:

```batch
cd C:\KOKKOS\kokkos

cmake -B build -G "Visual Studio 18 2026" -A x64 ^
  -DCMAKE_INSTALL_PREFIX=C:\opt\kokkos ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DKokkos_ENABLE_CUDA=ON ^
  -DKokkos_ENABLE_COMPILE_AS_CMAKE_LANGUAGE=ON ^
  -DKokkos_ARCH_BLACKWELL120=ON ^
  -DKokkos_ENABLE_SERIAL=ON ^
  -DCMAKE_CXX_STANDARD=20 ^
  -DCMAKE_CXX_FLAGS="/Zc:preprocessor" ^
  -DCMAKE_CUDA_FLAGS="-Xcompiler /Zc:preprocessor"
```

Flag breakdown:

| Flag | Purpose |
| --- | --- |
| `-G "Visual Studio 18 2026"` | VS 2026 generator (VS 2022 is `17`, VS 2026 is `18`) |
| `Kokkos_ENABLE_CUDA=ON` | Enable CUDA backend |
| `Kokkos_ENABLE_COMPILE_AS_CMAKE_LANGUAGE=ON` | **Required on Windows.** Without it, MSVC compiles Kokkos-using TUs as C++ and the `__CUDACC__` check in `Kokkos_Setup_Cuda.hpp` fires. Forces nvcc as the language driver. |
| `Kokkos_ARCH_BLACKWELL120=ON` | sm_120 codegen (RTX 5080 / 5090 consumer Blackwell). Available since Kokkos 4.7. |
| `Kokkos_ENABLE_SERIAL=ON` | Host backend. OpenMP is intentionally not enabled — MSVC's bundled OpenMP is the legacy 2.0 implementation, and Kokkos's OpenMP backend wants 4.5+. |
| `CMAKE_CXX_STANDARD=20` | Required by Kokkos 5.x. |
| `/Zc:preprocessor` | Standard-conforming preprocessor. Required by CUDA 13.x's CCCL headers. Threaded through both CXX and CUDA host-side compilation. |

Successful configure output should report:

```
-- Built-in Execution Spaces:
--     Device Parallel: Kokkos::Cuda
--     Host Parallel: NoTypeDefined
--       Host Serial: SERIAL
-- Architectures:
--  BLACKWELL120
-- Kokkos Backends: SERIAL;CUDA
```

### Step 8: Build and install

```batch
cmake --build build --config Release --parallel
cmake --install build --config Release
```

Build takes 15-25 minutes on a 24-core CPU. Successful build produces:

- `kokkoscore.lib`
- `kokkosalgorithms.lib`
- `kokkossimd.lib`
- `kokkoscontainers.lib`

Install lands headers and libs in `C:\opt\kokkos`.

### Step 9: Verify with `axpy_test`

Create a fresh directory (e.g. `C:\KOKKOS\axpy_test`) and drop in two files.

`axpy_test.cpp`:

```cpp
#include <Kokkos_Core.hpp>
#include <cstdio>

int main(int argc, char* argv[]) {
    Kokkos::initialize(argc, argv);
    {
        const int N = 1 << 20;
        Kokkos::View<double*> x("x", N), y("y", N);
        const double a = 2.0;

        Kokkos::parallel_for("init", N, KOKKOS_LAMBDA(int i) {
            x(i) = 1.0; y(i) = 2.0;
        });
        Kokkos::parallel_for("axpy", N, KOKKOS_LAMBDA(int i) {
            y(i) = a * x(i) + y(i);
        });

        double sum = 0.0;
        Kokkos::parallel_reduce("reduce", N,
            KOKKOS_LAMBDA(int i, double& s) { s += y(i); }, sum);

        std::printf("Execution space: %s\n",
                    Kokkos::DefaultExecutionSpace::name());
        std::printf("Sum: %g (expected %d)\n", sum, 4*N);
    }
    Kokkos::finalize();
    return 0;
}
```

`CMakeLists.txt`:

```cmake
cmake_minimum_required(VERSION 3.21)
project(axpy_test LANGUAGES CXX CUDA)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CUDA_STANDARD 20)

# Match the architecture Kokkos was built for (sm_120 / consumer Blackwell).
# Without this, CMake defaults to compute_75 and you get PTX-JIT mismatches
# at runtime that are hard to diagnose.
set(CMAKE_CUDA_ARCHITECTURES 120)

# Shared CUDA runtime — must match /MD (dynamic CRT) used by Kokkos.
# Default nvcc on Windows uses -cudart static (LIBCMT, /MT) which conflicts
# with our /MD build. The mismatch causes silent process death at startup
# (exit code 0xC0000409 STATUS_STACK_BUFFER_OVERRUN, no output at all).
# This setting is mandatory, not optional.
set(CMAKE_CUDA_RUNTIME_LIBRARY Shared)

find_package(Kokkos REQUIRED HINTS "C:/opt/kokkos")
add_executable(axpy_test axpy_test.cpp)

# Compile our .cpp through nvcc — required for any TU containing Kokkos kernels
# when Kokkos was built with COMPILE_AS_CMAKE_LANGUAGE=ON.
set_source_files_properties(axpy_test.cpp PROPERTIES LANGUAGE CUDA)

# Same MSVC standard-conforming preprocessor flag Kokkos was built with.
target_compile_options(axpy_test PRIVATE
  $<$<COMPILE_LANGUAGE:CUDA>:-Xcompiler=/Zc:preprocessor>
  $<$<COMPILE_LANGUAGE:CXX>:/Zc:preprocessor>)

target_link_libraries(axpy_test PRIVATE Kokkos::kokkos)
```

Build and run from the same x64 Native Tools Command Prompt:

```batch
cmake -B build -G "Visual Studio 18 2026" -A x64
cmake --build build --config Release
build\Release\axpy_test.exe
```

Expected output:

```
Execution space: Cuda
Sum: 4.1943e+06 (expected 4194304)
```

Confirm the build is using the right flags by checking the nvcc command line in the build output:

- `--generate-code=arch=compute_120,code=[compute_120,sm_120]` (not `compute_75`)
- `-cudart shared` (not `-cudart static`)

You will see two non-fatal warnings that are safe to ignore for this configuration:

- `nvcc warning: 'shared' is a deprecated value for option '--cudart'. Use 'hybrid' instead.` — CUDA 13 renamed the option; CMake's `CMAKE_CUDA_RUNTIME_LIBRARY=Shared` still emits the older spelling. Functionally equivalent.
- `LINK : warning LNK4098: defaultlib 'LIBCMT' conflicts` — pulled in by `cudadevrt.lib` (CUDA device runtime, statically linked regardless of `-cudart`). Does not cause runtime failure once `-cudart shared` is set.

If `Execution space: Cuda` and the sum is correct, the install is functional and kernels are running on the RTX 5080.

If the executable produces **no output at all** and `$LASTEXITCODE` is `-1073740791` (`0xC0000409`), the `set(CMAKE_CUDA_RUNTIME_LIBRARY Shared)` line is missing or wasn't picked up — see issue #5 in the issue summary above.

If `Execution space: Serial`, the GPU backend didn't link. The most common cause is a missing `set_source_files_properties(... LANGUAGE CUDA)` directive on the offending `.cpp` file in the downstream project.

---

## Downstream consumer projects: the rules that bite

Every project consuming this Kokkos install must do four things, three of which produce diagnostic build/link errors and one of which produces a silent runtime crash if forgotten.

### Rule 1: Compile Kokkos-touching translation units as CUDA

Every `.cpp` source file that references `Kokkos::View` or any `Kokkos::parallel_*` call must be compiled as CUDA, not as C++. This is a consequence of `Kokkos_ENABLE_COMPILE_AS_CMAKE_LANGUAGE=ON` — without it, the host compiler (MSVC) hits `Kokkos_Setup_Cuda.hpp`'s `#error: KOKKOS_ENABLE_CUDA defined but the compiler is not defining the __CUDACC__ macro as expected`.

The cleanest pattern for a real codebase is a filename convention plus a glob:

```cmake
file(GLOB_RECURSE KOKKOS_SRCS CONFIGURE_DEPENDS "src/*_kokkos.cpp")
set_source_files_properties(${KOKKOS_SRCS} PROPERTIES LANGUAGE CUDA)
```

Name kernel-bearing translation units `*_kokkos.cpp` (or pick any suffix). Files that don't touch Kokkos kernels stay regular `.cpp` and compile with cl.exe — much faster than routing every TU through nvcc. The boundary between "compile-with-cl" and "compile-with-nvcc" then lives at the filename level, which is grep-able and reviewable.

### Rule 2: Match the architecture

Set `CMAKE_CUDA_ARCHITECTURES` to match the architecture Kokkos was built for. Without this, CMake's CUDA default kicks in (currently sm_75 / Turing) and you get PTX-JIT translation at runtime — slower first launch, and a potential failure surface if Kokkos's templates instantiated in your TU rely on architecture-specific features.

```cmake
set(CMAKE_CUDA_ARCHITECTURES 120)
```

### Rule 3: Use the shared CUDA runtime

This is the one that bites silently. nvcc's default on Windows is `-cudart static`, which links the static CUDA runtime built with `/MT` (LIBCMT). Kokkos and your downstream project are built with `/MD` (MSVCRT). Mixing the two C runtimes in one process triggers the CRT's fastfail handler before `main()` runs — the executable returns exit code `0xC0000409` (`STATUS_STACK_BUFFER_OVERRUN`) with no output. There is no error message, no message box, no stderr. The link warning `LNK4098: defaultlib 'LIBCMT' conflicts with use of other libs` is the only signal during build, and it's easy to dismiss as benign.

```cmake
set(CMAKE_CUDA_RUNTIME_LIBRARY Shared)
```

This setting is mandatory for any downstream consumer of a Kokkos install built with `/MD`, which is the configuration this guide produces.

### Rule 4: Pass `/Zc:preprocessor` through

The same MSVC standard-conforming preprocessor flag used for the Kokkos build must flow through to every consumer translation unit, both CXX and CUDA. The pattern from the verification project's CMakeLists.txt generalises:

```cmake
target_compile_options(my_target PRIVATE
  $<$<COMPILE_LANGUAGE:CUDA>:-Xcompiler=/Zc:preprocessor>
  $<$<COMPILE_LANGUAGE:CXX>:/Zc:preprocessor>)
```

Without this flag, the first translation unit that pulls in CCCL headers fails with `fatal error C1189: MSVC traditional preprocessor not supported`.

---

## What the patches actually do

### Patch 1: `cuda_cc9_asm_exchange_op.inc`

The original file is a macro-driven include that emits two template specialisations (`device_atomic_exchange` and `device_atomic_compare_exchange`) constrained to `sizeof(ctype) == 16`. It uses GCC/Clang's `__int128` extension type as the operand passed through nvcc inline asm via the `"q"` (128-bit register) constraint.

The patch keeps the original code intact for all non-MSVC compilers (the `#else` branch) and adds an `#if defined(_MSC_VER)` branch that provides:

- `device_atomic_exchange` for 16-byte types: read old value, overwrite, return old. Not atomic.
- `device_atomic_compare_exchange` for 16-byte types: read old value, byte-wise compare against `compare`, conditionally overwrite, return old. Not atomic.

This satisfies the type system at the call site in `Kokkos_HostThreadTeam.cpp` where `Kokkos::atomic_compare_exchange<pair_int_t>` is instantiated. The `pair_int_t` type is `Kokkos::pair<int64_t, int64_t>`, exactly 16 bytes. On the host side (where this code logically runs in this Serial-only build) there is no concurrency, so the non-atomic fallback is observationally equivalent to a real atomic. On the GPU device side these specialisations are dead code — instantiated only because nvcc parses host functions for both host and device contexts, never actually called.

For builds that enable threaded host backends (OpenMP, Threads), this patch is **not safe** — the work-stealing CAS would race. Don't use this patch for such builds.

### Patch 2: `Kokkos_ViewCtor.hpp`

Two single-line replacements inside the body of `template <typename... P> struct ViewCtorProp`. Both substitute the literal type expression `ViewCtorProp<void, ...>` with the alias `view_ctor_prop_base<...>`, which is defined at line 191 as `template <typename Arg> using view_ctor_prop_base = ViewCtorProp<void, Arg>;`.

The aliases are semantically identical to the literal forms; the Kokkos team introduced them specifically to dodge MSVC's tendency to conflate the literal class-name reference with "the current instantiation" (in C++ Standard terms) and emit C3520 / C3528 errors. The same pattern was already applied to two other constructors in the same class. The patched constructors are simply two more cases that need the same workaround on MSVC 14.50.

---

## Limitations and caveats

- **Threaded host backends are unsupported in this configuration.** OpenMP cannot be enabled with MSVC's bundled (legacy 2.0) implementation, and the Patch 1 stub fallback for 16-byte atomics would race under any real concurrency. If host parallelism is needed, build separately with OpenMP via clang-cl or use the V100/Linux side of the workflow.
- **16-byte atomic operations on the GPU are non-functional.** They compile but don't perform real hardware atomics. No common Kokkos code path actually exercises 16-byte atomics on the device for typical workloads, but bespoke kernels using `Kokkos::atomic_*` on 16-byte types will silently produce incorrect results.
- **MSVC version drift will probably break things again.** MSVC 14.51 may fix the C3520 conformance bug (rendering Patch 2 harmlessly redundant), or it may move the failure to a different line in the same file. CCCL's `/Zc:preprocessor` requirement may relax. The desul `__int128` issue should eventually get an upstream fix from the Kokkos team.
- **CUDA version drift may break things again.** CUDA 13.3 / 14.0 will likely change CCCL header internals; if you upgrade, expect to re-evaluate the build flags.
- **Kokkos version drift will definitely break things again.** Both file patches are tied to specific source line numbers in 5.1.1. Upgrading Kokkos requires re-applying the same kind of workarounds, possibly in different files.

---

## Files in this package

- `Kokkos-Windows-CUDA-Build-Guide.md` — this document
- `cuda_cc9_asm_exchange_op.inc` — Patch 1, drops into `tpls/desul/include/desul/atomics/cuda/`
- `Kokkos_ViewCtor.hpp` — Patch 2, drops into `core/src/View/`
- `axpy_test.cpp` — verification source
- `CMakeLists.txt` — verification project CMake file (also serves as a reference template for downstream consumers)
