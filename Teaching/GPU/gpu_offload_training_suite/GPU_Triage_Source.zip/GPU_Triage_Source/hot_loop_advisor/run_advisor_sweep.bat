@echo off
REM ============================================================
REM  run_advisor_sweep.bat
REM
REM  CMake-driven Intel Advisor sweep for N=224, 512, 1024.
REM
REM  This intentionally builds through CMake instead of calling cl.exe
REM  directly. CMakeLists.txt owns the profiling build flags:
REM      Release-shape optimized code + debug symbols
REM      /O2 /Zi /DEBUG:FULL /MD, not Debug mode
REM
REM  Usage:
REM      run_advisor_sweep.bat
REM
REM  Optional:
REM      run_advisor_sweep.bat --survey-only
REM      run_advisor_sweep.bat --no-tripcounts
REM      run_advisor_sweep.bat --clean-build
REM      run_advisor_sweep.bat --skip-build
REM
REM  Run from an Intel oneAPI / VS x64 command prompt.
REM ============================================================

setlocal EnableExtensions EnableDelayedExpansion

REM Project root is the directory containing this BAT.
pushd "%~dp0" || exit /b 1
set "PROJ_BASE=%CD%"
set "BUILD_DIR=%PROJ_BASE%\build"
set "CONFIG=Release"
set "TOML=%PROJ_BASE%\nvidia_rtx_5080.toml"
set "RESULTS=%PROJ_BASE%\advisor_sweep_results.txt"
set "BASE_TARGET=xehpg_512xve"

set "SURVEY_ONLY=0"
set "SKIP_BUILD=0"
set "CLEAN_BUILD=0"

:ParseArgs
if "%~1"=="" goto DoneParseArgs
if /I "%~1"=="--survey-only" (
    set "SURVEY_ONLY=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--no-tripcounts" (
    set "SURVEY_ONLY=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--with-tripcounts" (
    set "SURVEY_ONLY=0"
    shift
    goto ParseArgs
)
if /I "%~1"=="--skip-build" (
    set "SKIP_BUILD=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--clean-build" (
    set "CLEAN_BUILD=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--fresh-cmake" (
    set "CLEAN_BUILD=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--help" call :Help & popd & exit /b 0
if /I "%~1"=="/help" call :Help & popd & exit /b 0

echo [FAIL] Unknown option: %~1
echo.
call :Help
popd
exit /b 1

:DoneParseArgs

where advisor >nul 2>&1
if errorlevel 1 (
    echo [FAIL] advisor not found on PATH. Run from the Intel oneAPI command prompt.
    popd
    exit /b 1
)

where cmake >nul 2>&1
if errorlevel 1 (
    echo [FAIL] cmake not found on PATH. Install CMake or open a VS/oneAPI prompt with CMake available.
    popd
    exit /b 1
)

if not exist "%PROJ_BASE%\CMakeLists.txt" (
    echo [FAIL] CMakeLists.txt not found in %PROJ_BASE%
    popd
    exit /b 1
)

if not exist "%TOML%" (
    echo [FAIL] TOML not found: %TOML%
    popd
    exit /b 1
)

if "%SKIP_BUILD%"=="1" (
    echo === Skipping CMake build because --skip-build was requested ===
) else (
    if "%CLEAN_BUILD%"=="1" (
        if exist "%BUILD_DIR%" (
            echo === Removing build directory: %BUILD_DIR% ===
            rmdir /s /q "%BUILD_DIR%"
        )
    )

    REM Avoid profiling a stale direct-cl binary in the source directory.
    REM If the updated CMakeLists writes to HOT_LOOP_RUNTIME_DIR, CMake will recreate it.
    if exist "%PROJ_BASE%\hot_loop_win.exe" del /f /q "%PROJ_BASE%\hot_loop_win.exe" >nul 2>&1
    if exist "%PROJ_BASE%\hot_loop_win.pdb" del /f /q "%PROJ_BASE%\hot_loop_win.pdb" >nul 2>&1

    echo === Configuring optimized profiling build with CMake ===
    echo     Release build + debug symbols; not Debug mode.
    cmake -S "%PROJ_BASE%" -B "%BUILD_DIR%" ^
        -DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=ProgramDatabase ^
        -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreadedDLL ^
        "-DHOT_LOOP_RUNTIME_DIR:PATH=%PROJ_BASE%" ^
        -DHOT_LOOP_NATIVE_ISA=ON ^
        -DHOT_LOOP_KEEP_FRAME_POINTERS=ON
    if errorlevel 1 (
        echo [FAIL] CMake configure failed
        popd
        exit /b 1
    )

    echo === Building hot_loop_win through CMake target hot_loop_win ===
    cmake --build "%BUILD_DIR%" --config %CONFIG% --target hot_loop_win
    if errorlevel 1 (
        echo [FAIL] CMake build failed
        popd
        exit /b 1
    )
)

call :ResolveExe
if errorlevel 1 (
    popd
    exit /b 1
)

call :ResolvePdb

echo.
echo [OK] Using CMake-built executable: %EXE%
if defined PDB (
    echo [OK] Found debug symbols: %PDB%
) else (
    echo [WARN] hot_loop_win.pdb was not found next to the executable or under the build dir.
    echo        Advisor can still run, but source attribution may be weaker.
)
echo.

> "%RESULTS%" echo Advisor Sweep Results
>> "%RESULTS%" echo =====================
>> "%RESULTS%" echo Build system    : CMake
>> "%RESULTS%" echo Build directory : %BUILD_DIR%
>> "%RESULTS%" echo Executable      : %EXE%
if defined PDB >> "%RESULTS%" echo PDB             : %PDB%
>> "%RESULTS%" echo.

call :RunSize "N=224"  50000 224  4096
if errorlevel 1 goto SweepFailed
call :RunSize "N=512"  5000  512  8192
if errorlevel 1 goto SweepFailed
call :RunSize "N=1024" 1000  1024 32768
if errorlevel 1 goto SweepFailed

echo.
echo ============================================================
echo   DONE. Reports saved to %RESULTS%
echo ============================================================
type "%RESULTS%"
popd
exit /b 0

:SweepFailed
echo.
echo ============================================================
echo   FAILED. Partial results saved to %RESULTS%
echo ============================================================
if exist "%RESULTS%" type "%RESULTS%"
popd
exit /b 1

REM ============================================================
:ResolveExe
REM Prefer source-dir output because the updated CMakeLists writes there.
REM Fall back to common CMake output directories for compatibility with the
REM older uploaded CMakeLists.txt.
REM ============================================================
set "EXE="
if exist "%PROJ_BASE%\hot_loop_win.exe" set "EXE=%PROJ_BASE%\hot_loop_win.exe"
if not defined EXE if exist "%BUILD_DIR%\%CONFIG%\hot_loop_win.exe" set "EXE=%BUILD_DIR%\%CONFIG%\hot_loop_win.exe"
if not defined EXE if exist "%BUILD_DIR%\hot_loop_win.exe" set "EXE=%BUILD_DIR%\hot_loop_win.exe"
if not defined EXE if exist "%BUILD_DIR%\x64\%CONFIG%\hot_loop_win.exe" set "EXE=%BUILD_DIR%\x64\%CONFIG%\hot_loop_win.exe"

if not defined EXE (
    for /f "delims=" %%F in ('dir /s /b "%BUILD_DIR%\hot_loop_win.exe" 2^>nul') do (
        set "EXE=%%F"
        goto FoundExe
    )
)

:FoundExe
if not defined EXE (
    echo [FAIL] Could not find hot_loop_win.exe after CMake build.
    echo        Checked:
    echo        %PROJ_BASE%\hot_loop_win.exe
    echo        %BUILD_DIR%\%CONFIG%\hot_loop_win.exe
    echo        %BUILD_DIR%\hot_loop_win.exe
    echo        %BUILD_DIR%\x64\%CONFIG%\hot_loop_win.exe
    exit /b 1
)
exit /b 0

REM ============================================================
:ResolvePdb
set "PDB="
for %%F in ("%EXE%") do set "EXE_DIR=%%~dpF"

if exist "%EXE_DIR%hot_loop_win.pdb" set "PDB=%EXE_DIR%hot_loop_win.pdb"
if not defined PDB if exist "%PROJ_BASE%\hot_loop_win.pdb" set "PDB=%PROJ_BASE%\hot_loop_win.pdb"
if not defined PDB if exist "%BUILD_DIR%\%CONFIG%\hot_loop_win.pdb" set "PDB=%BUILD_DIR%\%CONFIG%\hot_loop_win.pdb"
if not defined PDB if exist "%BUILD_DIR%\hot_loop_win.pdb" set "PDB=%BUILD_DIR%\hot_loop_win.pdb"

if not defined PDB (
    for /f "delims=" %%F in ('dir /s /b "%BUILD_DIR%\hot_loop_win.pdb" 2^>nul') do (
        set "PDB=%%F"
        goto FoundPdb
    )
)
:FoundPdb
exit /b 0

REM ============================================================
:RunSize
REM %1=label  %2=n_outer  %3=n_dim  %4=buf_len
REM ============================================================
set "LABEL=%~1"
set "ITERS=%2"
set "NDIM=%3"
set "BUFLEN=%4"
set "PDIR=%PROJ_BASE%\proj_%NDIM%"
set "DATA=%PDIR%\e000\pp000\data.0"

echo.
echo === %LABEL% ^(iters=%ITERS% dim=%NDIM% buf=%BUFLEN%^) ===
>> "%RESULTS%" echo --- %LABEL% ---

if exist "%PDIR%\e000" rmdir /s /q "%PDIR%\e000" 2>nul

echo   [1/3] Survey...
advisor --collect=survey --static-instruction-mix ^
    --project-dir="%PDIR%" ^
    --search-dir src:r="%PROJ_BASE%" ^
    -- "%EXE%" %ITERS% %NDIM% %BUFLEN%
if errorlevel 1 (
    echo   [FAIL] Survey failed for %LABEL%
    >> "%RESULTS%" echo Survey FAILED
    exit /b 1
)
echo   [OK] Survey

if "%SURVEY_ONLY%"=="1" (
    echo   [2/3] Characterization SKIPPED: survey-only mode
    echo   [3/3] Projection SKIPPED: projection needs Characterization/tripcounts data
    >> "%RESULTS%" echo Survey completed; projection intentionally skipped.
    >> "%RESULTS%" echo.
    exit /b 0
)

echo   [2/3] Characterization: Trip Counts + FLOP + cache/data-transfer modeling...
advisor --collect=tripcounts --flop --stacks ^
    --cache-simulation=single ^
    --target-device=%BASE_TARGET% ^
    --data-transfer=light ^
    --project-dir="%PDIR%" ^
    --search-dir src:r="%PROJ_BASE%" ^
    -- "%EXE%" %ITERS% %NDIM% %BUFLEN%
if errorlevel 1 (
    echo   [FAIL] Characterization failed for %LABEL%
    >> "%RESULTS%" echo Characterization FAILED
    exit /b 1
)
echo   [OK] Characterization

echo   [3/3] Projection...
advisor --collect=projection ^
    --project-dir="%PDIR%" ^
    --custom-config="%TOML%"
if errorlevel 1 (
    echo   [FAIL] Projection command failed for %LABEL%
    >> "%RESULTS%" echo Projection FAILED
    exit /b 1
)

if not exist "%DATA%\report.csv" (
    echo   [FAIL] Projection did not produce %DATA%\report.csv
    >> "%RESULTS%" echo Projection produced no report.csv. Check Advisor stdout above.
    exit /b 1
)
if not exist "%DATA%\whole_app_metrics.csv" (
    echo   [FAIL] Projection did not produce %DATA%\whole_app_metrics.csv
    >> "%RESULTS%" echo Projection produced no whole_app_metrics.csv. Check Advisor stdout above.
    exit /b 1
)

echo   [OK] Projection

>> "%RESULTS%" echo.
>> "%RESULTS%" echo %LABEL% Projection Data Directory:
>> "%RESULTS%" echo %DATA%
>> "%RESULTS%" echo.
>> "%RESULTS%" echo %LABEL% whole_app_metrics.csv:
type "%DATA%\whole_app_metrics.csv" >> "%RESULTS%"
>> "%RESULTS%" echo.
>> "%RESULTS%" echo %LABEL% config verification:
if exist "%DATA%\config.toml" (
    findstr /i /c:"device_name" /c:"device_id" /c:"Frequency" /c:"Memory_BW" "%DATA%\config.toml" >> "%RESULTS%"
) else (
    >> "%RESULTS%" echo config.toml not found
)
>> "%RESULTS%" echo.
>> "%RESULTS%" echo %LABEL% report.csv is available at:
>> "%RESULTS%" echo %DATA%\report.csv
>> "%RESULTS%" echo.

echo   [OK] CSV paths extracted
exit /b 0

:Help
echo Usage:
echo   run_advisor_sweep.bat [--survey-only] [--clean-build] [--skip-build]
echo.
echo Options:
echo   --survey-only    Build through CMake and run Advisor Survey only.
echo   --no-tripcounts  Alias for --survey-only.
echo   --with-tripcounts Run the full Survey + Tripcounts + Projection flow. This is the default.
echo   --clean-build    Delete the CMake build directory before configure/build.
echo   --fresh-cmake    Alias for --clean-build.
echo   --skip-build     Do not run CMake; use an existing hot_loop_win.exe.
exit /b 0
