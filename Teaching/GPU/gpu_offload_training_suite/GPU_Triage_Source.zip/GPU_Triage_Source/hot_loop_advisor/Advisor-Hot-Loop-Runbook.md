# Advisor Offload Modeling for `hot_loop_win.c`

Companion documentation for `run_advisor.bat`. The script does the work; this file explains what it's doing, why, and how to read the output.

This is teaching scaffolding. The verdict from the projection is "don't offload" — that's the *correct* answer for this workload on this card. The value is the workflow.

---

## Layout

```
C:\KOKKOS\hot_loop_advisor\        <-- working dir, project root, all paths relative to here
├── hot_loop_win.c                 source
├── CMakeLists.txt                 build config
├── nvidia_rtx_5080_v3.toml        device model for projection
├── run_advisor.bat                automation
├── build\hot_loop_win.exe         binary
└── e000\                          Advisor-generated experiment data
    ├── hs000\                       survey collection
    ├── trc000\                      tripcounts collection
    ├── pp000\                       projection collection
    │   └── data.0\
    │       ├── report.csv             per-loop projection table (the goldmine)
    │       ├── whole_app_metrics.csv  headline numbers
    │       ├── roofs.csv              per-precision peak FLOPS
    │       ├── config.toml            THE config Advisor used (override verification)
    │       └── report.html            standalone browser-viewable report
    └── report\
        └── advisor-report.html       Vue.js shell, needs GUI to populate
```

The Advisor project lives **inside** the working tree, not in a sibling `C:\advisor_results\`. This matters: Advisor stores collection paths relative to the project root, and a project located outside the working tree breaks `build\hot_loop_win.exe` lookups when the GUI tries to re-collect.

---

## Prerequisites

- Intel oneAPI 2025.4 (or compatible) installed.
- Build the binary first (CMake/Ninja or direct `icx /O2 /Zi /MD /std:c11 /QxHost /Qopt-report:3`). Avoid `/Ox`, `/fast`, `/fp:fast` — those change FP semantics and break checksum equivalence with the Linux/Kokkos variants.
- The five-phase smoke test passes:
  ```
  build\hot_loop_win.exe
  ```
  Should run in ~18-20s on a 285K-class CPU and end with a checksum and per-phase timers. If this doesn't run cleanly, Advisor will not save you.

## Running

From an Intel oneAPI command prompt — not PowerShell, not Git Bash:

```bat
cd C:\KOKKOS\hot_loop_advisor
run_advisor
```

That's it. The script wipes stale `e000\`, runs survey (~30s) → tripcounts (~15-20 min) → projection (~5s), prints the verification block, and opens the GUI.

If you're iterating on teaching materials and don't need cache simulation data, edit the script's tripcounts step to drop `--enable-cache-simulation` and `--stacks` — that cuts tripcounts to ~30s.

---

## Reading the output

After `run_advisor` completes, the most useful files are in `e000\pp000\data.0\`.

### Headline (`whole_app_metrics.csv`)

For hot_loop on the 5080 expect:

```
Total CPU time           18.28 s
Overall speedup           1.013×    ← 1.3% improvement, basically nothing
Speedup on accelerated    1.853×
Fraction accelerated      ~3%
Number of offloads        1
Total launch tax          0.25 s    ← 90% of accelerated time
```

The "1.3% overall, 90% launch-tax" picture is the lesson: *Advisor identified one tiny offloadable region, and even that region is mostly burning CPU↔GPU dispatch overhead.*

### Per-loop verdict (`report.csv`)

The table below is the actual May 2026 measured outcome — not predictions. Sorted by self-time:

| Loop | Self | GPU est | Speedup | Bounded by | Verdict |
| --- | --- | --- | --- | --- | --- |
| `cholesky:161` (vec body) | 3.27s | 3.27s | 1.00× | Launch_Tax + Trip_Count + Latencies | rejected — not profitable |
| `raw_aij` (func) | 2.97s | 11.09s | 0.27× | (not a loop) | can't model |
| `build_matrix:128` | 1.74s | 12.82s | 0.14× | **Dependency** + Latencies | rejected — 7× slower on GPU |
| `cholesky:150` | 0.64s | 4.14s | 0.15× | **Dependency** + Latencies | rejected — 7× slower on GPU |
| `transform_buffer:66` | 0.11s | 0.51s | (offloaded) | Launch_Tax + Latencies + GTI_BW | **★ the one offload** |
| `cholesky:148` (head) | 0.07s | 4.50s | 0.02× | **Dependency** + Latencies | rejected — 50× slower |
| `backward_solve:190` | 0.24s | 0.24s | 1.00× | Launch_Tax + Trip_Count | rejected — too small |
| `forward_solve:177` | 0.05s | 0.12s | 0.38× | Dependency + Latencies | rejected |
| `update_state:203` | 0.02s | — | — | — | filtered, too small |

Every Advisor concept is represented:

- **Dependency** (build_matrix, cholesky variants) — algorithmic serialization; SIMT GPU loses to the CPU's vector + cache hierarchy. Graphs/megakernels don't fix this; only algorithmic restructuring (block cholesky, batched cholesky across iters) does.
- **Launch_Tax** (cholesky vec body, solves) — small kernels where dispatch overhead drowns the work. *This* is what Kokkos Graph addresses.
- **Trip_Count** (same loops) — same diagnosis said differently: not enough iterations per call to amortize launch.
- **Latencies** — GPU memory latency for non-coalesced or scalar accesses. Pervasive.
- **GTI_BW** (transform_buffer) — global memory interface bandwidth, the closest thing to "memory bandwidth bound" in Advisor's vocabulary.
- **"Cannot be modelled: Not a Loop"** (raw_aij) — Advisor's offload model is loop-centric; pure function calls fall outside it.

### Verifying the TOML override took effect (`config.toml`)

```bat
type e000\pp000\data.0\config.toml
```

Should reproduce most of `nvidia_rtx_5080_v3.toml`, with `XVE_count` renamed to `EU_count` and `XVE_per_core` to `EU_per_subslice` because Advisor uses Xe-HPG vocabulary internally. The `device_id = "nvidia_rtx_5080"` and the bandwidth/size values prove your custom values are in use.

### Roofline plot data (`roofs.csv`, `roofline_estimates.csv`)

`roofs.csv` lists the modeled hardware ceilings (peak GFLOPS for each precision and op type, plus bandwidth roofs). `roofline_estimates.csv` gives per-loop coordinates (arithmetic intensity, achieved GFLOPS) — that's where each dot lives on the Survey & Roofline view.

---

## Modeling caveat for FP64 on consumer NVIDIA

Advisor's compute model assumes **FP64 throughput equals FP32 throughput** for any platform you select. On Intel Ponte Vecchio and Xe-HPG this is roughly accurate. On consumer NVIDIA Blackwell (RTX 5080) **FP64 is 1:64 of FP32** — about 0.83 TFLOPS vs 53 TFLOPS.

There is no exposed knob in Advisor's TOML to override the per-precision throughput ratio. The `[[Roofs]]` table syntax that v2 of the TOML attempted is silently ignored by Advisor 2025.4. So the `Float64 MAD Peak` reported in `roofs.csv` will be ~14 TFLOPS regardless of TOML edits — about 17× too high for the actual 5080.

For hot_loop, which is FP64-dominant, Advisor's GPU time estimates are best-case-only. The fact that the conservative model still recommends *not* offloading means the real-world result would be even worse than projected.

This itself is a teaching beat: production performance-modeling tools have abstraction boundaries. Knowing where they are and how to mentally correct for them is the discipline.

---

## GUI navigation

The script opens the GUI at the project. To find your way:

1. **Perspective dropdown** (top center): set to **Offload Modeling** for the projection-focused tabs (Summary / Accelerated Regions / Source View). Set to **CPU / Memory Roofline** for the Survey & Roofline visual.
2. **Tabs by perspective**:
   - Summary — headline numbers, top offloaded/non-offloaded
   - Accelerated Regions / Code Regions — per-loop table, sortable
   - Source View — code annotated with per-line metrics
   - Survey & Roofline — the dot-on-chart view
   - Refinement Reports — Memory Access Patterns and Dependencies analyses (separate collections, not run by default)
3. **The "Cannot find application file 'build\hot_loop_win.exe'" banner** — irrelevant for viewing existing data. Cancel it. Only matters if you re-collect from inside the GUI.

For browser-only viewing without the GUI, open `e000\pp000\data.0\report.html` directly (different file from `e000\report\advisor-report.html`).

---

## Files in this package

- `hot_loop_win.c` — Windows port of the toy benchmark
- `nvidia_rtx_5080_v3.toml` — device model for projection
- `run_advisor.bat` — automation script
- `Advisor-Hot-Loop-Runbook.md` — this document
