/* hot_loop_win.c -- CPU baseline with runtime-configurable dimensions.
 * Usage: hot_loop_win.exe [n_outer] [n_dim] [buf_len]
 * Defaults: 1000 1024 32768
 *
 * Crossover sweep:
 *   hot_loop_win.exe 50000 224 4096
 *   hot_loop_win.exe 5000  512 8192
 *   hot_loop_win.exe 1000  1024 32768
 * Build: cl /O2 /Zi /MD hot_loop_win.c */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

static double wall_seconds(void) {
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER now;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    return (double)now.QuadPart / (double)freq.QuadPart;
}
static __inline double safe_log(double x) {
    return (x > 1e-300) ? log(x) : -700.0;
}

static void transform_buffer(const double* __restrict in, double* __restrict out,
    double* __restrict flags, int n) {
    for (int k = 0; k < n; ++k) {
        const double v = in[k], a = fabs(v)+1e-12, lv = safe_log(a);
        if (lv > 5.0) { double s=(v>=0)?1.0:-1.0; out[k]=s*exp(0.5*lv); flags[k]=1.0; }
        else if (lv < -5.0) { double v2=v*v; out[k]=v*(1.0+0.5*v2+0.125*v2*v2); flags[k]=-1.0; }
        else { double t=tanh(v); out[k]=exp(lv)*t-0.1*v; flags[k]=(v>=0)?0.5:-0.5; }
    }
}

static __inline double raw_aij(int i, int j, int n_dim, int buf_len,
    const double* __restrict buf, const double* __restrict flags) {
    int bi=(i*7+3)&(buf_len-1), bj=(j*11+5)&(buf_len-1);
    double xi=buf[bi], xj=buf[bj], fi=flags[bi], fj=flags[bj];
    if (i==j) return xi*xi+0.5*xj*xj+(double)n_dim+1.0;
    int d=(i>j)?(i-j):(j-i); double dx=xi-xj, decay=exp(-0.01*(double)d);
    if (fi*fj>0.25) return 0.30*xi*xj*decay;
    else if (fi*fj<-0.25) return -0.10*dx*decay;
    else if (d<4) return 0.20*(xi+xj)*decay;
    else return 0.02*(xi-xj)*decay;
}

static void build_matrix(const double* __restrict buf, const double* __restrict flags,
    double* __restrict A, int n_dim, int buf_len) {
    for (int i=0; i<n_dim; ++i) for (int j=0; j<=i; ++j) {
        double aij;
        if (i==j) aij=raw_aij(i,i,n_dim,buf_len,buf,flags);
        else { aij=0.5*(raw_aij(i,j,n_dim,buf_len,buf,flags)+raw_aij(j,i,n_dim,buf_len,buf,flags)); }
        A[i*n_dim+j]=aij; if(i!=j) A[j*n_dim+i]=aij;
    }
}

static int cholesky_inplace(double* __restrict A, int n) {
    for (int j=0; j<n; ++j) {
        double diag=A[j*n+j];
        for (int k=0; k<j; ++k) { double l=A[j*n+k]; diag-=l*l; }
        if (!(diag>0.0)) return -1;
        diag=sqrt(diag); A[j*n+j]=diag;
        double inv=1.0/diag;
        for (int i=j+1; i<n; ++i) {
            double s=A[i*n+j];
            for (int k=0; k<j; ++k) s-=A[i*n+k]*A[j*n+k];
            A[i*n+j]=s*inv;
        }
    }
    return 0;
}

static void forward_solve(const double* __restrict L, const double* __restrict b,
    double* __restrict y, int n) {
    for (int i=0; i<n; ++i) { double s=b[i]; for (int k=0; k<i; ++k) s-=L[i*n+k]*y[k]; y[i]=s/L[i*n+i]; }
}
static void backward_solve(const double* __restrict L, const double* __restrict y,
    double* __restrict x, int n) {
    for (int i=n-1; i>=0; --i) { double s=y[i]; for (int k=i+1; k<n; ++k) s-=L[k*n+i]*x[k]; x[i]=s/L[i*n+i]; }
}

static void update_state(double* __restrict buf, const double* __restrict x, int buf_len, int n_dim) {
    for (int k=0; k<buf_len; ++k) {
        int src=k%n_dim; double up=x[src];
        double w=((k&3)==0)?0.9:((k&3)==1)?-0.7:0.3;
        buf[k]=w*buf[k]+(1.0-fabs(w))*up;
    }
}

int main(int argc, char* argv[]) {
    int n_outer=1000, n_dim=1024, buf_len=32768;
    if (argc>=2) n_outer=atoi(argv[1]);
    if (argc>=3) n_dim=atoi(argv[2]);
    if (argc>=4) buf_len=atoi(argv[3]);
    if (buf_len<=0||(buf_len&(buf_len-1))!=0) { fprintf(stderr,"buf_len must be power of 2\n"); return 1; }

    int n_fill=n_dim*n_dim;
    double *si=(double*)_aligned_malloc(buf_len*sizeof(double),64);
    double *so=(double*)_aligned_malloc(buf_len*sizeof(double),64);
    double *fl=(double*)_aligned_malloc(buf_len*sizeof(double),64);
    double *A =(double*)_aligned_malloc(n_fill*sizeof(double),64);
    double *b =(double*)_aligned_malloc(n_dim*sizeof(double),64);
    double *y =(double*)_aligned_malloc(n_dim*sizeof(double),64);
    double *x =(double*)_aligned_malloc(n_dim*sizeof(double),64);
    if (!si||!so||!fl||!A||!b||!y||!x) { fprintf(stderr,"alloc failed\n"); return 1; }

    for (int k=0; k<buf_len; ++k) si[k]=sin(0.0017*(double)k)+0.4*cos(0.013*(double)(k+1));
    for (int i=0; i<n_dim; ++i) b[i]=1.0+0.5*sin(0.07*(double)i);

    int chol_fail=0; double checksum=0.0;
    double tA=0,tB=0,tC=0,tD=0,tE=0;
    double t0=wall_seconds();

    for (int it=0; it<n_outer; ++it) {
        double s;
        s=wall_seconds(); transform_buffer(si,so,fl,buf_len); tA+=wall_seconds()-s;
        s=wall_seconds(); build_matrix(so,fl,A,n_dim,buf_len); tB+=wall_seconds()-s;
        s=wall_seconds();
        if (cholesky_inplace(A,n_dim)!=0) { chol_fail++; tC+=wall_seconds()-s; for(int k=0;k<buf_len;++k) si[k]*=0.5; continue; }
        tC+=wall_seconds()-s;
        s=wall_seconds(); forward_solve(A,b,y,n_dim); backward_solve(A,y,x,n_dim); tD+=wall_seconds()-s;
        s=wall_seconds(); update_state(si,x,buf_len,n_dim); tE+=wall_seconds()-s;
        checksum+=x[0]-x[n_dim/2]+x[n_dim-1];
    }

    double tT=wall_seconds()-t0;
    printf("hot_loop done   n_outer=%d  n_dim=%d  buf=%d\n", n_outer,n_dim,buf_len);
    printf("  cholesky failures = %d\n", chol_fail);
    printf("  checksum          = %.6e\n", checksum);
    printf("  wall time total   = %.3f s\n", tT);
    printf("    A  buf transform = %7.3f s  (%5.1f%%)\n", tA, 100.0*tA/tT);
    printf("    B  matrix build  = %7.3f s  (%5.1f%%)\n", tB, 100.0*tB/tT);
    printf("    C  cholesky      = %7.3f s  (%5.1f%%)\n", tC, 100.0*tC/tT);
    printf("    D  tri solves    = %7.3f s  (%5.1f%%)\n", tD, 100.0*tD/tT);
    printf("    E  state update  = %7.3f s  (%5.1f%%)\n", tE, 100.0*tE/tT);
    _aligned_free(si);_aligned_free(so);_aligned_free(fl);
    _aligned_free(A);_aligned_free(b);_aligned_free(y);_aligned_free(x);
    return 0;
}
