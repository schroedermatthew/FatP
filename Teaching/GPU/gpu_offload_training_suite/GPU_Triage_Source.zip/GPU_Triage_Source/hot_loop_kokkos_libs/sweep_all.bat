@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

rem ============================================================
rem sweep_all.bat
rem
rem Plain cmd.exe workflow.  No PowerShell execution policy, no
rem generated throwaway CMake projects.  This folder owns one
rem CMakeLists.txt and this script configures/builds/runs it.
rem
rem Expected starting shell:
rem   - Developer Command Prompt for Visual Studio, or
rem   - a cmd.exe where cl, cmake, nvcc, and the CUDA tools are on PATH.
rem
rem Optional environment overrides:
rem   set KOKKOS_DIR=C:\opt\kokkos\lib\cmake\Kokkos
rem   set KOKKOSKERNELS_DIR=C:\opt\kokkos\lib\cmake\KokkosKernels
rem   set ARCH=120
rem   set BUILD_DIR=build
rem ============================================================

if "%KOKKOS_DIR%"=="" set KOKKOS_DIR=C:\opt\kokkos\lib\cmake\Kokkos
if "%KOKKOSKERNELS_DIR%"=="" set KOKKOSKERNELS_DIR=C:\opt\kokkos\lib\cmake\KokkosKernels
if "%ARCH%"=="" set ARCH=120
if "%BUILD_DIR%"=="" set BUILD_DIR=build

set OUT=sweep_all_results.txt
set EXE_DIR=%BUILD_DIR%\Release

if /I "%1"=="--clean" (
    if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
)

if /I "%1"=="--clean-build" (
    if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
)

> "%OUT%" echo hot_loop_kokkos_libs sweep -- %date% %time%
>> "%OUT%" echo.

echo.
echo === CONFIGURE ===
echo Kokkos_DIR        = %KOKKOS_DIR%
echo KokkosKernels_DIR = %KOKKOSKERNELS_DIR%
echo CUDA ARCH         = %ARCH%

cmake -S . -B "%BUILD_DIR%" ^
    -DCMAKE_CUDA_ARCHITECTURES=%ARCH% ^
    -DKokkos_DIR="%KOKKOS_DIR%" ^
    -DKokkosKernels_DIR="%KOKKOSKERNELS_DIR%"
if errorlevel 1 (
    echo [FAIL] CMake configure failed.
    exit /b 1
)

echo.
echo === BUILD ===
cmake --build "%BUILD_DIR%" --config Release --parallel
if errorlevel 1 (
    echo [FAIL] Build failed.
    exit /b 1
)

echo.
echo === CHECKING BINARIES ===
set OK=1
call :check_exe CPU       "%EXE_DIR%\hot_loop_cpu.exe"
call :check_exe TeamPol   "%EXE_DIR%\hot_loop_kokkos.exe"
call :check_exe cuSOLVER  "%EXE_DIR%\hot_loop_kokkos_libs.exe"
call :check_exe Graph     "%EXE_DIR%\hot_loop_kokkos_libs_graph.exe"
if "%OK%"=="0" (
    echo [FAIL] Fix builds first.
    exit /b 1
)

echo.
echo === RUNNING SWEEP ===
call :run_cfg "N=224"  50000 224 4096
call :run_cfg "N=512"   5000 512 8192
call :run_cfg "N=1024"  1000 1024 32768

echo.
echo === DONE ===
echo Results saved to %OUT%
type "%OUT%"
exit /b 0

:check_exe
if exist %2 (
    echo   [OK] %1
) else (
    echo   [FAIL] %1 missing: %~2
    set OK=0
)
exit /b 0

:run_one
set LABEL=%~1
set NAME=%~2
set EXE=%~3
set NOUTER=%~4
set NDIM=%~5
set BUF=%~6

echo   Running %LABEL% / %NAME% ...
>> "%OUT%" echo %LABEL% / %NAME%:
"%EXE%" %NOUTER% %NDIM% %BUF% >> "%OUT%" 2>&1
if errorlevel 1 (
    echo     [FAIL] %NAME%
    >> "%OUT%" echo [FAIL] %NAME% returned errorlevel %ERRORLEVEL%
) else (
    echo     [OK] %NAME%
)
>> "%OUT%" echo.
exit /b 0

:run_cfg
set LABEL=%~1
set NOUTER=%~2
set NDIM=%~3
set BUF=%~4

echo.
echo --- %LABEL%  iters=%NOUTER%  n=%NDIM%  buf=%BUF% ---
>> "%OUT%" echo ============================================================
>> "%OUT%" echo %LABEL%  iters=%NOUTER%  n=%NDIM%  buf=%BUF%
>> "%OUT%" echo ============================================================

call :run_one "%LABEL%" CPU      "%EXE_DIR%\hot_loop_cpu.exe"                %NOUTER% %NDIM% %BUF%
call :run_one "%LABEL%" TeamPol  "%EXE_DIR%\hot_loop_kokkos.exe"             %NOUTER% %NDIM% %BUF%
call :run_one "%LABEL%" cuSOLVER "%EXE_DIR%\hot_loop_kokkos_libs.exe"        %NOUTER% %NDIM% %BUF%
call :run_one "%LABEL%" Graph    "%EXE_DIR%\hot_loop_kokkos_libs_graph.exe"  %NOUTER% %NDIM% %BUF%
exit /b 0
