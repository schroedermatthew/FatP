# hot_loop_kokkos_libs Windows build/run

This folder now uses a normal Windows command prompt workflow:

```bat
sweep_all.bat --clean-build
```

No `.ps1` script is required.  That avoids PowerShell execution-policy failures.

The canonical build is this folder's `CMakeLists.txt`.  It builds these targets:

| Target | Meaning |
|---|---|
| `hot_loop_cpu` | C CPU baseline |
| `hot_loop_kokkos` | TeamPolicy hand-written Cholesky/solve |
| `hot_loop_kokkos_libs` | Kokkos phases + status-checked cuSOLVER path |
| `hot_loop_kokkos_libs_graph` | single Kokkos graph with CUDA-captured cuSOLVER work |

Default paths can be overridden before running the script:

```bat
set KOKKOS_DIR=C:\opt\kokkos\lib\cmake\Kokkos
set KOKKOSKERNELS_DIR=C:\opt\kokkos\lib\cmake\KokkosKernels
set ARCH=120
sweep_all.bat --clean-build
```

Run from a Visual Studio Developer Command Prompt or another `cmd.exe` session where
`cl`, `cmake`, `nvcc`, and the CUDA Toolkit are visible.

Expected validation line for both cuSOLVER library targets:

```text
cuSOLVER status accumulator = 0 (expected 0)
```
