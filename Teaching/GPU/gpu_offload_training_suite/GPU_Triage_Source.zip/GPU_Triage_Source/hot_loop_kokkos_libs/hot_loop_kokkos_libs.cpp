/* ============================================================
 *  hot_loop_kokkos_libs.cpp
 *
 *  Kokkos + cuSOLVER library variant.
 *  No graph and no cuda_capture: each outer iteration launches the
 *  Kokkos phases and explicit cuSOLVER potrf/potrs calls directly.
 *
 *  Usage:
 *    hot_loop_kokkos_libs.exe [n_outer] [n_dim] [buf_len]
 *    Defaults: 1000 1024 32768
 *
 *  Crossover sweep (no recompile):
 *    hot_loop_kokkos_libs.exe 50000 224 4096
 *    hot_loop_kokkos_libs.exe 5000  512 8192
 *    hot_loop_kokkos_libs.exe 1000  1024 32768
 * ============================================================ */

#include <Kokkos_Core.hpp>
#include <cusolverDn.h>
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <chrono>

using ExecSpace = Kokkos::Cuda;
using MemSpace  = ExecSpace::memory_space;

using vec_t  = Kokkos::View<double*,  MemSpace>;
using mat_t  = Kokkos::View<double**, Kokkos::LayoutLeft, MemSpace>;
using sca_t  = Kokkos::View<double,   MemSpace>;
using ivec_t = Kokkos::View<int*,     MemSpace>;

#define CUDA_CHECK(call)                                                       \
    do {                                                                       \
        cudaError_t _status = (call);                                          \
        if (_status != cudaSuccess) {                                          \
            std::fprintf(stderr, "%s:%d: CUDA error %d (%s) in %s\n",       \
                         __FILE__, __LINE__, static_cast<int>(_status),        \
                         cudaGetErrorString(_status), #call);                 \
            std::abort();                                                      \
        }                                                                      \
    } while (0)

#define CUSOLVER_CHECK(call)                                                   \
    do {                                                                       \
        cusolverStatus_t _status = (call);                                     \
        if (_status != CUSOLVER_STATUS_SUCCESS) {                              \
            std::fprintf(stderr, "%s:%d: cuSOLVER error %d in %s\n",          \
                         __FILE__, __LINE__, static_cast<int>(_status), #call);\
            std::abort();                                                      \
        }                                                                      \
    } while (0)

KOKKOS_INLINE_FUNCTION
double safe_log(double x) {
    return (x > 1e-300) ? Kokkos::log(x) : -700.0;
}

KOKKOS_INLINE_FUNCTION
double my_fabs(double x) { return (x < 0.0) ? -x : x; }

KOKKOS_INLINE_FUNCTION
double raw_aij(int i, int j, int n_dim, int buf_len,
               const vec_t& buf,
               const vec_t& flags_v,
               const vec_t& decay_lut)
{
    const int    bi = (i * 7  + 3) & (buf_len - 1);
    const int    bj = (j * 11 + 5) & (buf_len - 1);
    const double xi = buf(bi);
    const double xj = buf(bj);
    const double fi = flags_v(bi);
    const double fj = flags_v(bj);

    if (i == j) {
        return xi*xi + 0.5*xj*xj + (double)n_dim + 1.0;
    }
    const int    d     = (i > j) ? (i - j) : (j - i);
    const double dx    = xi - xj;
    const double decay = decay_lut(d);
    if (fi*fj > 0.25)        return  0.30 * xi * xj   * decay;
    else if (fi*fj < -0.25)  return -0.10 * dx        * decay;
    else if (d < 4)          return  0.20 * (xi + xj) * decay;
    else                     return  0.02 * (xi - xj) * decay;
}

struct SolverStatusAccum {
    ivec_t info;
    ivec_t fail_acc;

    KOKKOS_INLINE_FUNCTION
    void operator()(int) const {
        if (info(0) != 0) {
            Kokkos::atomic_add(&fail_acc(0), 1);
        }
    }
};

int main(int argc, char* argv[])
{
    int n_outer = 1000;
    int n_dim   = 1024;
    int buf_len = 32768;

    /* Parse before Kokkos::initialize so --kokkos-* flags still work.
     * Kokkos strips its own flags; we consume positional args. */
    if (argc >= 2) n_outer = std::atoi(argv[1]);
    if (argc >= 3) n_dim   = std::atoi(argv[2]);
    if (argc >= 4) buf_len = std::atoi(argv[3]);

    if (buf_len <= 0 || (buf_len & (buf_len - 1)) != 0) {
        std::fprintf(stderr, "buf_len must be a positive power of two; got %d\n", buf_len);
        return 1;
    }
    if (n_dim < 4 || n_outer < 1) {
        std::fprintf(stderr, "n_dim >= 4, n_outer >= 1 required\n");
        return 1;
    }

    int return_code = 0;

    Kokkos::initialize(argc, argv);
    {
        ExecSpace exec;

        vec_t state_in    ("state_in",    buf_len);
        vec_t state_out   ("state_out",   buf_len);
        vec_t flags       ("flags",       buf_len);
        mat_t A           ("A",           n_dim, n_dim);
        vec_t b           ("b",           n_dim);
        mat_t B_work      ("B_work",      n_dim, 1);
        vec_t decay_lut   ("decay_lut",   n_dim);
        sca_t checksum_acc("checksum_acc");
        ivec_t solver_info("solver_info", 1);
        ivec_t solver_fail_acc("solver_fail_acc", 1);

        auto x = Kokkos::subview(B_work, Kokkos::ALL(), 0);

        /* Host init then deep_copy */
        {
            auto h_si = Kokkos::create_mirror_view(state_in);
            auto h_b  = Kokkos::create_mirror_view(b);
            for (int k = 0; k < buf_len; ++k) {
                h_si(k) = std::sin(0.0017 * (double)k)
                         + 0.4 * std::cos(0.013 * (double)(k + 1));
            }
            for (int i = 0; i < n_dim; ++i) {
                h_b(i) = 1.0 + 0.5 * std::sin(0.07 * (double)i);
            }
            Kokkos::deep_copy(exec, state_in, h_si);
            Kokkos::deep_copy(exec, b, h_b);
            Kokkos::deep_copy(exec, checksum_acc, 0.0);
            Kokkos::deep_copy(exec, solver_info, 0);
            Kokkos::deep_copy(exec, solver_fail_acc, 0);
        }

        Kokkos::parallel_for("init_decay_lut",
            Kokkos::RangePolicy<ExecSpace>(exec, 0, n_dim),
            KOKKOS_LAMBDA(int d) {
                decay_lut(d) = Kokkos::exp(-0.01 * (double)d);
            });
        exec.fence();

        cusolverDnHandle_t solver = nullptr;
        CUSOLVER_CHECK(cusolverDnCreate(&solver));
        CUSOLVER_CHECK(cusolverDnSetStream(solver, exec.cuda_stream()));

        int lwork = 0;
        CUSOLVER_CHECK(cusolverDnDpotrf_bufferSize(
            solver, CUBLAS_FILL_MODE_LOWER, n_dim, A.data(), n_dim, &lwork));
        vec_t solver_work("solver_work", (lwork > 1) ? lwork : 1);

        const auto t0 = std::chrono::high_resolution_clock::now();

        for (int it = 0; it < n_outer; ++it) {

            Kokkos::parallel_for("phaseA_transform",
                Kokkos::RangePolicy<ExecSpace>(exec, 0, buf_len),
                KOKKOS_LAMBDA(int k) {
                    const double v  = state_in(k);
                    const double a  = my_fabs(v) + 1e-12;
                    const double lv = safe_log(a);
                    if (lv > 5.0) {
                        const double s = (v >= 0.0) ? 1.0 : -1.0;
                        state_out(k) = s * Kokkos::exp(0.5 * lv);
                        flags(k)     = 1.0;
                    } else if (lv < -5.0) {
                        const double v2 = v * v;
                        state_out(k) = v * (1.0 + 0.5 * v2 + 0.125 * v2 * v2);
                        flags(k)     = -1.0;
                    } else {
                        const double t = Kokkos::tanh(v);
                        state_out(k) = Kokkos::exp(lv) * t - 0.1 * v;
                        flags(k)     = (v >= 0.0) ? 0.5 : -0.5;
                    }
                });

            Kokkos::parallel_for("phaseB_build",
                Kokkos::MDRangePolicy<ExecSpace, Kokkos::Rank<2>>(
                    exec, {0, 0}, {n_dim, n_dim}),
                KOKKOS_LAMBDA(int i, int j) {
                    if (j > i) return;
                    double aij;
                    if (i == j) {
                        aij = raw_aij(i, i, n_dim, buf_len,
                                      state_out, flags, decay_lut);
                    } else {
                        const double f_ij = raw_aij(i, j, n_dim, buf_len,
                                                    state_out, flags, decay_lut);
                        const double f_ji = raw_aij(j, i, n_dim, buf_len,
                                                    state_out, flags, decay_lut);
                        aij = 0.5 * (f_ij + f_ji);
                    }
                    A(i, j) = aij;
                    if (i != j) A(j, i) = aij;
                });

            CUDA_CHECK(cudaMemcpyAsync(B_work.data(), b.data(),
                                       static_cast<size_t>(n_dim) * sizeof(double),
                                       cudaMemcpyDeviceToDevice,
                                       exec.cuda_stream()));
            CUSOLVER_CHECK(cusolverDnSetStream(solver, exec.cuda_stream()));
            CUSOLVER_CHECK(cusolverDnDpotrf(
                solver, CUBLAS_FILL_MODE_LOWER, n_dim,
                A.data(), n_dim, solver_work.data(), lwork, solver_info.data()));

            Kokkos::parallel_for("potrf_status",
                Kokkos::RangePolicy<ExecSpace>(exec, 0, 1),
                SolverStatusAccum{solver_info, solver_fail_acc});

            CUSOLVER_CHECK(cusolverDnDpotrs(
                solver, CUBLAS_FILL_MODE_LOWER, n_dim, 1,
                A.data(), n_dim, B_work.data(), n_dim, solver_info.data()));

            Kokkos::parallel_for("potrs_status",
                Kokkos::RangePolicy<ExecSpace>(exec, 0, 1),
                SolverStatusAccum{solver_info, solver_fail_acc});

            Kokkos::parallel_for("checksum_tap",
                Kokkos::RangePolicy<ExecSpace>(exec, 0, 1),
                KOKKOS_LAMBDA(int) {
                    Kokkos::atomic_add(&checksum_acc(),
                        x(0) - x(n_dim/2) + x(n_dim - 1));
                });

            Kokkos::parallel_for("phaseE_update",
                Kokkos::RangePolicy<ExecSpace>(exec, 0, buf_len),
                KOKKOS_LAMBDA(int k) {
                    const int    src = k % n_dim;
                    const double up  = x(src);
                    const double w =
                        ((k & 3) == 0) ?  0.9 :
                        ((k & 3) == 1) ? -0.7 :
                                          0.3;
                    state_in(k) = w * state_in(k)
                                + (1.0 - my_fabs(w)) * up;
                });
        }

        exec.fence();
        const auto t1 = std::chrono::high_resolution_clock::now();
        const double secs = std::chrono::duration<double>(t1 - t0).count();

        double h_checksum = 0.0;
        int h_fail = 0;
        Kokkos::deep_copy(h_checksum, checksum_acc);
        auto h_fail_view = Kokkos::create_mirror_view(solver_fail_acc);
        Kokkos::deep_copy(h_fail_view, solver_fail_acc);
        h_fail = h_fail_view(0);

        CUSOLVER_CHECK(cusolverDnDestroy(solver));

        std::printf("hot_loop_kokkos_libs done   n_outer=%d  n_dim=%d  buf=%d\n",
                    n_outer, n_dim, buf_len);
        std::printf("  exec_space         = %s\n", ExecSpace::name());
        std::printf("  checksum           = %.6e\n", h_checksum);
        std::printf("  wall time total    = %.3f s\n", secs);
        std::printf("  cuSOLVER status accumulator = %d (expected 0)\n", h_fail);

        if (h_fail != 0) {
            std::fprintf(stderr, "cuSOLVER status accumulator was non-zero.\n");
            return_code = 2;
        }
    }
    Kokkos::finalize();
    return return_code;
}
