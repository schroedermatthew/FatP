/* hot_loop_kokkos.cpp — Pure Kokkos, TeamPolicy Cholesky on one SM.
 * Usage: hot_loop_kokkos.exe [n_outer] [n_dim] [buf_len]
 * Defaults: 1000 1024 32768 */

#include <Kokkos_Core.hpp>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <chrono>

using ExecSpace = Kokkos::DefaultExecutionSpace;
using MemSpace  = ExecSpace::memory_space;
using vec_t  = Kokkos::View<double*,  MemSpace>;
using mat_t  = Kokkos::View<double**, Kokkos::LayoutRight, MemSpace>;
using ivec_t = Kokkos::View<int,      MemSpace>;
using sca_t  = Kokkos::View<double,   MemSpace>;

KOKKOS_INLINE_FUNCTION double safe_log(double x) { return (x > 1e-300) ? Kokkos::log(x) : -700.0; }
KOKKOS_INLINE_FUNCTION double my_fabs(double x) { return (x < 0.0) ? -x : x; }

KOKKOS_INLINE_FUNCTION
double raw_aij(int i, int j, int n_dim, int buf_len,
               const vec_t& buf, const vec_t& flags_v, const vec_t& decay_lut) {
    int bi = (i*7+3)&(buf_len-1), bj = (j*11+5)&(buf_len-1);
    double xi = buf(bi), xj = buf(bj), fi = flags_v(bi), fj = flags_v(bj);
    if (i == j) return xi*xi + 0.5*xj*xj + (double)n_dim + 1.0;
    int d = (i>j)?(i-j):(j-i); double dx = xi-xj, decay = decay_lut(d);
    if (fi*fj > 0.25) return 0.30*xi*xj*decay;
    else if (fi*fj < -0.25) return -0.10*dx*decay;
    else if (d < 4) return 0.20*(xi+xj)*decay;
    else return 0.02*(xi-xj)*decay;
}

int main(int argc, char* argv[]) {
    int n_outer = 1000, n_dim = 1024, buf_len = 32768;
    if (argc >= 2) n_outer = std::atoi(argv[1]);
    if (argc >= 3) n_dim   = std::atoi(argv[2]);
    if (argc >= 4) buf_len = std::atoi(argv[3]);
    if (buf_len <= 0 || (buf_len & (buf_len-1)) != 0) {
        std::fprintf(stderr, "buf_len must be power of 2\n"); return 1; }

    Kokkos::initialize(argc, argv);
    {
        vec_t state_in("state_in",buf_len), state_out("state_out",buf_len),
              flags("flags",buf_len), b("b",n_dim), y("y",n_dim),
              x("x",n_dim), decay_lut("decay_lut",n_dim);
        mat_t A("A",n_dim,n_dim);
        ivec_t chol_status("chol_status"); sca_t checksum_acc("checksum_acc");

        { auto h_si = Kokkos::create_mirror_view(state_in);
          auto h_b  = Kokkos::create_mirror_view(b);
          for (int k=0;k<buf_len;++k) h_si(k)=std::sin(0.0017*(double)k)+0.4*std::cos(0.013*(double)(k+1));
          for (int i=0;i<n_dim;++i) h_b(i)=1.0+0.5*std::sin(0.07*(double)i);
          Kokkos::deep_copy(state_in,h_si); Kokkos::deep_copy(b,h_b);
          Kokkos::deep_copy(chol_status,0); Kokkos::deep_copy(checksum_acc,0.0); }

        Kokkos::parallel_for("lut", Kokkos::RangePolicy<ExecSpace>(0,n_dim),
            KOKKOS_LAMBDA(int d){ decay_lut(d)=Kokkos::exp(-0.01*(double)d); });

        const auto t0 = std::chrono::high_resolution_clock::now();
        for (int it = 0; it < n_outer; ++it) {
            Kokkos::parallel_for("A", Kokkos::RangePolicy<ExecSpace>(0,buf_len),
                KOKKOS_LAMBDA(int k) {
                    double v=state_in(k), a=my_fabs(v)+1e-12, lv=safe_log(a);
                    if (lv>5.0) { double s=(v>=0)?1.0:-1.0; state_out(k)=s*Kokkos::exp(0.5*lv); flags(k)=1.0; }
                    else if (lv<-5.0) { double v2=v*v; state_out(k)=v*(1.0+0.5*v2+0.125*v2*v2); flags(k)=-1.0; }
                    else { double t=Kokkos::tanh(v); state_out(k)=Kokkos::exp(lv)*t-0.1*v; flags(k)=(v>=0)?0.5:-0.5; }
                });
            Kokkos::parallel_for("B", Kokkos::MDRangePolicy<ExecSpace,Kokkos::Rank<2>>({0,0},{n_dim,n_dim}),
                KOKKOS_LAMBDA(int i, int j) {
                    if (j>i) return; double aij;
                    if (i==j) aij=raw_aij(i,i,n_dim,buf_len,state_out,flags,decay_lut);
                    else aij=0.5*(raw_aij(i,j,n_dim,buf_len,state_out,flags,decay_lut)+raw_aij(j,i,n_dim,buf_len,state_out,flags,decay_lut));
                    A(i,j)=aij; if(i!=j) A(j,i)=aij;
                });

            using team_pol = Kokkos::TeamPolicy<ExecSpace>;
            using member_t = team_pol::member_type;
            Kokkos::parallel_for("CD", team_pol(1,Kokkos::AUTO),
                KOKKOS_LAMBDA(const member_t& team) {
                    for (int j=0; j<n_dim; ++j) {
                        double s=0.0;
                        Kokkos::parallel_reduce(Kokkos::TeamThreadRange(team,j),
                            [&](int k, double& acc){ double l=A(j,k); acc+=l*l; }, s);
                        Kokkos::single(Kokkos::PerTeam(team), [&](){
                            double diag=A(j,j)-s;
                            if(!(diag>0.0)){Kokkos::atomic_inc(&chol_status()); diag=1e-12;}
                            A(j,j)=Kokkos::sqrt(diag); });
                        team.team_barrier();
                        double inv=1.0/A(j,j);
                        Kokkos::parallel_for(Kokkos::TeamThreadRange(team,j+1,n_dim),
                            [&](int i){ double si=A(i,j); for(int k=0;k<j;++k) si-=A(i,k)*A(j,k); A(i,j)=si*inv; });
                        team.team_barrier();
                    }
                    for (int i=0;i<n_dim;++i) {
                        double s=0.0;
                        Kokkos::parallel_reduce(Kokkos::TeamThreadRange(team,i),
                            [&](int k, double& acc){ acc+=A(i,k)*y(k); }, s);
                        Kokkos::single(Kokkos::PerTeam(team),[&](){ y(i)=(b(i)-s)/A(i,i); });
                        team.team_barrier(); }
                    for (int i=n_dim-1;i>=0;--i) {
                        double s=0.0;
                        Kokkos::parallel_reduce(Kokkos::TeamThreadRange(team,i+1,n_dim),
                            [&](int k, double& acc){ acc+=A(k,i)*x(k); }, s);
                        Kokkos::single(Kokkos::PerTeam(team),[&](){ x(i)=(y(i)-s)/A(i,i); });
                        team.team_barrier(); }
                    Kokkos::single(Kokkos::PerTeam(team),[&](){
                        Kokkos::atomic_add(&checksum_acc(), x(0)-x(n_dim/2)+x(n_dim-1)); });
                });

            Kokkos::parallel_for("E", Kokkos::RangePolicy<ExecSpace>(0,buf_len),
                KOKKOS_LAMBDA(int k) {
                    int src=k%n_dim; double up=x(src);
                    double w=((k&3)==0)?0.9:((k&3)==1)?-0.7:0.3;
                    state_in(k)=w*state_in(k)+(1.0-my_fabs(w))*up;
                });
        }
        Kokkos::fence();
        double secs = std::chrono::duration<double>(std::chrono::high_resolution_clock::now()-t0).count();
        int h_cf=0; double h_cs=0.0;
        Kokkos::deep_copy(h_cf,chol_status); Kokkos::deep_copy(h_cs,checksum_acc);
        std::printf("hot_loop_kokkos done   n_outer=%d  n_dim=%d  buf=%d\n", n_outer,n_dim,buf_len);
        std::printf("  exec_space         = %s\n", ExecSpace::name());
        std::printf("  cholesky failures  = %d\n", h_cf);
        std::printf("  checksum           = %.6e\n", h_cs);
        std::printf("  wall time total    = %.3f s\n", secs);
    }
    Kokkos::finalize();
    return 0;
}
