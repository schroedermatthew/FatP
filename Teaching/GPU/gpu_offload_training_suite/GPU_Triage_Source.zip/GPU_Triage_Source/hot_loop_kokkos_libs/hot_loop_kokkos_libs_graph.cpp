/* hot_loop_kokkos_libs_graph.cpp — Single Kokkos graph + CUDA 12+ vendor-library capture.
 * Usage: hot_loop_kokkos_libs_graph.exe [n_outer] [n_dim] [buf_len]
 * Defaults can be set at compile time with HOT_LOOP_N_OUTER, HOT_LOOP_N_DIM,
 * and HOT_LOOP_BUF_LEN; otherwise they are 1000 1024 32768.
 *
 * This is the non-ArrayView training path.  It intentionally does NOT use the
 * older two-graph compatibility split.  The whole per-iteration sequence is
 * represented as one Kokkos graph and replayed once per outer iteration:
 *
 *   PhaseA -> PhaseB -> cuda_capture(RHS reset + cuSOLVER potrf)
 *          -> status -> cuda_capture(cuSOLVER potrs) -> status
 *          -> checksum -> PhaseE
 *
 * Requirements:
 *   - Kokkos with CUDA Graph capture support
 *   - CUDA Toolkit 12+ / driver stack where cuSOLVER potrf/potrs participate
 *     correctly in stream capture
 */

#include <Kokkos_Core.hpp>
#include <Kokkos_Graph.hpp>
#include <cusolverDn.h>
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <chrono>

using ExecSpace = Kokkos::Cuda;
using MemSpace  = ExecSpace::memory_space;
using vec_t  = Kokkos::View<double*,  MemSpace>;
using mat_t  = Kokkos::View<double**, Kokkos::LayoutLeft, MemSpace>;
using sca_t  = Kokkos::View<double,   MemSpace>;
using ivec_t = Kokkos::View<int*,     MemSpace>;

#ifndef HOT_LOOP_N_OUTER
#define HOT_LOOP_N_OUTER 1000
#endif
#ifndef HOT_LOOP_N_DIM
#define HOT_LOOP_N_DIM 1024
#endif
#ifndef HOT_LOOP_BUF_LEN
#define HOT_LOOP_BUF_LEN 32768
#endif

#define CUDA_CHECK(call)                                                       \
    do {                                                                       \
        cudaError_t _status = (call);                                          \
        if (_status != cudaSuccess) {                                          \
            std::fprintf(stderr, "%s:%d: CUDA error %d (%s) in %s\n",       \
                         __FILE__, __LINE__, static_cast<int>(_status),        \
                         cudaGetErrorString(_status), #call);                 \
            std::abort();                                                      \
        }                                                                      \
    } while (0)

#define CUSOLVER_CHECK(call)                                                   \
    do {                                                                       \
        cusolverStatus_t _status = (call);                                     \
        if (_status != CUSOLVER_STATUS_SUCCESS) {                              \
            std::fprintf(stderr, "%s:%d: cuSOLVER error %d in %s\n",          \
                         __FILE__, __LINE__, static_cast<int>(_status), #call);\
            std::abort();                                                      \
        }                                                                      \
    } while (0)

KOKKOS_INLINE_FUNCTION double safe_log(double x) { return (x > 1e-300) ? Kokkos::log(x) : -700.0; }
KOKKOS_INLINE_FUNCTION double my_fabs(double x) { return (x < 0.0) ? -x : x; }

KOKKOS_INLINE_FUNCTION
double raw_aij(int i, int j, int n_dim, int buf_len,
               const vec_t& buf, const vec_t& fl, const vec_t& lut) {
    int bi=(i*7+3)&(buf_len-1), bj=(j*11+5)&(buf_len-1);
    double xi=buf(bi),xj=buf(bj),fi=fl(bi),fj=fl(bj);
    if (i==j) return xi*xi+0.5*xj*xj+(double)n_dim+1.0;
    int d=(i>j)?(i-j):(j-i); double dx=xi-xj, decay=lut(d);
    if (fi*fj>0.25) return 0.30*xi*xj*decay;
    else if (fi*fj<-0.25) return -0.10*dx*decay;
    else if (d<4) return 0.20*(xi+xj)*decay;
    else return 0.02*(xi-xj)*decay;
}

struct PhaseA {
    vec_t state_in, state_out, flags;
    KOKKOS_INLINE_FUNCTION void operator()(int k) const {
        double v=state_in(k), a=my_fabs(v)+1e-12, lv=safe_log(a);
        if (lv>5.0){double s=(v>=0)?1.0:-1.0; state_out(k)=s*Kokkos::exp(0.5*lv); flags(k)=1.0;}
        else if(lv<-5.0){double v2=v*v; state_out(k)=v*(1.0+0.5*v2+0.125*v2*v2); flags(k)=-1.0;}
        else{double t=Kokkos::tanh(v); state_out(k)=Kokkos::exp(lv)*t-0.1*v; flags(k)=(v>=0)?0.5:-0.5;}
    }
};

struct PhaseB {
    mat_t A; vec_t state_out, flags, decay_lut; int n_dim, buf_len;
    KOKKOS_INLINE_FUNCTION void operator()(int i, int j) const {
        if (j>i) return; double aij;
        if (i==j) aij=raw_aij(i,i,n_dim,buf_len,state_out,flags,decay_lut);
        else aij=0.5*(raw_aij(i,j,n_dim,buf_len,state_out,flags,decay_lut)
                     +raw_aij(j,i,n_dim,buf_len,state_out,flags,decay_lut));
        A(i,j)=aij; if(i!=j) A(j,i)=aij;
    }
};

struct StatusAccum {
    ivec_t info, fail_acc;
    KOKKOS_INLINE_FUNCTION void operator()(int) const {
        if (info(0) != 0) Kokkos::atomic_add(&fail_acc(0), 1);
    }
};

struct ChecksumTap {
    sca_t checksum_acc; vec_t x; int n_dim;
    KOKKOS_INLINE_FUNCTION void operator()(int) const {
        Kokkos::atomic_add(&checksum_acc(), x(0)-x(n_dim/2)+x(n_dim-1));
    }
};

struct PhaseE {
    vec_t state_in, x; int n_dim;
    KOKKOS_INLINE_FUNCTION void operator()(int k) const {
        int src=k%n_dim; double up=x(src);
        double w=((k&3)==0)?0.9:((k&3)==1)?-0.7:0.3;
        state_in(k)=w*state_in(k)+(1.0-my_fabs(w))*up;
    }
};

int main(int argc, char* argv[]) {
    int n_outer=HOT_LOOP_N_OUTER, n_dim=HOT_LOOP_N_DIM, buf_len=HOT_LOOP_BUF_LEN;
    if (argc>=2) n_outer=std::atoi(argv[1]);
    if (argc>=3) n_dim  =std::atoi(argv[2]);
    if (argc>=4) buf_len=std::atoi(argv[3]);
    if (buf_len<=0||(buf_len&(buf_len-1))!=0){std::fprintf(stderr,"buf_len must be power of 2\n");return 1;}

    int return_code = 0;
    Kokkos::initialize(argc, argv);
    {
        ExecSpace exec;
        vec_t state_in("state_in",buf_len), state_out("state_out",buf_len),
              flags("flags",buf_len), b("b",n_dim), decay_lut("decay_lut",n_dim),
              solver_work("solver_work",1);
        mat_t A("A",n_dim,n_dim), B_work("B_work",n_dim,1);
        sca_t checksum_acc("checksum_acc");
        ivec_t solver_info("solver_info",1), solver_fail_acc("solver_fail_acc",1);
        auto x = Kokkos::subview(B_work, Kokkos::ALL(), 0);

        { auto h_si=Kokkos::create_mirror_view(state_in);
          auto h_b =Kokkos::create_mirror_view(b);
          for(int k=0;k<buf_len;++k) h_si(k)=std::sin(0.0017*(double)k)+0.4*std::cos(0.013*(double)(k+1));
          for(int i=0;i<n_dim;++i) h_b(i)=1.0+0.5*std::sin(0.07*(double)i);
          Kokkos::deep_copy(exec,state_in,h_si); Kokkos::deep_copy(exec,b,h_b);
          Kokkos::deep_copy(exec,checksum_acc,0.0);
          Kokkos::deep_copy(exec,solver_info,0);
          Kokkos::deep_copy(exec,solver_fail_acc,0); }

        Kokkos::parallel_for("lut", Kokkos::RangePolicy<ExecSpace>(exec,0,n_dim),
            KOKKOS_LAMBDA(int d){ decay_lut(d)=Kokkos::exp(-0.01*(double)d); });
        exec.fence();

        cusolverDnHandle_t solver = nullptr;
        CUSOLVER_CHECK(cusolverDnCreate(&solver));
        CUSOLVER_CHECK(cusolverDnSetStream(solver, exec.cuda_stream()));

        int lwork = 0;
        CUSOLVER_CHECK(cusolverDnDpotrf_bufferSize(
            solver, CUBLAS_FILL_MODE_LOWER, n_dim, A.data(), n_dim, &lwork));
        if (lwork > 1) solver_work = vec_t("solver_work", lwork);

        /* Warm up Kokkos dispatch and cuSOLVER handle/workspace paths before capture.
         * This avoids putting first-use initialization into the captured graph. */
        {
            mat_t warm_A("warm_A",1,1), warm_B("warm_B",1,1);
            vec_t warm_work("warm_work",1);
            ivec_t warm_info("warm_info",1);
            Kokkos::deep_copy(exec,warm_A,1.0);
            Kokkos::deep_copy(exec,warm_B,1.0);
            Kokkos::deep_copy(exec,warm_info,0);
            CUSOLVER_CHECK(cusolverDnSetStream(solver, exec.cuda_stream()));
            CUSOLVER_CHECK(cusolverDnDpotrf(
                solver, CUBLAS_FILL_MODE_LOWER, 1,
                warm_A.data(), 1, warm_work.data(), 1, warm_info.data()));
            CUSOLVER_CHECK(cusolverDnDpotrs(
                solver, CUBLAS_FILL_MODE_LOWER, 1, 1,
                warm_A.data(), 1, warm_B.data(), 1, warm_info.data()));
            exec.fence();
        }

        {
            auto graph = Kokkos::Experimental::create_graph([&](auto root) {
                auto nA = root.then_parallel_for("A",
                    Kokkos::RangePolicy<ExecSpace>(exec,0,buf_len),
                    PhaseA{state_in,state_out,flags});

                auto nB = nA.then_parallel_for("B",
                    Kokkos::MDRangePolicy<ExecSpace,Kokkos::Rank<2>>(exec,{0,0},{n_dim,n_dim}),
                    PhaseB{A,state_out,flags,decay_lut,n_dim,buf_len});

                auto nPotrf = nB.cuda_capture(exec, [=](const ExecSpace& exec_) {
                    CUDA_CHECK(cudaMemcpyAsync(B_work.data(), b.data(),
                                                   static_cast<size_t>(n_dim) * sizeof(double),
                                                   cudaMemcpyDeviceToDevice,
                                                   exec_.cuda_stream()));
                    CUSOLVER_CHECK(cusolverDnSetStream(solver, exec_.cuda_stream()));
                    CUSOLVER_CHECK(cusolverDnDpotrf(
                        solver, CUBLAS_FILL_MODE_LOWER, n_dim,
                        A.data(), n_dim, solver_work.data(), lwork, solver_info.data()));
                });

                auto nPotrfStatus = nPotrf.then_parallel_for("potrf_status",
                    Kokkos::RangePolicy<ExecSpace>(exec,0,1),
                    StatusAccum{solver_info,solver_fail_acc});

                auto nPotrs = nPotrfStatus.cuda_capture(exec, [=](const ExecSpace& exec_) {
                    CUSOLVER_CHECK(cusolverDnSetStream(solver, exec_.cuda_stream()));
                    CUSOLVER_CHECK(cusolverDnDpotrs(
                        solver, CUBLAS_FILL_MODE_LOWER, n_dim, 1,
                        A.data(), n_dim, B_work.data(), n_dim, solver_info.data()));
                });

                auto nPotrsStatus = nPotrs.then_parallel_for("potrs_status",
                    Kokkos::RangePolicy<ExecSpace>(exec,0,1),
                    StatusAccum{solver_info,solver_fail_acc});

                auto nC = nPotrsStatus.then_parallel_for("chk",
                    Kokkos::RangePolicy<ExecSpace>(exec,0,1),
                    ChecksumTap{checksum_acc,x,n_dim});

                (void)nC.then_parallel_for("E",
                    Kokkos::RangePolicy<ExecSpace>(exec,0,buf_len),
                    PhaseE{state_in,x,n_dim});
            });
            graph.instantiate();

            const auto t0 = std::chrono::high_resolution_clock::now();
            for (int it=0; it<n_outer; ++it) {
                graph.submit(exec);
            }
            exec.fence();
            double secs = std::chrono::duration<double>(std::chrono::high_resolution_clock::now()-t0).count();

            double h_cs=0.0; int h_fail=0;
            Kokkos::deep_copy(h_cs, checksum_acc);
            auto h_fail_view = Kokkos::create_mirror_view(solver_fail_acc);
            Kokkos::deep_copy(h_fail_view, solver_fail_acc);
            h_fail = h_fail_view(0);

            std::printf("hot_loop_kokkos_libs_graph done   n_outer=%d  n_dim=%d  buf=%d\n", n_outer,n_dim,buf_len);
            std::printf("  exec_space         = %s\n", ExecSpace::name());
            std::printf("  graph mode         = single Kokkos graph; CUDA-captured cuSOLVER potrf/potrs\n");
            std::printf("  checksum           = %.6e\n", h_cs);
            std::printf("  wall time total    = %.3f s\n", secs);
            std::printf("  cuSOLVER status accumulator = %d (expected 0)\n", h_fail);
            if (h_fail != 0) {
                std::fprintf(stderr, "cuSOLVER status accumulator was non-zero; returning failure after cleanup.\n");
            }
        }
        auto h_final_fail = Kokkos::create_mirror_view(solver_fail_acc);
        Kokkos::deep_copy(h_final_fail, solver_fail_acc);
        const int final_fail = h_final_fail(0);
        CUSOLVER_CHECK(cusolverDnDestroy(solver));
        if (final_fail != 0) return_code = 2;
    }
    Kokkos::finalize();
    return return_code;
}
