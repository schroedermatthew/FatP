# hot_loop_kokkos_flat_naive

This is the deliberately naive flat `parallel_for` port.

It is meant to compile and run so that the training document can include real numbers for the beginner mistake:
A/B/E are valid flat kernels, but C/D erase true recurrence ordering and therefore do not produce a trustworthy checksum.

## Build

Use the same Kokkos installation used for `hot_loop_kokkos.cpp`.

```bat
build_flat_naive.bat --clean-build
```

or configure manually with CMake.

## What to record

For each N variant, record:

- wall time total
- checksum
- cholesky failures
- execution space

Then compare the checksum against the scalar CPU / MKL / corrected TeamPolicy result. The important result is not just speed. The important result is that this implementation should be classified as a wrong-answer anti-pattern.

## Compile-time sizing

The source supports overrides:

```cmake
-DN_DIM=224
-DN_OUTER=50000
-DBUF_LEN=4096
```

If your CMake wiring does not pass these yet, duplicate the file for 224/512/1024 the same way the other project variants do.
