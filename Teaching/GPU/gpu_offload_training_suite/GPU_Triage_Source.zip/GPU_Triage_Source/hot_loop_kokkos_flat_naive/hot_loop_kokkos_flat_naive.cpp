/* ============================================================
 *  hot_loop_kokkos_flat_naive.cpp
 *
 *  Deliberately naive flat-Kokkos port of hot_loop.c.
 *
 *  Purpose:
 *    This file is NOT the recommended implementation. It is a runnable
 *    teaching specimen for the first beginner mistake: replacing every
 *    source loop with Kokkos::parallel_for, including loops that carry
 *    true data dependencies.
 *
 *  Expected behavior:
 *    - Phase A is a legitimate flat RangePolicy over BUF_LEN.
 *    - Phase B is a legitimate flat MDRangePolicy over N_DIM x N_DIM.
 *    - Phase E is a legitimate flat RangePolicy over BUF_LEN.
 *    - Phase C is intentionally wrong: all Cholesky columns are launched
 *      concurrently even though column j reads columns 0..j-1.
 *    - Phase D is intentionally wrong: all triangular-solve rows are
 *      launched concurrently even though each row reads previously solved
 *      values.
 *
 *  Why this matters:
 *    This program should compile and run, but the checksum is not a valid
 *    correctness result. The failure is not a Kokkos bug. It is the direct
 *    result of erasing the ordering constraints in the Cholesky and
 *    triangular solves.
 *
 *  Kernel-launch budget per outer iter: 7
 *    A       RangePolicy(BUF_LEN)
 *    B       MDRangePolicy<Rank<2>>(N,N)  (j>i early-return)
 *    C_bad   RangePolicy(N)               (wrong: columns race)
 *    Df_bad  RangePolicy(N)               (wrong: y dependencies race)
 *    Db_bad  RangePolicy(N)               (wrong: x dependencies race)
 *    Chk     RangePolicy(1)
 *    E       RangePolicy(BUF_LEN)
 *
 *  Build with the same Kokkos+CMake environment as hot_loop_kokkos.cpp.
 * ============================================================ */

#include <Kokkos_Core.hpp>
#include <cstdio>
#include <cmath>
#include <chrono>

#ifndef N_OUTER
#define N_OUTER 50000
#endif

#ifndef N_DIM
#define N_DIM 224
#endif

#ifndef BUF_LEN
#define BUF_LEN 4096
#endif

using ExecSpace = Kokkos::DefaultExecutionSpace;
using MemSpace  = ExecSpace::memory_space;

using vec_t  = Kokkos::View<double*,  MemSpace>;
using mat_t  = Kokkos::View<double**, Kokkos::LayoutRight, MemSpace>;
using ivec_t = Kokkos::View<int,      MemSpace>;
using sca_t  = Kokkos::View<double,   MemSpace>;

KOKKOS_INLINE_FUNCTION
double safe_log(double x) {
    return (x > 1e-300) ? Kokkos::log(x) : -700.0;
}

KOKKOS_INLINE_FUNCTION
double my_fabs(double x) { return (x < 0.0) ? -x : x; }

/* Canonical raw matrix-entry formula.  Direction-dependent because
 * the buffer-index multipliers differ for the two arguments (7 on
 * the first, 11 on the second), so raw_aij(i,j) != raw_aij(j,i) in
 * general.  Phase B uses 0.5 * (raw_aij(i,j) + raw_aij(j,i)) to
 * symmetrize -- this matches the CPU reference's average. */
KOKKOS_INLINE_FUNCTION
double raw_aij(int i, int j,
               const vec_t& buf,
               const vec_t& flags_v,
               const vec_t& decay_lut)
{
    const int    bi = (i * 7  + 3) & (BUF_LEN - 1);
    const int    bj = (j * 11 + 5) & (BUF_LEN - 1);
    const double xi = buf(bi);
    const double xj = buf(bj);
    const double fi = flags_v(bi);
    const double fj = flags_v(bj);

    if (i == j) {
        return xi*xi + 0.5*xj*xj + (double)N_DIM + 1.0;
    }
    const int    d     = (i > j) ? (i - j) : (j - i);
    const double dx    = xi - xj;
    const double decay = decay_lut(d);
    if (fi*fj > 0.25)        return  0.30 * xi * xj   * decay;
    else if (fi*fj < -0.25)  return -0.10 * dx        * decay;
    else if (d < 4)          return  0.20 * (xi + xj) * decay;
    else                     return  0.02 * (xi - xj) * decay;
}

int main(int argc, char* argv[])
{
    Kokkos::initialize(argc, argv);
    {
        // ---- View allocations ------------------------------------
        vec_t  state_in    ("state_in",    BUF_LEN);
        vec_t  state_out   ("state_out",   BUF_LEN);
        vec_t  flags       ("flags",       BUF_LEN);
        mat_t  A           ("A",           N_DIM, N_DIM);
        vec_t  b           ("b",           N_DIM);
        vec_t  y           ("y",           N_DIM);
        vec_t  x           ("x",           N_DIM);
        vec_t  decay_lut   ("decay_lut",   N_DIM);
        ivec_t chol_status ("chol_status");      // 0-D
        sca_t  checksum_acc("checksum_acc");     // 0-D

        // ---- host-side init then deep_copy -----------------------
        {
            auto h_state_in = Kokkos::create_mirror_view(state_in);
            auto h_b        = Kokkos::create_mirror_view(b);
            for (int k = 0; k < BUF_LEN; ++k) {
                h_state_in(k) = std::sin(0.0017 * (double)k)
                              + 0.4 * std::cos(0.013 * (double)(k + 1));
            }
            for (int i = 0; i < N_DIM; ++i) {
                h_b(i) = 1.0 + 0.5 * std::sin(0.07 * (double)i);
            }
            Kokkos::deep_copy(state_in, h_state_in);
            Kokkos::deep_copy(b, h_b);
            Kokkos::deep_copy(chol_status, 0);
            Kokkos::deep_copy(checksum_acc, 0.0);
        }

        // ---- precompute exp decay LUT (once) --------------------
        Kokkos::parallel_for("init_decay_lut",
            Kokkos::RangePolicy<ExecSpace>(0, N_DIM),
            KOKKOS_LAMBDA(int d) {
                decay_lut(d) = Kokkos::exp(-0.01 * (double)d);
            });

        // ---- outer loop -----------------------------------------
        const auto t0 = std::chrono::high_resolution_clock::now();

        for (int it = 0; it < N_OUTER; ++it) {

            // === Phase A : log/exp + 3-way regime branch ===
            Kokkos::parallel_for("phaseA_transform",
                Kokkos::RangePolicy<ExecSpace>(0, BUF_LEN),
                KOKKOS_LAMBDA(int k) {
                    const double v  = state_in(k);
                    const double a  = my_fabs(v) + 1e-12;
                    const double lv = safe_log(a);
                    if (lv > 5.0) {
                        const double s = (v >= 0.0) ? 1.0 : -1.0;
                        state_out(k) = s * Kokkos::exp(0.5 * lv);
                        flags(k)     = 1.0;
                    } else if (lv < -5.0) {
                        const double v2 = v * v;
                        state_out(k) = v * (1.0 + 0.5 * v2 + 0.125 * v2 * v2);
                        flags(k)     = -1.0;
                    } else {
                        const double t = Kokkos::tanh(v);
                        state_out(k) = Kokkos::exp(lv) * t - 0.1 * v;
                        flags(k)     = (v >= 0.0) ? 0.5 : -0.5;
                    }
                });

            // === Phase B : SPD matrix build, lower-tri fill + mirror ===
            // Off-diagonal entries average raw_aij(i,j) and raw_aij(j,i)
            // to match the CPU reference's symmetrization.
            Kokkos::parallel_for("phaseB_build",
                Kokkos::MDRangePolicy<ExecSpace, Kokkos::Rank<2>>(
                    {0, 0}, {N_DIM, N_DIM}),
                KOKKOS_LAMBDA(int i, int j) {
                    if (j > i) return;     // upper handled by mirror

                    double aij;
                    if (i == j) {
                        aij = raw_aij(i, i, state_out, flags, decay_lut);
                    } else {
                        const double f_ij = raw_aij(i, j, state_out, flags, decay_lut);
                        const double f_ji = raw_aij(j, i, state_out, flags, decay_lut);
                        aij = 0.5 * (f_ij + f_ji);
                    }
                    A(i, j) = aij;
                    if (i != j) A(j, i) = aij;
                });

            // === Phase C : NAIVE WRONG flat Cholesky ===
            // This erases the column dependency.  Column j reads A(j,k) and
            // A(i,k) for k < j while those earlier columns may still be
            // unfinished in the same kernel launch.
            Kokkos::parallel_for("phaseC_cholesky_flat_wrong",
                Kokkos::RangePolicy<ExecSpace>(0, N_DIM),
                KOKKOS_LAMBDA(int j) {
                    double diag = A(j, j);
                    for (int k = 0; k < j; ++k) {
                        const double l = A(j, k);
                        diag -= l * l;
                    }

                    if (!(diag > 0.0)) {
                        Kokkos::atomic_inc(&chol_status());
                        diag = 1e-12;
                    }

                    diag = Kokkos::sqrt(diag);
                    A(j, j) = diag;
                    const double inv_diag = 1.0 / diag;

                    for (int i = j + 1; i < N_DIM; ++i) {
                        double s = A(i, j);
                        for (int k = 0; k < j; ++k) {
                            s -= A(i, k) * A(j, k);
                        }
                        A(i, j) = s * inv_diag;
                    }
                });

            // === Phase D1 : NAIVE WRONG flat forward solve ===
            // Row i reads y(0..i-1), but all rows are launched concurrently.
            Kokkos::parallel_for("phaseD_forward_flat_wrong",
                Kokkos::RangePolicy<ExecSpace>(0, N_DIM),
                KOKKOS_LAMBDA(int i) {
                    double s = b(i);
                    for (int k = 0; k < i; ++k) {
                        s -= A(i, k) * y(k);
                    }
                    y(i) = s / A(i, i);
                });

            // === Phase D2 : NAIVE WRONG flat backward solve ===
            // Row i reads x(i+1..N-1), but all rows are launched concurrently.
            Kokkos::parallel_for("phaseD_backward_flat_wrong",
                Kokkos::RangePolicy<ExecSpace>(0, N_DIM),
                KOKKOS_LAMBDA(int i) {
                    double s = y(i);
                    for (int k = i + 1; k < N_DIM; ++k) {
                        s -= A(k, i) * x(k);
                    }
                    x(i) = s / A(i, i);
                });

            // ---- on-device checksum tap ----
            Kokkos::parallel_for("checksum_tap_flat_wrong",
                Kokkos::RangePolicy<ExecSpace>(0, 1),
                KOKKOS_LAMBDA(int) {
                    Kokkos::atomic_add(&checksum_acc(),
                        x(0) - x(N_DIM/2) + x(N_DIM-1));
                });

            // === Phase E : state update, solution diffused into buf ===
            Kokkos::parallel_for("phaseE_update",
                Kokkos::RangePolicy<ExecSpace>(0, BUF_LEN),
                KOKKOS_LAMBDA(int k) {
                    const int    src = k % N_DIM;
                    const double up  = x(src);
                    const double w =
                        ((k & 3) == 0) ?  0.9 :
                        ((k & 3) == 1) ? -0.7 :
                                          0.3;
                    state_in(k) = w * state_in(k)
                                + (1.0 - my_fabs(w)) * up;
                });
        }

        Kokkos::fence();   // ensure all device work finished
        const auto t1 = std::chrono::high_resolution_clock::now();
        const double secs = std::chrono::duration<double>(t1 - t0).count();

        // ---- read final accumulators (single device->host pair) ----
        int    h_chol_failures = 0;
        double h_checksum      = 0.0;
        Kokkos::deep_copy(h_chol_failures, chol_status);
        Kokkos::deep_copy(h_checksum,      checksum_acc);

        std::printf("hot_loop_kokkos_flat_naive done   iters=%d  N_DIM=%d  buf=%d\n",
                    N_OUTER, N_DIM, BUF_LEN);
        std::printf("  exec_space              = %s\n", ExecSpace::name());
        std::printf("  cholesky failures       = %d\n", h_chol_failures);
        std::printf("  checksum                = %.6e\n", h_checksum);
        std::printf("  wall time total         = %.3f s\n", secs);
    }
    Kokkos::finalize();
    return 0;
}
