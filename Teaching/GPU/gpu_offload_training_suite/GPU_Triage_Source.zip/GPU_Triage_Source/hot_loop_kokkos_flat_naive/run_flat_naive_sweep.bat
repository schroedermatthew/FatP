@echo off
setlocal EnableExtensions

set CONFIG=Release
set ARCH=120
set KOKKOS_DIR=C:\KOKKOS\kokkos\build\cmake_packages\Kokkos

if "%1"=="--clean-build" (
    for %%D in (build_flat_naive_224 build_flat_naive_512 build_flat_naive_1024) do (
        if exist "%%D" rmdir /s /q "%%D"
    )
)

call :build_and_run 224 50000 build_flat_naive_224 || exit /b 1
call :build_and_run 512 5000  build_flat_naive_512 || exit /b 1
call :build_and_run 1024 1000 build_flat_naive_1024 || exit /b 1

goto :eof

:build_and_run
set N=%1
set ITERS=%2
set BDIR=%3

echo.
echo === Flat naive Kokkos parallel_for: N=%N%, iterations=%ITERS% ===
cmake -S . -B "%BDIR%" -G "Visual Studio 18 2026" -A x64 ^
    -DCMAKE_BUILD_TYPE=%CONFIG% ^
    -DCMAKE_CUDA_ARCHITECTURES=%ARCH% ^
    -DKokkos_DIR="%KOKKOS_DIR%" ^
    -DHOT_LOOP_N_DIM=%N% ^
    -DHOT_LOOP_N_OUTER=%ITERS% ^
    -DHOT_LOOP_BUF_LEN=4096
if errorlevel 1 exit /b 1

cmake --build "%BDIR%" --config %CONFIG% --parallel
if errorlevel 1 exit /b 1

"%BDIR%\%CONFIG%\hot_loop_kokkos_flat_naive.exe"
if errorlevel 1 exit /b 1

goto :eof
