/* hot_loop_mkl.c -- MKL CPU-library baseline for Advisor/variant triage.
 *
 * Usage:
 *     hot_loop_mkl.exe [n_outer] [n_dim] [buf_len]
 *
 * Sweep points:
 *     hot_loop_mkl.exe 50000 224  4096
 *     hot_loop_mkl.exe 5000  512  8192
 *     hot_loop_mkl.exe 1000  1024 32768
 *
 * Purpose:
 *     Keep phases A, B, and E identical to the scalar CPU baseline.
 *     Replace phase C/D hand-written Cholesky + triangular solves with MKL:
 *
 *         Phase C: LAPACKE_dpotrf(row-major, lower)
 *         Phase D: LAPACKE_dpotrs(row-major, lower, one RHS)
 *
 *     This is the fair optimized CPU-library baseline.  It is not a GPU
 *     offload model and should not use Advisor projection.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <mkl.h>

static double wall_seconds(void)
{
    static LARGE_INTEGER freq = { 0 };
    LARGE_INTEGER now;

    if (freq.QuadPart == 0)
    {
        QueryPerformanceFrequency(&freq);
    }

    QueryPerformanceCounter(&now);
    return (double)now.QuadPart / (double)freq.QuadPart;
}

static __inline double safe_log(double x)
{
    return (x > 1e-300) ? log(x) : -700.0;
}

static int is_power_of_two(int x)
{
    return (x > 0) && ((x & (x - 1)) == 0);
}

static double *alloc_aligned_doubles(size_t count)
{
    return (double *)_aligned_malloc(count * sizeof(double), 64);
}

static void free_aligned(void *ptr)
{
    _aligned_free(ptr);
}

/* -------------------------------------------------------------------------
 * Phase A -- buffer transform with three magnitude regimes.
 * ------------------------------------------------------------------------- */
static void transform_buffer(const double *__restrict in,
                             double *__restrict out,
                             double *__restrict flags,
                             int n)
{
    for (int k = 0; k < n; ++k)
    {
        const double v  = in[k];
        const double a  = fabs(v) + 1e-12;
        const double lv = safe_log(a);

        if (lv > 5.0)
        {
            const double s = (v >= 0.0) ? 1.0 : -1.0;
            out[k] = s * exp(0.5 * lv);
            flags[k] = 1.0;
        }
        else if (lv < -5.0)
        {
            const double v2 = v * v;
            out[k] = v * (1.0 + 0.5 * v2 + 0.125 * v2 * v2);
            flags[k] = -1.0;
        }
        else
        {
            const double t = tanh(v);
            out[k] = exp(lv) * t - 0.1 * v;
            flags[k] = (v >= 0.0) ? 0.5 : -0.5;
        }
    }
}

/* -------------------------------------------------------------------------
 * Phase B -- canonical SPD matrix construction.
 *
 * raw_aij(i,j) is intentionally direction-dependent.  Off-diagonal matrix
 * entries must average both directions to match the reference semantics.
 * ------------------------------------------------------------------------- */
static __inline double raw_aij(int i,
                               int j,
                               int n_dim,
                               int buf_len,
                               const double *__restrict buf,
                               const double *__restrict flags)
{
    const int bi = (i * 7 + 3) & (buf_len - 1);
    const int bj = (j * 11 + 5) & (buf_len - 1);

    const double xi = buf[bi];
    const double xj = buf[bj];
    const double fi = flags[bi];
    const double fj = flags[bj];

    if (i == j)
    {
        return xi * xi + 0.5 * xj * xj + (double)n_dim + 1.0;
    }

    const int d = (i > j) ? (i - j) : (j - i);
    const double dx = xi - xj;
    const double decay = exp(-0.01 * (double)d);

    if (fi * fj > 0.25)
    {
        return 0.30 * xi * xj * decay;
    }
    else if (fi * fj < -0.25)
    {
        return -0.10 * dx * decay;
    }
    else if (d < 4)
    {
        return 0.20 * (xi + xj) * decay;
    }
    else
    {
        return 0.02 * (xi - xj) * decay;
    }
}

static void build_matrix(const double *__restrict buf,
                         const double *__restrict flags,
                         double *__restrict A,
                         int n_dim,
                         int buf_len)
{
    for (int i = 0; i < n_dim; ++i)
    {
        for (int j = 0; j <= i; ++j)
        {
            double aij;

            if (i == j)
            {
                aij = raw_aij(i, i, n_dim, buf_len, buf, flags);
            }
            else
            {
                const double f_ij = raw_aij(i, j, n_dim, buf_len, buf, flags);
                const double f_ji = raw_aij(j, i, n_dim, buf_len, buf, flags);
                aij = 0.5 * (f_ij + f_ji);
            }

            A[(size_t)i * (size_t)n_dim + (size_t)j] = aij;

            if (i != j)
            {
                A[(size_t)j * (size_t)n_dim + (size_t)i] = aij;
            }
        }
    }
}

/* -------------------------------------------------------------------------
 * Phase C/D -- MKL POTRF/POTRS.
 *
 * A is row-major full storage.  LAPACKE_dpotrf with LAPACK_ROW_MAJOR and
 * uplo='L' overwrites the lower triangle with L.  LAPACKE_dpotrs solves
 * L L^T x = b.  rhs is one column in row-major layout, so ldb = nrhs = 1.
 * ------------------------------------------------------------------------- */
static int mkl_factor_and_solve(double *__restrict A,
                                const double *__restrict b,
                                double *__restrict x,
                                int n_dim,
                                double *__restrict time_cholesky,
                                double *__restrict time_solve)
{
    const lapack_int n = (lapack_int)n_dim;
    const lapack_int nrhs = 1;
    const lapack_int lda = n;
    const lapack_int ldb = nrhs;

    double s = wall_seconds();
    lapack_int info = LAPACKE_dpotrf(LAPACK_ROW_MAJOR, 'L', n, A, lda);
    *time_cholesky += wall_seconds() - s;

    if (info != 0)
    {
        return (int)info;
    }

    for (int i = 0; i < n_dim; ++i)
    {
        x[i] = b[i];
    }

    s = wall_seconds();
    info = LAPACKE_dpotrs(LAPACK_ROW_MAJOR, 'L', n, nrhs, A, lda, x, ldb);
    *time_solve += wall_seconds() - s;

    return (int)info;
}

/* -------------------------------------------------------------------------
 * Phase E -- state update.
 * ------------------------------------------------------------------------- */
static void update_state(double *__restrict buf,
                         const double *__restrict x,
                         int buf_len,
                         int n_dim)
{
    for (int k = 0; k < buf_len; ++k)
    {
        const int src = k % n_dim;
        const double up = x[src];

        double w;
        if ((k & 3) == 0)
        {
            w = 0.9;
        }
        else if ((k & 3) == 1)
        {
            w = -0.7;
        }
        else
        {
            w = 0.3;
        }

        buf[k] = w * buf[k] + (1.0 - fabs(w)) * up;
    }
}

static void print_usage(const char *exe)
{
    fprintf(stderr, "Usage: %s [n_outer] [n_dim] [buf_len]\n", exe);
    fprintf(stderr, "Examples:\n");
    fprintf(stderr, "  %s 50000 224  4096\n", exe);
    fprintf(stderr, "  %s 5000  512  8192\n", exe);
    fprintf(stderr, "  %s 1000  1024 32768\n", exe);
}

int main(int argc, char **argv)
{
    int n_outer = 1000;
    int n_dim = 1024;
    int buf_len = 32768;

    if (argc >= 2)
    {
        n_outer = atoi(argv[1]);
    }
    if (argc >= 3)
    {
        n_dim = atoi(argv[2]);
    }
    if (argc >= 4)
    {
        buf_len = atoi(argv[3]);
    }
    if (argc > 4 || n_outer <= 0 || n_dim <= 0 || !is_power_of_two(buf_len))
    {
        print_usage(argv[0]);
        return 1;
    }

    const size_t n_fill = (size_t)n_dim * (size_t)n_dim;

    double *state_in = alloc_aligned_doubles((size_t)buf_len);
    double *state_out = alloc_aligned_doubles((size_t)buf_len);
    double *flags = alloc_aligned_doubles((size_t)buf_len);
    double *A = alloc_aligned_doubles(n_fill);
    double *b = alloc_aligned_doubles((size_t)n_dim);
    double *x = alloc_aligned_doubles((size_t)n_dim);

    if (!state_in || !state_out || !flags || !A || !b || !x)
    {
        fprintf(stderr, "alloc failed\n");
        free_aligned(state_in);
        free_aligned(state_out);
        free_aligned(flags);
        free_aligned(A);
        free_aligned(b);
        free_aligned(x);
        return 1;
    }

    for (int k = 0; k < buf_len; ++k)
    {
        state_in[k] = sin(0.0017 * (double)k) + 0.4 * cos(0.013 * (double)(k + 1));
    }

    for (int i = 0; i < n_dim; ++i)
    {
        b[i] = 1.0 + 0.5 * sin(0.07 * (double)i);
    }

    int chol_fail = 0;
    int solve_fail = 0;
    double checksum = 0.0;

    double tA = 0.0;
    double tB = 0.0;
    double tC = 0.0;
    double tD = 0.0;
    double tE = 0.0;

    const double t0 = wall_seconds();

    for (int it = 0; it < n_outer; ++it)
    {
        double s;

        s = wall_seconds();
        transform_buffer(state_in, state_out, flags, buf_len);
        tA += wall_seconds() - s;

        s = wall_seconds();
        build_matrix(state_out, flags, A, n_dim, buf_len);
        tB += wall_seconds() - s;

        const int info = mkl_factor_and_solve(A, b, x, n_dim, &tC, &tD);
        if (info != 0)
        {
            if (info > 0)
            {
                ++chol_fail;
                for (int k = 0; k < buf_len; ++k)
                {
                    state_in[k] *= 0.5;
                }
                continue;
            }

            ++solve_fail;
            fprintf(stderr, "MKL LAPACK failure: info=%d at outer iteration %d\n", info, it);
            break;
        }

        s = wall_seconds();
        update_state(state_in, x, buf_len, n_dim);
        tE += wall_seconds() - s;

        checksum += x[0] - x[n_dim / 2] + x[n_dim - 1];
    }

    const double tT = wall_seconds() - t0;

    char mkl_version[198];
    mkl_get_version_string(mkl_version, (int)sizeof(mkl_version));

    printf("hot_loop_mkl done   n_outer=%d  n_dim=%d  buf=%d\n", n_outer, n_dim, buf_len);
    printf("  mkl version       = %s\n", mkl_version);
    printf("  mkl max threads   = %d\n", mkl_get_max_threads());
    printf("  cholesky failures = %d\n", chol_fail);
    printf("  solve failures    = %d\n", solve_fail);
    printf("  checksum          = %.6e\n", checksum);
    printf("  wall time total   = %.3f s\n", tT);
    printf("    A  buf transform = %7.3f s  (%5.1f%%)\n", tA, 100.0 * tA / tT);
    printf("    B  matrix build  = %7.3f s  (%5.1f%%)\n", tB, 100.0 * tB / tT);
    printf("    C  MKL dpotrf    = %7.3f s  (%5.1f%%)\n", tC, 100.0 * tC / tT);
    printf("    D  MKL dpotrs    = %7.3f s  (%5.1f%%)\n", tD, 100.0 * tD / tT);
    printf("    E  state update  = %7.3f s  (%5.1f%%)\n", tE, 100.0 * tE / tT);

    free_aligned(state_in);
    free_aligned(state_out);
    free_aligned(flags);
    free_aligned(A);
    free_aligned(b);
    free_aligned(x);

    return (solve_fail == 0) ? 0 : 2;
}
