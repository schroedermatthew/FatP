@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

REM ============================================================
REM  Build Kokkos (OpenMP) + KokkosKernels (MKL) + hot_loop app
REM  Run from the Intel oneAPI command prompt (setvars already loaded).
REM ============================================================

set KOKKOS_SRC=C:\KOKKOS\kokkos
set KK_SRC=C:\KOKKOS\kokkos-kernels
set INSTALL_PREFIX=C:\opt\kokkos-openmp
set MKL_CMAKE=C:\Program Files (x86)\Intel\oneAPI\mkl\latest\lib\cmake\MKL
set OUT=results_team_libs_openmp.txt

where icx >nul 2>&1
if errorlevel 1 (
    echo [FAIL] icx not found. Run from the Intel oneAPI command prompt.
    pause & exit /b 1
)
where cmake >nul 2>&1
if errorlevel 1 (
    echo [FAIL] cmake not found.
    pause & exit /b 1
)

echo === Step 1: Building Kokkos (OpenMP) ===
if exist kokkos_build rmdir /s /q kokkos_build
cmake -G Ninja -B kokkos_build -S "%KOKKOS_SRC%" ^
    -DCMAKE_CXX_COMPILER=icx ^
    -DKokkos_ENABLE_OPENMP=ON ^
    -DKokkos_ENABLE_SERIAL=ON ^
    -DCMAKE_CXX_STANDARD=20 ^
    -DCMAKE_BUILD_TYPE=Release ^
    -DCMAKE_INSTALL_PREFIX="%INSTALL_PREFIX%" ^
    -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreadedDLL
if errorlevel 1 ( echo [FAIL] Kokkos configure & pause & exit /b 1 )
cmake --build kokkos_build
if errorlevel 1 ( echo [FAIL] Kokkos build & pause & exit /b 1 )
cmake --install kokkos_build
if errorlevel 1 ( echo [FAIL] Kokkos install & pause & exit /b 1 )
echo [OK] Kokkos

echo === Step 2: Building KokkosKernels (MKL TPL) ===
if exist kk_build rmdir /s /q kk_build
cmake -G Ninja -B kk_build -S "%KK_SRC%" ^
    -DCMAKE_CXX_COMPILER=icx ^
    -DKokkos_DIR="%INSTALL_PREFIX%\lib\cmake\Kokkos" ^
    -DKokkosKernels_ENABLE_TPL_MKL=ON ^
    -DCMAKE_PREFIX_PATH="%MKL_CMAKE%" ^
    -DMKL_INTERFACE_FULL=intel_lp64 ^
    -DMKL_SYCL_INTERFACE_FULL=intel_lp64 ^
    -DMKL_THREADING=intel_thread ^
    -DCMAKE_BUILD_TYPE=Release ^
    -DCMAKE_INSTALL_PREFIX="%INSTALL_PREFIX%" ^
    -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreadedDLL
if errorlevel 1 ( echo [FAIL] KokkosKernels configure & pause & exit /b 1 )
cmake --build kk_build
if errorlevel 1 ( echo [FAIL] KokkosKernels build & pause & exit /b 1 )
cmake --install kk_build
if errorlevel 1 ( echo [FAIL] KokkosKernels install & pause & exit /b 1 )
echo [OK] KokkosKernels

echo === Step 3: Building and running hot_loop (OpenMP) ===
set KOKKOS_OMP=%INSTALL_PREFIX%\lib\cmake\Kokkos
set KK_OMP=%INSTALL_PREFIX%\lib\cmake\KokkosKernels
set OMP_PROC_BIND=spread
set OMP_PLACES=threads
set SRC=hot_loop_kokkos_team_libs.cpp

echo TeamPolicy + MKL (OpenMP) sweep -- %date% %time% > %OUT%

for %%C in ("224 50000 4096" "512 5000 8192" "1024 1000 32768") do (
    for /f "tokens=1,2,3" %%a in (%%C) do (
        set N=%%a
        set NOUTER=%%b
        set BUF=%%c
        set BDIR=build_omp_!N!

        echo.
        echo --- N=!N! ---

        powershell -Command "(Get-Content '%SRC%' -Raw) -replace 'constexpr\s+int\s+N_OUTER\s*=\s*\d+;','constexpr int N_OUTER = !NOUTER!;' -replace 'constexpr\s+int\s+N_DIM\s*=\s*\d+;','constexpr int N_DIM = !N!;' -replace 'constexpr\s+int\s+BUF_LEN\s*=\s*\d+;','constexpr int BUF_LEN = !BUF!;' | Set-Content team_omp_!N!.cpp"

        if exist !BDIR! rmdir /s /q !BDIR!
        mkdir !BDIR!

        (
            echo cmake_minimum_required(VERSION 3.18^)
            echo set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreadedDLL"^)
            echo project(hot_loop_omp LANGUAGES CXX^)
            echo set(CMAKE_CXX_STANDARD 20^)
            echo set(CMAKE_CXX_STANDARD_REQUIRED ON^)
            echo set(MKL_INTERFACE_FULL intel_lp64^)
            echo set(MKL_SYCL_INTERFACE_FULL intel_lp64^)
            echo set(MKL_THREADING intel_thread^)
            echo find_package(MKL REQUIRED^)
            echo find_package(Kokkos REQUIRED^)
            echo find_package(KokkosKernels REQUIRED^)
            echo add_executable(hot_loop_omp ${CMAKE_CURRENT_SOURCE_DIR}/team_omp.cpp^)
            echo target_link_libraries(hot_loop_omp PRIVATE Kokkos::kokkos KokkosKernels::kokkoskernels^)
        ) > !BDIR!\CMakeLists.txt

        copy team_omp_!N!.cpp !BDIR!\team_omp.cpp >nul

        echo   Configuring...
        cmake -G Ninja -B !BDIR!\build -S !BDIR! -DCMAKE_CXX_COMPILER=icx -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="%MKL_CMAKE%" -DKokkos_DIR="%KOKKOS_OMP%" -DKokkosKernels_DIR="%KK_OMP%" 2>&1
        if errorlevel 1 (
            echo   [FAIL] cmake configure
            echo N=!N!: CMAKE CONFIGURE FAILED >> %OUT%
        ) else (
            echo   Building...
            cmake --build !BDIR!\build 2>&1
            set EXE=!BDIR!\build\hot_loop_omp.exe
            if exist !EXE! (
                echo   Running...
                !EXE! >> %OUT% 2>&1
                echo   [OK]
            ) else (
                echo   [FAIL] build
                echo N=!N!: BUILD FAILED >> %OUT%
            )
        )
    )
)

echo.
echo --- Results ---
type %OUT%
pause
