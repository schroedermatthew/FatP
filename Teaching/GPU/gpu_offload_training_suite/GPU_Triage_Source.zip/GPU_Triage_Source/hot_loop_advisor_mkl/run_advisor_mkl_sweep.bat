@echo off
REM ============================================================
REM  run_advisor_mkl_sweep.bat
REM
REM  CMake-driven Intel Advisor sweep for the MKL CPU variants.
REM
REM  This is not the GPU offload projection sweep.  MKL is the fair
REM  optimized CPU baseline.  By default this script collects BOTH:
REM      1. sequential MKL
REM      2. Intel threaded MKL
REM
REM  For each MKL mode it collects:
REM      1. normal program stdout/timing
REM      2. Advisor Survey
REM      3. Advisor Roofline, unless --survey-only is used
REM
REM  Usage:
REM      run_advisor_mkl_sweep.bat
REM
REM  Optional:
REM      run_advisor_mkl_sweep.bat --survey-only
REM      run_advisor_mkl_sweep.bat --clean-build
REM      run_advisor_mkl_sweep.bat --skip-build
REM      run_advisor_mkl_sweep.bat --sequential-only
REM      run_advisor_mkl_sweep.bat --threaded-only
REM
REM  Compatibility aliases:
REM      --sequential-mkl == --sequential-only
REM      --threaded-mkl   == --threaded-only
REM
REM  Run from an Intel oneAPI / VS x64 command prompt.
REM ============================================================

setlocal EnableExtensions EnableDelayedExpansion

REM Project root is the directory containing this BAT.
pushd "%~dp0" || exit /b 1
set "PROJ_BASE=%CD%"
set "CONFIG=Release"
set "RESULTS=%PROJ_BASE%\advisor_mkl_results.txt"
set "RAW_DIR=%PROJ_BASE%\advisor_mkl_raw"

set "SURVEY_ONLY=0"
set "SKIP_BUILD=0"
set "CLEAN_BUILD=0"
set "RUN_SEQUENTIAL=1"
set "RUN_THREADED=1"

REM Preserve caller-supplied thread settings before this script changes them.
set "USER_MKL_NUM_THREADS=%MKL_NUM_THREADS%"
set "USER_OMP_NUM_THREADS=%OMP_NUM_THREADS%"

:ParseArgs
if "%~1"=="" goto DoneParseArgs
if /I "%~1"=="--survey-only" (
    set "SURVEY_ONLY=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--no-roofline" (
    set "SURVEY_ONLY=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--skip-build" (
    set "SKIP_BUILD=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--clean-build" (
    set "CLEAN_BUILD=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--fresh-cmake" (
    set "CLEAN_BUILD=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--sequential-only" (
    set "RUN_SEQUENTIAL=1"
    set "RUN_THREADED=0"
    shift
    goto ParseArgs
)
if /I "%~1"=="--threaded-only" (
    set "RUN_SEQUENTIAL=0"
    set "RUN_THREADED=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--sequential-mkl" (
    set "RUN_SEQUENTIAL=1"
    set "RUN_THREADED=0"
    shift
    goto ParseArgs
)
if /I "%~1"=="--threaded-mkl" (
    set "RUN_SEQUENTIAL=0"
    set "RUN_THREADED=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--both-mkl" (
    set "RUN_SEQUENTIAL=1"
    set "RUN_THREADED=1"
    shift
    goto ParseArgs
)
if /I "%~1"=="--help" call :Help & popd & exit /b 0
if /I "%~1"=="/help" call :Help & popd & exit /b 0

echo [FAIL] Unknown option: %~1
echo.
call :Help
popd
exit /b 1

:DoneParseArgs

where advisor >nul 2>&1
if errorlevel 1 (
    echo [FAIL] advisor not found on PATH. Run from the Intel oneAPI command prompt.
    popd
    exit /b 1
)

where cmake >nul 2>&1
if errorlevel 1 (
    echo [FAIL] cmake not found on PATH. Install CMake or open a VS/oneAPI prompt with CMake available.
    popd
    exit /b 1
)

if "%MKLROOT%"=="" (
    echo [FAIL] MKLROOT is not set. Run from the Intel oneAPI command prompt or run setvars.bat.
    popd
    exit /b 1
)

if not exist "%PROJ_BASE%\CMakeLists.txt" (
    echo [FAIL] CMakeLists.txt not found in %PROJ_BASE%
    popd
    exit /b 1
)

if not exist "%RAW_DIR%" mkdir "%RAW_DIR%" >nul 2>&1

> "%RESULTS%" echo Advisor MKL Sweep Results
>> "%RESULTS%" echo =========================
>> "%RESULTS%" echo Build system    : CMake
>> "%RESULTS%" echo Project root    : %PROJ_BASE%
>> "%RESULTS%" echo MKLROOT         : %MKLROOT%
>> "%RESULTS%" echo Modes requested : sequential=%RUN_SEQUENTIAL% threaded=%RUN_THREADED%
>> "%RESULTS%" echo Survey only     : %SURVEY_ONLY%
>> "%RESULTS%" echo MKL_DYNAMIC     : FALSE
>> "%RESULTS%" echo.

if "%RUN_SEQUENTIAL%"=="1" (
    call :RunMode sequential sequential
    if errorlevel 1 goto SweepFailed
)

if "%RUN_THREADED%"=="1" (
    call :RunMode threaded intel_thread
    if errorlevel 1 goto SweepFailed
)

echo.
echo ============================================================
echo   DONE. MKL Advisor data saved to %RESULTS%
echo ============================================================
type "%RESULTS%"
popd
exit /b 0

:SweepFailed
echo.
echo ============================================================
echo   FAILED. Partial MKL results saved to %RESULTS%
echo ============================================================
if exist "%RESULTS%" type "%RESULTS%"
popd
exit /b 1

REM ============================================================
:RunMode
REM %1=mode label used in files/projects, e.g. sequential/threaded
REM %2=CMake HOT_LOOP_MKL_THREADING value, e.g. sequential/intel_thread
REM ============================================================
set "MODE_LABEL=%~1"
set "MKL_THREADING=%~2"
set "BUILD_DIR=%PROJ_BASE%\build_%MODE_LABEL%"

if /I "%MODE_LABEL%"=="sequential" (
    set "MKL_NUM_THREADS=1"
    set "OMP_NUM_THREADS=1"
) else (
    if defined USER_MKL_NUM_THREADS (
        set "MKL_NUM_THREADS=%USER_MKL_NUM_THREADS%"
    ) else (
        set "MKL_NUM_THREADS=%NUMBER_OF_PROCESSORS%"
    )

    if defined USER_OMP_NUM_THREADS (
        set "OMP_NUM_THREADS=%USER_OMP_NUM_THREADS%"
    ) else (
        set "OMP_NUM_THREADS=!MKL_NUM_THREADS!"
    )
)
set "MKL_DYNAMIC=FALSE"

echo.
echo ============================================================
echo   MKL mode: %MODE_LABEL%  ^(HOT_LOOP_MKL_THREADING=%MKL_THREADING%^) 
echo   MKL_NUM_THREADS=%MKL_NUM_THREADS%  OMP_NUM_THREADS=%OMP_NUM_THREADS%
echo ============================================================

>> "%RESULTS%" echo ============================================================
>> "%RESULTS%" echo MKL mode        : %MODE_LABEL%
>> "%RESULTS%" echo Build directory : %BUILD_DIR%
>> "%RESULTS%" echo MKL threading   : %MKL_THREADING%
>> "%RESULTS%" echo MKL_NUM_THREADS : %MKL_NUM_THREADS%
>> "%RESULTS%" echo OMP_NUM_THREADS : %OMP_NUM_THREADS%
>> "%RESULTS%" echo ============================================================
>> "%RESULTS%" echo.

if "%SKIP_BUILD%"=="1" (
    echo === Skipping CMake build because --skip-build was requested ===
) else (
    if "%CLEAN_BUILD%"=="1" (
        if exist "%BUILD_DIR%" (
            echo === Removing build directory: %BUILD_DIR% ===
            rmdir /s /q "%BUILD_DIR%"
        )
    )

    REM Avoid profiling stale binaries in the source directory.  The next build
    REM writes this mode's EXE/PDB flat into PROJ_BASE.
    if exist "%PROJ_BASE%\hot_loop_mkl.exe" del /f /q "%PROJ_BASE%\hot_loop_mkl.exe" >nul 2>&1
    if exist "%PROJ_BASE%\hot_loop_mkl.pdb" del /f /q "%PROJ_BASE%\hot_loop_mkl.pdb" >nul 2>&1

    echo === Configuring optimized MKL profiling build with CMake [%MODE_LABEL%] ===
    echo     Release build + debug symbols; not Debug mode.
    echo     MKL threading: %MKL_THREADING%
    cmake -S "%PROJ_BASE%" -B "%BUILD_DIR%" ^
        -DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=ProgramDatabase ^
        -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreadedDLL ^
        "-DHOT_LOOP_RUNTIME_DIR:PATH=%PROJ_BASE%" ^
        "-DHOT_LOOP_MKL_THREADING=%MKL_THREADING%" ^
        -DHOT_LOOP_NATIVE_ISA=ON ^
        -DHOT_LOOP_KEEP_FRAME_POINTERS=ON
    if errorlevel 1 (
        echo [FAIL] CMake configure failed for %MODE_LABEL%
        exit /b 1
    )

    echo === Building hot_loop_mkl through CMake target hot_loop_mkl [%MODE_LABEL%] ===
    cmake --build "%BUILD_DIR%" --config %CONFIG% --target hot_loop_mkl
    if errorlevel 1 (
        echo [FAIL] CMake build failed for %MODE_LABEL%
        exit /b 1
    )
)

call :ResolveExe
if errorlevel 1 exit /b 1
call :ResolvePdb

echo.
echo [OK] Using CMake-built executable: %EXE%
if defined PDB (
    echo [OK] Found debug symbols: %PDB%
) else (
    echo [WARN] hot_loop_mkl.pdb was not found next to the executable or under the build dir.
    echo        Advisor can still run, but source attribution may be weaker.
)
echo [OK] MKLROOT=%MKLROOT%
echo [OK] MKL mode=%MODE_LABEL%
echo [OK] MKL_THREADING=%MKL_THREADING%
echo [OK] MKL_NUM_THREADS=%MKL_NUM_THREADS%
echo.

>> "%RESULTS%" echo Executable      : %EXE%
if defined PDB >> "%RESULTS%" echo PDB             : %PDB%
>> "%RESULTS%" echo.

call :RunSize "%MODE_LABEL%" "N=224"  50000 224  4096
if errorlevel 1 exit /b 1
call :RunSize "%MODE_LABEL%" "N=512"  5000  512  8192
if errorlevel 1 exit /b 1
call :RunSize "%MODE_LABEL%" "N=1024" 1000  1024 32768
if errorlevel 1 exit /b 1

exit /b 0

REM ============================================================
:ResolveExe
REM Prefer source-dir output because CMakeLists writes there.
REM Fall back to this mode's CMake output directories for compatibility.
REM ============================================================
set "EXE="
if exist "%PROJ_BASE%\hot_loop_mkl.exe" set "EXE=%PROJ_BASE%\hot_loop_mkl.exe"
if not defined EXE if exist "%BUILD_DIR%\%CONFIG%\hot_loop_mkl.exe" set "EXE=%BUILD_DIR%\%CONFIG%\hot_loop_mkl.exe"
if not defined EXE if exist "%BUILD_DIR%\hot_loop_mkl.exe" set "EXE=%BUILD_DIR%\hot_loop_mkl.exe"
if not defined EXE if exist "%BUILD_DIR%\x64\%CONFIG%\hot_loop_mkl.exe" set "EXE=%BUILD_DIR%\x64\%CONFIG%\hot_loop_mkl.exe"

if not defined EXE (
    for /f "delims=" %%F in ('dir /s /b "%BUILD_DIR%\hot_loop_mkl.exe" 2^>nul') do (
        set "EXE=%%F"
        goto FoundExe
    )
)

:FoundExe
if not defined EXE (
    echo [FAIL] Could not find hot_loop_mkl.exe after CMake build.
    exit /b 1
)
exit /b 0

REM ============================================================
:ResolvePdb
set "PDB="
for %%F in ("%EXE%") do set "EXE_DIR=%%~dpF"

if exist "%EXE_DIR%hot_loop_mkl.pdb" set "PDB=%EXE_DIR%hot_loop_mkl.pdb"
if not defined PDB if exist "%PROJ_BASE%\hot_loop_mkl.pdb" set "PDB=%PROJ_BASE%\hot_loop_mkl.pdb"
if not defined PDB if exist "%BUILD_DIR%\%CONFIG%\hot_loop_mkl.pdb" set "PDB=%BUILD_DIR%\%CONFIG%\hot_loop_mkl.pdb"
if not defined PDB if exist "%BUILD_DIR%\hot_loop_mkl.pdb" set "PDB=%BUILD_DIR%\hot_loop_mkl.pdb"

if not defined PDB (
    for /f "delims=" %%F in ('dir /s /b "%BUILD_DIR%\hot_loop_mkl.pdb" 2^>nul') do (
        set "PDB=%%F"
        goto FoundPdb
    )
)
:FoundPdb
exit /b 0

REM ============================================================
:RunSize
REM %1=mode_label  %2=label  %3=n_outer  %4=n_dim  %5=buf_len
REM ============================================================
set "MODE_LABEL=%~1"
set "LABEL=%~2"
set "ITERS=%3"
set "NDIM=%4"
set "BUFLEN=%5"
set "PDIR=%PROJ_BASE%\proj_mkl_%MODE_LABEL%_%NDIM%"
set "STDOUT_FILE=%RAW_DIR%\mkl_%MODE_LABEL%_%NDIM%_stdout.txt"

echo.
echo === MKL %MODE_LABEL% %LABEL% ^(iters=%ITERS% dim=%NDIM% buf=%BUFLEN%^) ===
>> "%RESULTS%" echo --- MKL %MODE_LABEL% %LABEL% ---

if exist "%PDIR%\e000" rmdir /s /q "%PDIR%\e000" 2>nul

REM Run once outside Advisor so the benchmark summary is not contaminated by
REM profiler overhead.  This is the timing row for the app.
echo   [0/2] Standalone benchmark run...
"%EXE%" %ITERS% %NDIM% %BUFLEN% > "%STDOUT_FILE%" 2>&1
if errorlevel 1 (
    echo   [FAIL] Standalone MKL run failed for %MODE_LABEL% %LABEL%
    type "%STDOUT_FILE%"
    >> "%RESULTS%" echo Standalone run FAILED
    exit /b 1
)
echo   [OK] Standalone benchmark

>> "%RESULTS%" echo.
>> "%RESULTS%" echo %LABEL% standalone stdout:
type "%STDOUT_FILE%" >> "%RESULTS%"
>> "%RESULTS%" echo.

REM Survey gives where time went.  For MKL, expect much of the hot work to be
REM inside MKL DLLs instead of source loops.
echo   [1/2] Advisor Survey...
advisor --collect=survey --static-instruction-mix ^
    --project-dir="%PDIR%" ^
    --search-dir src:r="%PROJ_BASE%" ^
    --search-dir bin:r="%MKLROOT%" ^
    -- "%EXE%" %ITERS% %NDIM% %BUFLEN%
if errorlevel 1 (
    echo   [FAIL] Survey failed for MKL %MODE_LABEL% %LABEL%
    >> "%RESULTS%" echo Survey FAILED
    exit /b 1
)
echo   [OK] Survey

if "%SURVEY_ONLY%"=="1" (
    echo   [2/2] Roofline SKIPPED: survey-only mode
    >> "%RESULTS%" echo Survey completed; roofline intentionally skipped.
    >> "%RESULTS%" echo Advisor project directory:
    >> "%RESULTS%" echo %PDIR%
    >> "%RESULTS%" echo.
    exit /b 0
)

REM CPU Roofline / FLOP characterization.  This is for the fair optimized CPU
REM baseline, not GPU offload projection.
echo   [2/2] Advisor CPU Roofline...
advisor --collect=roofline ^
    --project-dir="%PDIR%" ^
    --search-dir src:r="%PROJ_BASE%" ^
    --search-dir bin:r="%MKLROOT%" ^
    -- "%EXE%" %ITERS% %NDIM% %BUFLEN%
if errorlevel 1 (
    echo   [FAIL] CPU Roofline failed for MKL %MODE_LABEL% %LABEL%
    >> "%RESULTS%" echo CPU Roofline FAILED
    exit /b 1
)
echo   [OK] CPU Roofline

>> "%RESULTS%" echo Advisor project directory:
>> "%RESULTS%" echo %PDIR%
>> "%RESULTS%" echo.
>> "%RESULTS%" echo Expected use:
>> "%RESULTS%" echo   Open the Advisor project or exported report for MKL call-stack/roofline evidence.
>> "%RESULTS%" echo   Do not treat this as a GPU projection run.
>> "%RESULTS%" echo.

exit /b 0

:Help
echo Usage:
echo   run_advisor_mkl_sweep.bat [--survey-only] [--clean-build] [--skip-build]
echo                              [--sequential-only ^| --threaded-only ^| --both-mkl]
echo.
echo Options:
echo   --survey-only      Build through CMake and run standalone+Advisor Survey only.
echo   --no-roofline      Alias for --survey-only.
echo   --clean-build      Delete the per-mode CMake build directories before configure/build.
echo   --fresh-cmake      Alias for --clean-build.
echo   --skip-build       Do not run CMake; use an existing hot_loop_mkl.exe.
echo   --both-mkl         Run sequential MKL and Intel threaded MKL. Default.
echo   --sequential-only  Run only sequential MKL.
echo   --threaded-only    Run only Intel threaded MKL.
echo   --sequential-mkl   Compatibility alias for --sequential-only.
echo   --threaded-mkl     Compatibility alias for --threaded-only.
echo.
echo Threaded mode:
echo   Uses caller-supplied MKL_NUM_THREADS if set; otherwise NUMBER_OF_PROCESSORS.
echo   Sets OMP_NUM_THREADS to match unless caller supplied OMP_NUM_THREADS.
exit /b 0
