@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set KOKKOS_DIR=C:\opt\kokkos\lib\cmake\Kokkos
set KK_DIR=C:\opt\kokkos\lib\cmake\KokkosKernels
set ARCH=120
set SRC=hot_loop_kokkos_team_libs.cpp
set OUT=results_team_libs.txt

echo TeamPolicy + cuSOLVER sweep -- %date% %time% > %OUT%
echo Building and running TeamPolicy + cuSOLVER variant...

for %%C in ("224 50000 4096" "512 5000 8192" "1024 1000 32768") do (
    for /f "tokens=1,2,3" %%a in (%%C) do (
        set N=%%a
        set NOUTER=%%b
        set BUF=%%c
        set BDIR=build_!N!

        echo.
        echo --- N=!N! ---

        powershell -Command "(Get-Content '%SRC%' -Raw) -replace 'constexpr\s+int\s+N_OUTER\s*=\s*\d+;','constexpr int N_OUTER = !NOUTER!;' -replace 'constexpr\s+int\s+N_DIM\s*=\s*\d+;','constexpr int N_DIM = !N!;' -replace 'constexpr\s+int\s+BUF_LEN\s*=\s*\d+;','constexpr int BUF_LEN = !BUF!;' | Set-Content team_libs_!N!.cpp"

        if exist !BDIR! rmdir /s /q !BDIR!
        mkdir !BDIR!
        copy CMakeLists.txt !BDIR!\CMakeLists.txt >nul
        copy team_libs_!N!.cpp !BDIR!\hot_loop_kokkos_team_libs.cpp >nul

        echo   Configuring...
        cmake -B !BDIR!\build -S !BDIR! -DCMAKE_CUDA_ARCHITECTURES=%ARCH% -DKokkos_DIR=%KOKKOS_DIR% -DKokkosKernels_DIR=%KK_DIR% 2>&1
        if errorlevel 1 (
            echo   [FAIL] cmake configure
            echo N=!N!: CMAKE CONFIGURE FAILED >> %OUT%
        ) else (
            echo   Building...
            cmake --build !BDIR!\build --config Release 2>&1
            set EXE=!BDIR!\build\Release\hot_loop_kokkos_team_libs.exe
            if exist !EXE! (
                echo   Running...
                !EXE! >> %OUT% 2>&1
                echo   [OK]
            ) else (
                echo   [FAIL] build
                echo N=!N!: BUILD FAILED >> %OUT%
            )
        )
    )
)

echo.
echo --- Results ---
type %OUT%
pause
