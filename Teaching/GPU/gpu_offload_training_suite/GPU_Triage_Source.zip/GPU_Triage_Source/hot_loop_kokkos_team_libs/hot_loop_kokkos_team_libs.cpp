/* ============================================================
 *  hot_loop_kokkos_team_libs.cpp
 *
 *  TeamPolicy showcase: hierarchical parallelism for data-parallel
 *  phases (A, B, E), vendor libraries (cuSOLVER/cuBLAS) for
 *  linear algebra (C, D).
 *
 *  This variant exists to show what TeamPolicy is GOOD at:
 *    - Team-level work distribution with TeamThreadRange
 *    - Scratch memory (ScratchView) for intra-team data reuse
 *    - Three-level hierarchy: league x team x thread
 *
 *  Previous variants either used TeamPolicy(1, AUTO) for serial
 *  work it couldn't parallelise (hot_loop_kokkos.cpp) or used
 *  RangePolicy/MDRangePolicy which hide the team structure
 *  (hot_loop_kokkos_libs.cpp).  This version uses TeamPolicy
 *  where it helps and vendor libraries where it doesn't.
 *
 *  --- Phase B: why TeamPolicy wins ---
 *
 *  Phase B builds a symmetric N x N matrix.  Each row i needs:
 *    - xi = buf[(i*7+3) & (BUF-1)]    (constant across all j)
 *    - fi = flags[(i*7+3) & (BUF-1)]  (constant across all j)
 *    - For each column j <= i: xj, fj, decay_lut[|i-j|]
 *
 *  With TeamPolicy(N, AUTO): one team per row.  The team loads
 *  xi and fi once, then distributes columns j across threads
 *  via TeamThreadRange.  All threads in the team share the row's
 *  constants without redundant global loads.
 *
 *  With RangePolicy(N*N): each thread independently computes its
 *  (i,j) indices and independently loads xi, fi from global mem.
 *  No sharing, redundant loads across threads in the same row.
 *
 *  --- Kernel-launch budget per outer iter: 7 ---
 *    A          TeamPolicy(nTeamsA, AUTO)
 *    B          TeamPolicy(N, AUTO) + scratch
 *    deep_copy  b -> B_work column 0
 *    C          potrf      (vendor: cuSOLVER)
 *    D-fwd      trsm       (vendor: cuBLAS)
 *    D-bwd      trsm       (vendor: cuBLAS)
 *    E          TeamPolicy(nTeamsE, AUTO)
 *    (checksum folded into Phase E team 0 — no extra launch)
 *
 *  --- Build: same as hot_loop_kokkos_libs.cpp ---
 *    Needs Kokkos + KokkosKernels with cuSOLVER/cuBLAS TPLs.
 * ============================================================ */

#include <Kokkos_Core.hpp>
#include <KokkosBlas3_trsm.hpp>
#include <KokkosLapack_potrf.hpp>
#include <cstdio>
#include <cmath>
#include <chrono>

constexpr int N_OUTER = 50000;
constexpr int N_DIM   = 224;
constexpr int BUF_LEN = 4096;

using ExecSpace = Kokkos::DefaultExecutionSpace;
using MemSpace  = ExecSpace::memory_space;

using vec_t = Kokkos::View<double*,  MemSpace>;
using mat_t = Kokkos::View<double**, Kokkos::LayoutLeft, MemSpace>;
using sca_t = Kokkos::View<double,   MemSpace>;

using team_policy = Kokkos::TeamPolicy<ExecSpace>;
using member_t    = team_policy::member_type;

/* Scratch memory type: 1-D double array in Level 0 (shared mem on GPU) */
using scratch_t = Kokkos::View<double*, ExecSpace::scratch_memory_space,
                               Kokkos::MemoryUnmanaged>;

KOKKOS_INLINE_FUNCTION
double safe_log(double x) {
    return (x > 1e-300) ? Kokkos::log(x) : -700.0;
}

KOKKOS_INLINE_FUNCTION
double my_fabs(double x) { return (x < 0.0) ? -x : x; }

/* Raw matrix-entry formula.  See hot_loop.c for discussion. */
KOKKOS_INLINE_FUNCTION
double raw_aij(int i, int j,
               const vec_t& buf,
               const vec_t& flags_v,
               const vec_t& decay_lut)
{
    const int    bi = (i * 7  + 3) & (BUF_LEN - 1);
    const int    bj = (j * 11 + 5) & (BUF_LEN - 1);
    const double xi = buf(bi);
    const double xj = buf(bj);
    const double fi = flags_v(bi);
    const double fj = flags_v(bj);

    if (i == j) {
        return xi*xi + 0.5*xj*xj + (double)N_DIM + 1.0;
    }
    const int    d     = (i > j) ? (i - j) : (j - i);
    const double dx    = xi - xj;
    const double decay = decay_lut(d);
    if (fi*fj > 0.25)        return  0.30 * xi * xj   * decay;
    else if (fi*fj < -0.25)  return -0.10 * dx        * decay;
    else if (d < 4)          return  0.20 * (xi + xj) * decay;
    else                     return  0.02 * (xi - xj) * decay;
}

int main(int argc, char* argv[])
{
    Kokkos::initialize(argc, argv);
    {
        /* ---- View allocations -------------------------------- */
        vec_t state_in    ("state_in",    BUF_LEN);
        vec_t state_out   ("state_out",   BUF_LEN);
        vec_t flags       ("flags",       BUF_LEN);
        mat_t A           ("A",           N_DIM, N_DIM);
        vec_t b           ("b",           N_DIM);
        mat_t B_work      ("B_work",      N_DIM, 1);
        vec_t decay_lut   ("decay_lut",   N_DIM);
        sca_t checksum_acc("checksum_acc");

        auto x = Kokkos::subview(B_work, Kokkos::ALL(), 0);

        /* ---- host init then deep_copy ----------------------- */
        {
            auto h_state_in = Kokkos::create_mirror_view(state_in);
            auto h_b        = Kokkos::create_mirror_view(b);
            for (int k = 0; k < BUF_LEN; ++k) {
                h_state_in(k) = std::sin(0.0017 * (double)k)
                              + 0.4 * std::cos(0.013 * (double)(k + 1));
            }
            for (int i = 0; i < N_DIM; ++i) {
                h_b(i) = 1.0 + 0.5 * std::sin(0.07 * (double)i);
            }
            Kokkos::deep_copy(state_in, h_state_in);
            Kokkos::deep_copy(b, h_b);
            Kokkos::deep_copy(checksum_acc, 0.0);
        }

        /* ---- precompute decay LUT (one-shot) ---------------- */
        Kokkos::parallel_for("initDecayLut",
            Kokkos::RangePolicy<ExecSpace>(0, N_DIM),
            KOKKOS_LAMBDA(int d) {
                decay_lut(d) = Kokkos::exp(-0.01 * (double)d);
            });

        /* ---- team policies ---------------------------------- */
        /* Phase A/E: teams of 256 threads over BUF_LEN chunks */
        constexpr int CHUNK_A = 256;
        const int nTeamsA = (BUF_LEN + CHUNK_A - 1) / CHUNK_A;
        auto policyA = team_policy(nTeamsA, Kokkos::AUTO);

        /* Phase B: one team per row, threads distribute columns.
         * Scratch: 4 doubles per team (xi, fi, bi_val, spare)
         * for row-constant values loaded once per team. */
        constexpr int SCRATCH_DOUBLES = 4;
        const int scratchBytes = scratch_t::shmem_size(SCRATCH_DOUBLES);
        auto policyB = team_policy(N_DIM, Kokkos::AUTO)
                           .set_scratch_size(0, Kokkos::PerTeam(scratchBytes));

        /* Phase E: same geometry as A */
        auto policyE = team_policy(nTeamsA, Kokkos::AUTO);

        /* ---- outer loop ------------------------------------- */
        const auto t0 = std::chrono::high_resolution_clock::now();

        for (int it = 0; it < N_OUTER; ++it) {

            /* === Phase A : TeamPolicy over BUF_LEN chunks === */
            Kokkos::parallel_for("phaseATeam", policyA,
                KOKKOS_LAMBDA(const member_t& team)
                {
                    const int base = team.league_rank() * CHUNK_A;
                    Kokkos::parallel_for(
                        Kokkos::TeamThreadRange(team, CHUNK_A),
                        [&](int offset)
                        {
                            const int k = base + offset;
                            if (k >= BUF_LEN) return;
                            const double v  = state_in(k);
                            const double a  = my_fabs(v) + 1e-12;
                            const double lv = safe_log(a);
                            if (lv > 5.0)
                            {
                                const double s = (v >= 0.0) ? 1.0 : -1.0;
                                state_out(k) = s * Kokkos::exp(0.5 * lv);
                                flags(k)     = 1.0;
                            }
                            else if (lv < -5.0)
                            {
                                const double v2 = v * v;
                                state_out(k) = v * (1.0 + 0.5 * v2 + 0.125 * v2 * v2);
                                flags(k)     = -1.0;
                            }
                            else
                            {
                                const double t = Kokkos::tanh(v);
                                state_out(k) = Kokkos::exp(lv) * t - 0.1 * v;
                                flags(k)     = (v >= 0.0) ? 0.5 : -0.5;
                            }
                        });
                });

            /* === Phase B : TeamPolicy(N) with scratch === */
            /* One team per row i.  Team loads row-constant values
             * (xi, fi) into scratch once, then distributes columns
             * j = 0..i across threads via TeamThreadRange.
             * Scratch avoids redundant global loads of xi, fi. */
            Kokkos::parallel_for("phaseBTeam", policyB,
                KOKKOS_LAMBDA(const member_t& team)
                {
                    const int i = team.league_rank();
                    scratch_t scratch(team.team_scratch(0), SCRATCH_DOUBLES);

                    /* Team leader loads row-constant values into scratch */
                    Kokkos::single(Kokkos::PerTeam(team), [&]()
                    {
                        const int bi = (i * 7 + 3) & (BUF_LEN - 1);
                        scratch(0) = state_out(bi);   /* xi */
                        scratch(1) = flags(bi);       /* fi */
                    });
                    team.team_barrier();

                    const double xi = scratch(0);
                    const double fi = scratch(1);

                    /* Distribute columns j = 0..i across team threads */
                    Kokkos::parallel_for(
                        Kokkos::TeamThreadRange(team, i + 1),
                        [&](int j)
                        {
                            double aij;
                            if (i == j)
                            {
                                /* Diagonal: use raw_aij for full formula */
                                aij = raw_aij(i, i, state_out, flags, decay_lut);
                            }
                            else
                            {
                                /* Off-diagonal: compute using cached xi, fi */
                                const int    bj = (j * 11 + 5) & (BUF_LEN - 1);
                                const double xj = state_out(bj);
                                const double fj = flags(bj);
                                const int    d  = i - j;  /* i > j guaranteed */
                                const double decay = decay_lut(d);
                                const double dx = xi - xj;

                                double f_ij;
                                if (fi*fj > 0.25)        f_ij =  0.30 * xi * xj * decay;
                                else if (fi*fj < -0.25)  f_ij = -0.10 * dx      * decay;
                                else if (d < 4)          f_ij =  0.20 * (xi+xj) * decay;
                                else                     f_ij =  0.02 * (xi-xj) * decay;

                                /* Reverse direction: raw_aij(j, i, ...) */
                                const int    bj2 = (j * 7 + 3) & (BUF_LEN - 1);
                                const int    bi2 = (i * 11 + 5) & (BUF_LEN - 1);
                                const double xj2 = state_out(bj2);
                                const double xi2 = state_out(bi2);
                                const double fj2 = flags(bj2);
                                const double fi2 = flags(bi2);
                                const double dx2 = xj2 - xi2;

                                double f_ji;
                                if (fj2*fi2 > 0.25)        f_ji =  0.30 * xj2 * xi2 * decay;
                                else if (fj2*fi2 < -0.25)  f_ji = -0.10 * dx2       * decay;
                                else if (d < 4)             f_ji =  0.20 * (xj2+xi2) * decay;
                                else                        f_ji =  0.02 * (xj2-xi2) * decay;

                                aij = 0.5 * (f_ij + f_ji);
                            }
                            A(i, j) = aij;
                            if (i != j) A(j, i) = aij;
                        });
                });

            /* === Phases C+D : vendor library (cuSOLVER/cuBLAS) === */
            Kokkos::deep_copy(ExecSpace(), x, b);
            KokkosLapack::potrf(ExecSpace(), "L", A);
            KokkosBlas::trsm(ExecSpace(),
                             "L", "L", "N", "N", 1.0, A, B_work);
            KokkosBlas::trsm(ExecSpace(),
                             "L", "L", "T", "N", 1.0, A, B_work);

            /* === Phase E + checksum : TeamPolicy over chunks === */
            Kokkos::parallel_for("phaseETeam", policyE,
                KOKKOS_LAMBDA(const member_t& team)
                {
                    const int base = team.league_rank() * CHUNK_A;
                    Kokkos::parallel_for(
                        Kokkos::TeamThreadRange(team, CHUNK_A),
                        [&](int offset)
                        {
                            const int k = base + offset;
                            if (k >= BUF_LEN) return;
                            const int    src = k % N_DIM;
                            const double up  = x(src);
                            const double w =
                                ((k & 3) == 0) ?  0.9 :
                                ((k & 3) == 1) ? -0.7 :
                                                  0.3;
                            state_in(k) = w * state_in(k)
                                        + (1.0 - my_fabs(w)) * up;
                        });
                    /* Checksum: team 0, thread 0 only */
                    if (team.league_rank() == 0)
                    {
                        Kokkos::single(Kokkos::PerTeam(team), [&]()
                        {
                            Kokkos::atomic_add(&checksum_acc(),
                                x(0) - x(N_DIM/2) + x(N_DIM-1));
                        });
                    }
                });
        }

        Kokkos::fence();
        const auto t1 = std::chrono::high_resolution_clock::now();
        const double secs = std::chrono::duration<double>(t1 - t0).count();

        /* ---- read final accumulator ------------------------- */
        double h_checksum = 0.0;
        Kokkos::deep_copy(h_checksum, checksum_acc);

        std::printf("hot_loop_kokkos_team_libs done   iters=%d  N_DIM=%d  buf=%d\n",
                    N_OUTER, N_DIM, BUF_LEN);
        std::printf("  exec_space         = %s\n", ExecSpace::name());
        std::printf("  checksum           = %.6e\n", h_checksum);
        std::printf("  wall time total    = %.3f s\n", secs);
    }
    Kokkos::finalize();
    return 0;
}
