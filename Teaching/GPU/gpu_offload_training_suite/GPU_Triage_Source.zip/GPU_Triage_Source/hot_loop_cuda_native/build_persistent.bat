@echo off
cd /d "%~dp0"
set A=sm_120
set F=-O2 -arch=%A% -rdc=true -std=c++17 -Xcompiler=/Zc:preprocessor -lcudadevrt
set OUT=results_persistent.txt
echo Persistent -- %date% %time% > %OUT%

powershell -Command "(Get-Content hot_loop_cuda_persistent.cu -Raw) -replace 'constexpr\s+int\s+N_OUTER\s*=\s*\d+;','constexpr int N_OUTER = 50000;' -replace 'constexpr\s+int\s+N_DIM\s*=\s*\d+;','constexpr int N_DIM = 224;' -replace 'constexpr\s+int\s+BUF_LEN\s*=\s*\d+;','constexpr int BUF_LEN = 4096;' | Set-Content persist_224.cu"
echo Building N=224...
nvcc %F% persist_224.cu -o persist_224.exe
if not errorlevel 1 ( persist_224.exe >> %OUT% 2>&1 & echo   OK 224 ) else ( echo   FAIL 224 & echo N=224: FAIL >> %OUT% )

powershell -Command "(Get-Content hot_loop_cuda_persistent.cu -Raw) -replace 'constexpr\s+int\s+N_OUTER\s*=\s*\d+;','constexpr int N_OUTER = 5000;' -replace 'constexpr\s+int\s+N_DIM\s*=\s*\d+;','constexpr int N_DIM = 512;' -replace 'constexpr\s+int\s+BUF_LEN\s*=\s*\d+;','constexpr int BUF_LEN = 8192;' | Set-Content persist_512.cu"
echo Building N=512...
nvcc %F% persist_512.cu -o persist_512.exe
if not errorlevel 1 ( persist_512.exe >> %OUT% 2>&1 & echo   OK 512 ) else ( echo   FAIL 512 & echo N=512: FAIL >> %OUT% )

powershell -Command "(Get-Content hot_loop_cuda_persistent.cu -Raw) -replace 'constexpr\s+int\s+N_OUTER\s*=\s*\d+;','constexpr int N_OUTER = 1000;' -replace 'constexpr\s+int\s+N_DIM\s*=\s*\d+;','constexpr int N_DIM = 1024;' -replace 'constexpr\s+int\s+BUF_LEN\s*=\s*\d+;','constexpr int BUF_LEN = 32768;' | Set-Content persist_1024.cu"
echo Building N=1024...
nvcc %F% persist_1024.cu -o persist_1024.exe
if not errorlevel 1 ( persist_1024.exe >> %OUT% 2>&1 & echo   OK 1024 ) else ( echo   FAIL 1024 & echo N=1024: FAIL >> %OUT% )

echo.
type %OUT%
pause
