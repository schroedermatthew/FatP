/* ============================================================
 *  hot_loop_cuda.cu
 *
 *  Direct CUDA + cuSOLVER implementation of the synthetic hot
 *  loop.  Companion to hot_loop_kokkos.cpp (hand-rolled team
 *  kernel) and hot_loop_kokkos_libs.cpp (Kokkos with TPL
 *  dispatch).  This version is the no-portability-layer baseline:
 *  what you'd write if you committed to NVIDIA-only.
 *
 *  --- Phase mapping ---
 *
 *    A   __global__ phaseA_transform_kernel    (BUF_LEN threads)
 *    B   __global__ phaseB_build_kernel        (N_DIM*N_DIM threads,
 *                                                 upper tri early-return)
 *    C   cusolverDnDpotrf  (vendor blocked Cholesky, lower triangle)
 *    D   cusolverDnDpotrs  (vendor: fwd+bwd solve in one call,
 *                            given the Cholesky factor)
 *    E   __global__ phaseE_update_kernel       (BUF_LEN threads)
 *
 *  Plus a tiny __global__ checksum_tap_kernel (1 thread, atomicAdd
 *  on a device double) and a one-shot __global__ for the decay LUT.
 *
 *  --- Layout ---
 *
 *  A is column-major: A[i + j*N_DIM] = A(i,j).  Matches cuSOLVER's
 *  native expectation; no transpose copy at the wrapper boundary.
 *  Phase B's index decode keeps i = idx/N, j = idx%N for the warp
 *  partitioning to be row-aligned (32 contiguous threads share i,
 *  vary in j) -- the upper-tri skip predicates whole warps cleanly
 *  for most rows.
 *
 *  --- Failure handling ---
 *
 *  cuSOLVER writes a status int to d_info on each potrf/potrs.
 *  We don't read it inside the loop (would force a device->host
 *  sync per iter, ~50K syncs at ~5us = 250ms wasted).  Numerical
 *  failure would NaN-propagate through the checksum and be visible
 *  in the final output.  The diagonal bump in Phase B + bounded
 *  Phase A state keep A SPD for the benchmark's input distribution;
 *  failures are not expected.  See hot_loop.c for the full SPD
 *  contract statement.
 *
 *  --- Launch budget per outer iter: 9 ---
 *    A          phaseA_transform_kernel
 *    B          phaseB_build_kernel
 *    memcpy     d_b -> d_B_work (device-to-device async)
 *    C          cusolverDnDpotrf
 *    status     accumulate_status_kernel (after potrf)
 *    D          cusolverDnDpotrs
 *    status     accumulate_status_kernel (after potrs)
 *    chk        checksum_tap_kernel (1 thread)
 *    E          phaseE_update_kernel
 *
 *  The two status kernels are diagnostic; removing them for absolute
 *  minimum overhead would yield 7 launches/iter at the cost of giving
 *  up Cholesky-failure detection.  They cost ~10 us total per iter.
 *
 *  --- Build (V100 = sm_70) ---
 *    nvcc -O3 -arch=sm_70 -std=c++20 hot_loop_cuda.cu \
 *         -lcusolver -lcublas -o hot_loop_cuda
 *
 *    Adjust -arch to sm_80 (A100), sm_90 (H100), etc.
 * ============================================================ */

#include <cuda_runtime.h>
#include <cusolverDn.h>
#include <cublas_v2.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <chrono>
#include <vector>

constexpr int N_OUTER = 50000;
constexpr int N_DIM   = 224;
constexpr int BUF_LEN = 4096;

#define CUDA_CHECK(call) do {                                                  \
    cudaError_t _e = (call);                                                   \
    if (_e != cudaSuccess) {                                                   \
        std::fprintf(stderr, "CUDA error %s:%d: %s\n",                         \
                     __FILE__, __LINE__, cudaGetErrorString(_e));              \
        std::exit(1);                                                          \
    }                                                                          \
} while (0)

#define CUSOLVER_CHECK(call) do {                                              \
    cusolverStatus_t _s = (call);                                              \
    if (_s != CUSOLVER_STATUS_SUCCESS) {                                       \
        std::fprintf(stderr, "cuSOLVER error %s:%d: status=%d\n",              \
                     __FILE__, __LINE__, (int)_s);                             \
        std::exit(1);                                                          \
    }                                                                          \
} while (0)

/* ----------------------------------------------------------------
 *  Device kernels
 * ---------------------------------------------------------------- */

__global__
void init_decay_lut_kernel(double* __restrict__ lut)
{
    const int d = blockIdx.x * blockDim.x + threadIdx.x;
    if (d >= N_DIM) return;
    lut[d] = exp(-0.01 * (double)d);
}

__global__
void phaseA_transform_kernel(const double* __restrict__ in,
                             double*       __restrict__ out,
                             double*       __restrict__ flags)
{
    const int k = blockIdx.x * blockDim.x + threadIdx.x;
    if (k >= BUF_LEN) return;

    const double v  = in[k];
    const double a  = fabs(v) + 1e-12;
    const double lv = (a > 1e-300) ? log(a) : -700.0;

    if (lv > 5.0) {
        const double s = (v >= 0.0) ? 1.0 : -1.0;
        out[k]   = s * exp(0.5 * lv);
        flags[k] = 1.0;
    } else if (lv < -5.0) {
        const double v2 = v * v;
        out[k]   = v * (1.0 + 0.5 * v2 + 0.125 * v2 * v2);
        flags[k] = -1.0;
    } else {
        const double t = tanh(v);
        out[k]   = exp(lv) * t - 0.1 * v;
        flags[k] = (v >= 0.0) ? 0.5 : -0.5;
    }
}

/* Canonical raw matrix-entry formula.  raw_aij(i,j) != raw_aij(j,i)
 * in general because the buffer-index multipliers differ on the two
 * arguments.  Phase B averages the two directions to symmetrize. */
__device__ __forceinline__
double raw_aij_dev(int i, int j,
                   const double* __restrict__ buf,
                   const double* __restrict__ flags,
                   const double* __restrict__ decay_lut)
{
    const int    bi = (i * 7  + 3) & (BUF_LEN - 1);
    const int    bj = (j * 11 + 5) & (BUF_LEN - 1);
    const double xi = buf[bi];
    const double xj = buf[bj];
    const double fi = flags[bi];
    const double fj = flags[bj];

    if (i == j) {
        return xi*xi + 0.5*xj*xj + (double)N_DIM + 1.0;
    }
    const int    d     = (i > j) ? (i - j) : (j - i);
    const double dx    = xi - xj;
    const double decay = decay_lut[d];
    if (fi*fj > 0.25)        return  0.30 * xi * xj   * decay;
    else if (fi*fj < -0.25)  return -0.10 * dx        * decay;
    else if (d < 4)          return  0.20 * (xi + xj) * decay;
    else                     return  0.02 * (xi - xj) * decay;
}

__global__
void phaseB_build_kernel(const double* __restrict__ buf,
                         const double* __restrict__ flags,
                         double*       __restrict__ A,
                         const double* __restrict__ decay_lut)
{
    const int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= N_DIM * N_DIM) return;

    const int i = idx / N_DIM;
    const int j = idx - i * N_DIM;
    if (j > i) return;          // upper handled by mirror

    double aij;
    if (i == j) {
        aij = raw_aij_dev(i, i, buf, flags, decay_lut);
    } else {
        const double f_ij = raw_aij_dev(i, j, buf, flags, decay_lut);
        const double f_ji = raw_aij_dev(j, i, buf, flags, decay_lut);
        aij = 0.5 * (f_ij + f_ji);
    }

    /* column-major: A[i + j*N] = A(i,j) */
    A[i + j * N_DIM] = aij;
    if (i != j) A[j + i * N_DIM] = aij;
}

__global__
void checksum_tap_kernel(const double* __restrict__ x,
                         double*       __restrict__ checksum)
{
    /* single-thread launch; no contention -- atomicAdd just for
     * accumulating across outer iters into the same scalar. */
    if (threadIdx.x == 0 && blockIdx.x == 0) {
        atomicAdd(checksum, x[0] - x[N_DIM/2] + x[N_DIM-1]);
    }
}

/* Async accumulation of cuSOLVER devInfo status.  cuSOLVER writes 0
 * to *info on success, or the (1-based) leading minor that was not
 * positive definite on failure.  We don't want to copy info back to
 * the host every iteration (would force a sync), so we accumulate
 * any-failure into a counter that gets read once at the end. */
__global__
void accumulate_status_kernel(const int* __restrict__ info,
                              int*       __restrict__ any_failure)
{
    if (threadIdx.x == 0 && blockIdx.x == 0 && *info != 0) {
        atomicAdd(any_failure, 1);
    }
}

__global__
void phaseE_update_kernel(double*       __restrict__ state_in,
                          const double* __restrict__ x)
{
    const int k = blockIdx.x * blockDim.x + threadIdx.x;
    if (k >= BUF_LEN) return;

    const int    src = k % N_DIM;
    const double up  = x[src];
    const double w =
        ((k & 3) == 0) ?  0.9 :
        ((k & 3) == 1) ? -0.7 :
                          0.3;
    state_in[k] = w * state_in[k] + (1.0 - fabs(w)) * up;
}

/* ----------------------------------------------------------------
 *  Driver
 * ---------------------------------------------------------------- */

int main()
{
    /* ---- host init ------------------------------------------- */
    std::vector<double> h_state_in(BUF_LEN);
    std::vector<double> h_b(N_DIM);
    for (int k = 0; k < BUF_LEN; ++k) {
        h_state_in[k] = std::sin(0.0017 * (double)k)
                      + 0.4 * std::cos(0.013 * (double)(k + 1));
    }
    for (int i = 0; i < N_DIM; ++i) {
        h_b[i] = 1.0 + 0.5 * std::sin(0.07 * (double)i);
    }

    /* ---- device allocations --------------------------------- */
    double *d_state_in, *d_state_out, *d_flags;
    double *d_A, *d_b, *d_B_work, *d_decay_lut, *d_checksum;
    int    *d_info;
    int    *d_chol_fail;     /* async accumulator for cuSOLVER status */

    CUDA_CHECK(cudaMalloc(&d_state_in,  BUF_LEN       * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_state_out, BUF_LEN       * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_flags,     BUF_LEN       * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_A,         N_DIM * N_DIM * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_b,         N_DIM         * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_B_work,    N_DIM         * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_decay_lut, N_DIM         * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_checksum,  sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_info,      sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_chol_fail, sizeof(int)));

    CUDA_CHECK(cudaMemcpy(d_state_in, h_state_in.data(),
                          BUF_LEN * sizeof(double), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_b, h_b.data(),
                          N_DIM * sizeof(double), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemset(d_checksum,  0, sizeof(double)));
    CUDA_CHECK(cudaMemset(d_chol_fail, 0, sizeof(int)));

    /* ---- stream + cuSOLVER handle --------------------------- */
    cudaStream_t       stream;
    cusolverDnHandle_t cusolver_h;
    CUDA_CHECK(cudaStreamCreate(&stream));
    CUSOLVER_CHECK(cusolverDnCreate(&cusolver_h));
    CUSOLVER_CHECK(cusolverDnSetStream(cusolver_h, stream));

    /* ---- workspace query for potrf -------------------------- */
    int     lwork = 0;
    double* d_work = nullptr;
    CUSOLVER_CHECK(cusolverDnDpotrf_bufferSize(
        cusolver_h, CUBLAS_FILL_MODE_LOWER, N_DIM, d_A, N_DIM, &lwork));
    CUDA_CHECK(cudaMalloc(&d_work, lwork * sizeof(double)));

    /* ---- one-shot decay LUT --------------------------------- */
    init_decay_lut_kernel<<<(N_DIM + 255)/256, 256, 0, stream>>>(d_decay_lut);

    /* ---- launch geometry ------------------------------------ */
    constexpr int BLOCK = 256;
    const int gridA = (BUF_LEN + BLOCK - 1) / BLOCK;
    const int gridB = (N_DIM*N_DIM + BLOCK - 1) / BLOCK;
    const int gridE = (BUF_LEN + BLOCK - 1) / BLOCK;

    /* ---- outer loop ----------------------------------------- */
    const auto t0 = std::chrono::high_resolution_clock::now();

    for (int it = 0; it < N_OUTER; ++it) {

        /* === Phase A === */
        phaseA_transform_kernel<<<gridA, BLOCK, 0, stream>>>(
            d_state_in, d_state_out, d_flags);

        /* === Phase B === */
        phaseB_build_kernel<<<gridB, BLOCK, 0, stream>>>(
            d_state_out, d_flags, d_A, d_decay_lut);

        /* === Reset RHS: B_work = b === */
        CUDA_CHECK(cudaMemcpyAsync(d_B_work, d_b,
                                   N_DIM * sizeof(double),
                                   cudaMemcpyDeviceToDevice, stream));

        /* === Phase C: Cholesky factorization === */
        CUSOLVER_CHECK(cusolverDnDpotrf(
            cusolver_h, CUBLAS_FILL_MODE_LOWER, N_DIM,
            d_A, N_DIM, d_work, lwork, d_info));
        accumulate_status_kernel<<<1, 1, 0, stream>>>(d_info, d_chol_fail);

        /* === Phase D: forward + backward solve in one call === */
        CUSOLVER_CHECK(cusolverDnDpotrs(
            cusolver_h, CUBLAS_FILL_MODE_LOWER, N_DIM, /*nrhs=*/1,
            d_A, N_DIM, d_B_work, N_DIM, d_info));
        accumulate_status_kernel<<<1, 1, 0, stream>>>(d_info, d_chol_fail);

        /* === Checksum tap === */
        checksum_tap_kernel<<<1, 1, 0, stream>>>(d_B_work, d_checksum);

        /* === Phase E === */
        phaseE_update_kernel<<<gridE, BLOCK, 0, stream>>>(
            d_state_in, d_B_work);
    }

    CUDA_CHECK(cudaStreamSynchronize(stream));
    const auto t1 = std::chrono::high_resolution_clock::now();
    const double secs = std::chrono::duration<double>(t1 - t0).count();

    /* ---- read final checksum -------------------------------- */
    double h_checksum  = 0.0;
    int    h_chol_fail = 0;
    CUDA_CHECK(cudaMemcpy(&h_checksum, d_checksum,
                          sizeof(double), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&h_chol_fail, d_chol_fail,
                          sizeof(int),    cudaMemcpyDeviceToHost));

    std::printf("hot_loop_cuda done   iters=%d  N_DIM=%d  buf=%d\n",
                N_OUTER, N_DIM, BUF_LEN);
    std::printf("  checksum         = %.6e\n", h_checksum);
    std::printf("  wall time total  = %.3f s\n", secs);
    std::printf("  cuSOLVER status accumulator = %d (expected 0)\n",
                h_chol_fail);

    /* ---- cleanup -------------------------------------------- */
    CUDA_CHECK(cudaFree(d_state_in));
    CUDA_CHECK(cudaFree(d_state_out));
    CUDA_CHECK(cudaFree(d_flags));
    CUDA_CHECK(cudaFree(d_A));
    CUDA_CHECK(cudaFree(d_b));
    CUDA_CHECK(cudaFree(d_B_work));
    CUDA_CHECK(cudaFree(d_decay_lut));
    CUDA_CHECK(cudaFree(d_checksum));
    CUDA_CHECK(cudaFree(d_info));
    CUDA_CHECK(cudaFree(d_chol_fail));
    CUDA_CHECK(cudaFree(d_work));
    CUSOLVER_CHECK(cusolverDnDestroy(cusolver_h));
    CUDA_CHECK(cudaStreamDestroy(stream));

    return h_chol_fail == 0 ? 0 : 2;
}
