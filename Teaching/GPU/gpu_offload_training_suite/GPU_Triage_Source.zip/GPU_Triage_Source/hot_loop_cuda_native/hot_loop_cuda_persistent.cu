/* ============================================================
 *  hot_loop_cuda_persistent.cu
 *
 *  Persistent-kernel version: the entire outer loop (all N_OUTER
 *  iterations) runs inside ONE __global__ kernel, launched once
 *  from the host.  Maximum-fusion endpoint -- the host issues
 *  exactly one cooperative kernel launch and one stream sync;
 *  every other piece of orchestration is on the GPU.
 *
 *  Identical device helpers to hot_loop_cuda_megakernel.cu.  The
 *  only change is the kernel structure: an outer for-loop wraps
 *  the per-iteration sequence, with one extra grid.sync() at the
 *  end of each iteration so that Phase E's writes to state_in
 *  are globally visible before the next iteration's Phase A reads.
 *
 *  --- When this is the right answer ---
 *
 *  Best for:
 *    - Workloads dominated by host-side launch overhead at moderate
 *      problem sizes where library quality is not the bottleneck.
 *    - Cases where keeping all SMs occupied during the linear-algebra
 *      phases is impossible anyway (so persistent-kernel idle SMs
 *      cost nothing extra).
 *
 *  Worst for:
 *    - Large N where blocked vendor Cholesky beats unblocked
 *      single-block code by >> launch-overhead savings.
 *    - Workloads that need to share the GPU with other processes,
 *      because the cooperative launch occupies its grid for the
 *      entire run.
 *
 *  --- Watchdog timer ---
 *
 *  The kernel will run for the full duration of the loop (potentially
 *  seconds to minutes).  On Linux compute nodes with no display GPU
 *  this is fine.  On Windows or any system where a watchdog timer
 *  may kill kernels exceeding ~2 seconds, this approach will fail
 *  and the megakernel (one launch per iter) is the right fallback.
 *
 *  --- Build ---
 *    nvcc -O3 -arch=sm_70 -rdc=true -std=c++17 \
 *         hot_loop_cuda_persistent.cu -lcudadevrt \
 *         -o hot_loop_cuda_persistent
 * ============================================================ */

#include <cuda_runtime.h>
#include <cooperative_groups.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <chrono>
#include <vector>

namespace cg = cooperative_groups;

constexpr int N_OUTER = 50000;
constexpr int N_DIM   = 224;
constexpr int BUF_LEN = 4096;
constexpr int BLOCK   = 256;

#define CUDA_CHECK(call) do {                                                  \
    cudaError_t _e = (call);                                                   \
    if (_e != cudaSuccess) {                                                   \
        std::fprintf(stderr, "CUDA error %s:%d: %s\n",                         \
                     __FILE__, __LINE__, cudaGetErrorString(_e));              \
        std::exit(1);                                                          \
    }                                                                          \
} while (0)

/* ----------------------------------------------------------------
 *  Device helpers (identical to megakernel version)
 * ---------------------------------------------------------------- */

__device__ __forceinline__
double block_sum(double val, double* scratch)
{
    int tid = threadIdx.x;
    scratch[tid] = val;
    __syncthreads();
    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (tid < s) scratch[tid] += scratch[tid + s];
        __syncthreads();
    }
    return scratch[0];
}

__device__ __forceinline__
void phaseA_dev(const double* __restrict__ in,
                double*       __restrict__ out,
                double*       __restrict__ flags,
                int total)
{
    const int gtid  = blockIdx.x * blockDim.x + threadIdx.x;
    const int gsize = gridDim.x  * blockDim.x;
    for (int k = gtid; k < total; k += gsize) {
        const double v  = in[k];
        const double a  = fabs(v) + 1e-12;
        const double lv = (a > 1e-300) ? log(a) : -700.0;
        if (lv > 5.0) {
            const double s = (v >= 0.0) ? 1.0 : -1.0;
            out[k]   = s * exp(0.5 * lv);
            flags[k] = 1.0;
        } else if (lv < -5.0) {
            const double v2 = v * v;
            out[k]   = v * (1.0 + 0.5 * v2 + 0.125 * v2 * v2);
            flags[k] = -1.0;
        } else {
            const double t = tanh(v);
            out[k]   = exp(lv) * t - 0.1 * v;
            flags[k] = (v >= 0.0) ? 0.5 : -0.5;
        }
    }
}

/* Canonical raw matrix-entry formula.  Called twice from phaseB_dev
 * for off-diagonal entries to symmetrize (matches CPU reference). */
__device__ __forceinline__
double raw_aij_dev(int i, int j,
                   const double* __restrict__ buf,
                   const double* __restrict__ flags,
                   const double* __restrict__ decay_lut,
                   int N, int buf_len)
{
    const int    bi = (i * 7  + 3) & (buf_len - 1);
    const int    bj = (j * 11 + 5) & (buf_len - 1);
    const double xi = buf[bi];
    const double xj = buf[bj];
    const double fi = flags[bi];
    const double fj = flags[bj];

    if (i == j) {
        return xi*xi + 0.5*xj*xj + (double)N + 1.0;
    }
    const int    d     = (i > j) ? (i - j) : (j - i);
    const double dx    = xi - xj;
    const double decay = decay_lut[d];
    if (fi*fj > 0.25)        return  0.30 * xi * xj   * decay;
    else if (fi*fj < -0.25)  return -0.10 * dx        * decay;
    else if (d < 4)          return  0.20 * (xi + xj) * decay;
    else                     return  0.02 * (xi - xj) * decay;
}

__device__ __forceinline__
void phaseB_dev(const double* __restrict__ buf,
                const double* __restrict__ flags,
                double*       __restrict__ A,
                const double* __restrict__ decay_lut,
                int N, int buf_len)
{
    const int gtid  = blockIdx.x * blockDim.x + threadIdx.x;
    const int gsize = gridDim.x  * blockDim.x;
    const int total = N * N;
    for (int idx = gtid; idx < total; idx += gsize) {
        const int i = idx / N;
        const int j = idx - i * N;
        if (j > i) continue;
        double aij;
        if (i == j) {
            aij = raw_aij_dev(i, i, buf, flags, decay_lut, N, buf_len);
        } else {
            const double f_ij = raw_aij_dev(i, j, buf, flags, decay_lut, N, buf_len);
            const double f_ji = raw_aij_dev(j, i, buf, flags, decay_lut, N, buf_len);
            aij = 0.5 * (f_ij + f_ji);
        }
        A[i + j * N] = aij;
        if (i != j) A[j + i * N] = aij;
    }
}

__device__ __forceinline__
void reset_rhs_dev(const double* __restrict__ b,
                   double*       __restrict__ B_work,
                   int N)
{
    const int gtid  = blockIdx.x * blockDim.x + threadIdx.x;
    const int gsize = gridDim.x  * blockDim.x;
    for (int k = gtid; k < N; k += gsize) B_work[k] = b[k];
}

__device__ __forceinline__
void cholesky_block(double* A, int N, double* scratch)
{
    const int tid   = threadIdx.x;
    const int bsize = blockDim.x;
    __shared__ double s_inv_diag;

    for (int j = 0; j < N; ++j) {
        double partial = 0.0;
        for (int k = tid; k < j; k += bsize) {
            const double l = A[j + k * N];
            partial += l * l;
        }
        const double sum = block_sum(partial, scratch);
        if (tid == 0) {
            const double diag = A[j + j * N] - sum;
            const double L_jj = sqrt(diag);
            A[j + j * N] = L_jj;
            s_inv_diag   = 1.0 / L_jj;
        }
        __syncthreads();
        const double inv_diag = s_inv_diag;
        for (int i = j + 1 + tid; i < N; i += bsize) {
            double s = A[i + j * N];
            for (int k = 0; k < j; ++k) {
                s -= A[i + k * N] * A[j + k * N];
            }
            A[i + j * N] = s * inv_diag;
        }
        __syncthreads();
    }
}

__device__ __forceinline__
void forward_solve_block(const double* __restrict__ L,
                         double*       __restrict__ xy,
                         int N, double* scratch)
{
    const int tid   = threadIdx.x;
    const int bsize = blockDim.x;
    __shared__ double s_diag;
    for (int i = 0; i < N; ++i) {
        double partial = 0.0;
        for (int k = tid; k < i; k += bsize) {
            partial += L[i + k * N] * xy[k];
        }
        const double sum = block_sum(partial, scratch);
        if (tid == 0) {
            s_diag = L[i + i * N];
            xy[i]  = (xy[i] - sum) / s_diag;
        }
        __syncthreads();
    }
}

__device__ __forceinline__
void backward_solve_block(const double* __restrict__ L,
                          double*       __restrict__ xy,
                          int N, double* scratch)
{
    const int tid   = threadIdx.x;
    const int bsize = blockDim.x;
    __shared__ double s_diag;
    for (int i = N - 1; i >= 0; --i) {
        double partial = 0.0;
        for (int k = i + 1 + tid; k < N; k += bsize) {
            partial += L[k + i * N] * xy[k];
        }
        const double sum = block_sum(partial, scratch);
        if (tid == 0) {
            s_diag = L[i + i * N];
            xy[i]  = (xy[i] - sum) / s_diag;
        }
        __syncthreads();
    }
}

__device__ __forceinline__
void phaseE_dev(double*       __restrict__ state_in,
                const double* __restrict__ x,
                int N, int buf_len)
{
    const int gtid  = blockIdx.x * blockDim.x + threadIdx.x;
    const int gsize = gridDim.x  * blockDim.x;
    for (int k = gtid; k < buf_len; k += gsize) {
        const int    src = k % N;
        const double up  = x[src];
        const double w =
            ((k & 3) == 0) ?  0.9 :
            ((k & 3) == 1) ? -0.7 :
                              0.3;
        state_in[k] = w * state_in[k] + (1.0 - fabs(w)) * up;
    }
}

/* ----------------------------------------------------------------
 *  Persistent kernel: the ENTIRE outer loop runs inside the kernel.
 *  Single launch, single host sync at the end.
 * ---------------------------------------------------------------- */

__global__
void init_decay_lut_kernel(double* __restrict__ lut, int N)
{
    const int d = blockIdx.x * blockDim.x + threadIdx.x;
    if (d < N) lut[d] = exp(-0.01 * (double)d);
}

__global__
void persistent_kernel(double* __restrict__ state_in,
                       double* __restrict__ state_out,
                       double* __restrict__ flags,
                       double* __restrict__ A,
                       const double* __restrict__ b,
                       double* __restrict__ B_work,
                       const double* __restrict__ decay_lut,
                       double* __restrict__ checksum,
                       int N, int buf_len, int n_outer)
{
    extern __shared__ double scratch[];
    cg::grid_group grid = cg::this_grid();

    for (int it = 0; it < n_outer; ++it) {
        /* Phase A */
        phaseA_dev(state_in, state_out, flags, buf_len);
        grid.sync();

        /* Phase B */
        phaseB_dev(state_out, flags, A, decay_lut, N, buf_len);
        grid.sync();

        /* RHS reset */
        reset_rhs_dev(b, B_work, N);
        grid.sync();

        /* Linear algebra: block 0 only */
        if (blockIdx.x == 0) {
            cholesky_block(A, N, scratch);
            forward_solve_block(A, B_work, N, scratch);
            backward_solve_block(A, B_work, N, scratch);
            if (threadIdx.x == 0) {
                atomicAdd(checksum,
                          B_work[0] - B_work[N/2] + B_work[N-1]);
            }
        }
        grid.sync();

        /* Phase E */
        phaseE_dev(state_in, B_work, N, buf_len);

        /* Extra sync: required so next iter's Phase A reads the
         * Phase E writes to state_in.  In the megakernel version
         * this is provided implicitly by the kernel-launch boundary;
         * here we have to do it ourselves. */
        grid.sync();
    }
}

/* ----------------------------------------------------------------
 *  Driver
 * ---------------------------------------------------------------- */

int main()
{
    int dev = 0;
    int coop_supported = 0;
    CUDA_CHECK(cudaDeviceGetAttribute(&coop_supported,
        cudaDevAttrCooperativeLaunch, dev));
    if (!coop_supported) {
        std::fprintf(stderr,
            "Cooperative launch not supported on device %d\n", dev);
        return 1;
    }
    int numSMs = 0;
    CUDA_CHECK(cudaDeviceGetAttribute(&numSMs,
        cudaDevAttrMultiProcessorCount, dev));

    /* ---- host init ------------------------------------------ */
    std::vector<double> h_state_in(BUF_LEN);
    std::vector<double> h_b(N_DIM);
    for (int k = 0; k < BUF_LEN; ++k) {
        h_state_in[k] = std::sin(0.0017 * (double)k)
                      + 0.4 * std::cos(0.013 * (double)(k + 1));
    }
    for (int i = 0; i < N_DIM; ++i) {
        h_b[i] = 1.0 + 0.5 * std::sin(0.07 * (double)i);
    }

    /* ---- device allocations -------------------------------- */
    double *d_state_in, *d_state_out, *d_flags;
    double *d_A, *d_b, *d_B_work, *d_decay_lut, *d_checksum;

    CUDA_CHECK(cudaMalloc(&d_state_in,  BUF_LEN       * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_state_out, BUF_LEN       * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_flags,     BUF_LEN       * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_A,         N_DIM * N_DIM * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_b,         N_DIM         * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_B_work,    N_DIM         * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_decay_lut, N_DIM         * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_checksum,  sizeof(double)));

    CUDA_CHECK(cudaMemcpy(d_state_in, h_state_in.data(),
                          BUF_LEN * sizeof(double), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_b, h_b.data(),
                          N_DIM * sizeof(double), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemset(d_checksum, 0, sizeof(double)));

    init_decay_lut_kernel<<<(N_DIM + 255)/256, 256>>>(d_decay_lut, N_DIM);
    CUDA_CHECK(cudaDeviceSynchronize());

    /* ---- pick a cooperative-safe grid size ----------------- */
    int blocksPerSm = 0;
    const int sharedBytes = BLOCK * sizeof(double);
    CUDA_CHECK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
        &blocksPerSm, persistent_kernel, BLOCK, sharedBytes));
    if (blocksPerSm <= 0) {
        std::fprintf(stderr,
            "persistent_kernel cannot launch cooperatively: occupancy is zero "
            "for block=%d, sharedBytes=%d.  Reduce shared memory or "
            "register pressure.\n", BLOCK, sharedBytes);
        return 1;
    }
    const int gridSize = numSMs * blocksPerSm;

    std::printf("persistent_kernel grid: %d blocks x %d threads (SMs=%d, occ=%d/SM)\n",
                gridSize, BLOCK, numSMs, blocksPerSm);

    /* ---- single cooperative launch for the entire run ------ */
    int N_arg     = N_DIM;
    int buf_arg   = BUF_LEN;
    int outer_arg = N_OUTER;
    void* args[] = {
        &d_state_in, &d_state_out, &d_flags,
        &d_A, &d_b, &d_B_work, &d_decay_lut, &d_checksum,
        &N_arg, &buf_arg, &outer_arg
    };

    cudaStream_t stream;
    CUDA_CHECK(cudaStreamCreate(&stream));

    const auto t0 = std::chrono::high_resolution_clock::now();

    CUDA_CHECK(cudaLaunchCooperativeKernel(
        (void*)persistent_kernel,
        dim3(gridSize), dim3(BLOCK),
        args, sharedBytes, stream));

    CUDA_CHECK(cudaStreamSynchronize(stream));
    const auto t1 = std::chrono::high_resolution_clock::now();
    const double secs = std::chrono::duration<double>(t1 - t0).count();

    /* ---- read final checksum ------------------------------- */
    double h_checksum = 0.0;
    CUDA_CHECK(cudaMemcpy(&h_checksum, d_checksum,
                          sizeof(double), cudaMemcpyDeviceToHost));

    std::printf("hot_loop_cuda_persistent done   iters=%d  N_DIM=%d  buf=%d\n",
                N_OUTER, N_DIM, BUF_LEN);
    std::printf("  checksum         = %.6e\n", h_checksum);
    std::printf("  wall time total  = %.3f s\n", secs);
    std::printf("  host launches    = 1\n");

    /* ---- cleanup ------------------------------------------- */
    CUDA_CHECK(cudaStreamDestroy(stream));
    CUDA_CHECK(cudaFree(d_state_in));
    CUDA_CHECK(cudaFree(d_state_out));
    CUDA_CHECK(cudaFree(d_flags));
    CUDA_CHECK(cudaFree(d_A));
    CUDA_CHECK(cudaFree(d_b));
    CUDA_CHECK(cudaFree(d_B_work));
    CUDA_CHECK(cudaFree(d_decay_lut));
    CUDA_CHECK(cudaFree(d_checksum));
    return 0;
}
