# cmake/UtilityFunctions.cmake
# Contains helper functions to reduce boilerplate in subdirectory CMakeLists.txt files.

# --- Function 1: Add a standard unit test target with boilerplate ---
# Call this in test subdirectories (e.g., Tests/sampling/CMakeLists.txt)
function(ADD_CUSTOM_TEST TEST_NAME TEST_SOURCES TEST_DEPS)
    # 1. Define the executable
    add_executable(${TEST_NAME} ${TEST_SOURCES})

    # 2. Add include directories (using SYSTEM PRIVATE for cleaner warnings)
    target_include_directories(${TEST_NAME} SYSTEM PRIVATE 
        "${PROJECT_SOURCE_DIR}")

    # 3. Handle platform-specific additional libs (e.g., stdc++fs)
    set(additional_libs)
    if (UNIX)
        list(APPEND additional_libs "stdc++fs")
    endif()

    # 4. Link dependencies
    # MKL_LIBS property must be set in the top-level file before this runs
    get_property(MKL_LIBS GLOBAL PROPERTY MKL_LIBS_PROPERTY)
    
    # Link against the single main library (not a separate test library)
    target_link_libraries(${TEST_NAME} PRIVATE
        ${TARGET_LIBRARY}     # Link the single main library
        ${TEST_DEPS}          # Link specific, extra dependencies passed as arguments
        ${MKL_LIBS}
        ${additional_libs}
        Boost::unit_test_framework
        project_options
    )

    # 5. Register the test with CTest
    add_test(${TEST_NAME} ${TEST_NAME} --log_level=unit_scope --report_level=detailed)

    # 6. Artefact management logic
    file(RELATIVE_PATH artpath ${PROJECT_SOURCE_DIR} ${CMAKE_CURRENT_SOURCE_DIR}/CMakeLists.txt)
    get_filename_component(artpath ${artpath} DIRECTORY)
    if (EXISTS ${PROJECT_SOURCE_DIR}/artefacts/${artpath}/artefacts)
        file(COPY ${PROJECT_SOURCE_DIR}/artefacts/${artpath}/artefacts DESTINATION ${CMAKE_CURRENT_BINARY_DIR})
    endif()
endfunction()


# --- Function 2: Configure linking for the main application executable ---
# Call this in the app/ CMakeLists.txt file.
function(CONFIGURE_EXECUTABLE_LINKING TARGET_NAME)
    # Retrieve MKL_LIBS from global property
    get_property(MKL_LIBS GLOBAL PROPERTY MKL_LIBS_PROPERTY)
    
    set(additional_libs)

    # Logic for SNOPT and Fortran libraries
    if (UNIX)
        if (ENABLE_OPTIMIZERS)
            target_compile_definitions(${TARGET_NAME} PRIVATE NOBS_ENABLE_OPTIMIZERS) 
            if (SIMULATE_SNOPT)      
                list(APPEND additional_libs "snoptProblem")
            else()
                list(APPEND additional_libs "${SNOPT_LIB}/lib/libsnopt7_cpp.a")
            endif()
        endif()
        list(APPEND additional_libs "gfortran")
        list(APPEND additional_libs "stdc++fs")
    else()
        # Windows specific optimizer logic
        if (ENABLE_OPTIMIZERS AND NOT SIMULATE_SNOPT)
            message(FATAL_ERROR "Only SNOPT simulation is currently supported on Windows")
        endif()
    endif()

    # Multithreading configuration
    if (MULTI_THREAD AND NOT CMAKE_BUILD_TYPE STREQUAL "Debug")
        target_compile_definitions(${TARGET_NAME} PRIVATE MULTI_THREAD)
    endif()

    # Final linking step
    target_link_libraries(${TARGET_NAME} PRIVATE
        boltMathBackend
        ${TARGET_LIBRARY}
        ${MKL_LIBS}
        ${additional_libs}
        OpenMP::OpenMP_CXX
        project_options
    )
endfunction()


# --- Function 3: Add sources to the main library target ---
# Call this in library subdirectories (e.g., common/ CMakeLists.txt).
# Usage: ADD_LIBRARY_COMPONENT(PRIVATE file1.cpp file2.cpp PUBLIC header1.hpp header2.hpp)
# Note: Both PRIVATE and PUBLIC keywords are optional - omit if no sources of that type
function(ADD_LIBRARY_COMPONENT)
    set(options "")
    set(oneValueArgs "")
    set(multiValueArgs PRIVATE PUBLIC)
    
    # Parse arguments using keyword syntax
    cmake_parse_arguments(ARG "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    
    # Add sources to the single main library target
    if(ARG_PRIVATE)
        target_sources(${TARGET_LIB} PRIVATE ${ARG_PRIVATE})
    endif()
    
    if(ARG_PUBLIC)
        target_sources(${TARGET_LIB} PUBLIC ${ARG_PUBLIC})
    endif()
    
    # Add current directory to include path
    target_include_directories(${TARGET_LIB} PUBLIC ${CMAKE_CURRENT_LIST_DIR})
endfunction()
