#pragma once

#include "BoltTypes.hpp"
#include <vector>
#include <stdexcept>
#include <mkl.h>

namespace bolt {

// =============================================================================
// LEVEL 1 BLAS: VECTOR OPERATIONS
// =============================================================================

/// Scale a vector by a constant: x = alpha * x
/// 
/// @param alpha Scaling factor
/// @param x Vector to scale (modified in-place)
/// 
/// **Complexity:** O(n)
/// **MKL Function:** cblas_dscal
inline void scale(real alpha, std::vector<real>& x) {
    size_t n = x.size();
    mkl_index n_mkl = to_mkl_index(n);
    
    cblas_dscal(n_mkl, alpha, x.data(), 1);
}

/// Scale a vector by a constant: y = alpha * x (non-destructive)
/// 
/// @param alpha Scaling factor
/// @param x Input vector (not modified)
/// @param y Output vector (must be pre-allocated to same size as x)
/// @throws std::invalid_argument if vectors have different sizes
inline void scale(real alpha, const std::vector<real>& x, std::vector<real>& y) {
    if (x.size() != y.size()) {
        throw std::invalid_argument("Vectors must have the same size");
    }
    
    size_t n = x.size();
    mkl_index n_mkl = to_mkl_index(n);
    
    // Copy x to y, then scale
    cblas_dcopy(n_mkl, x.data(), 1, y.data(), 1);
    cblas_dscal(n_mkl, alpha, y.data(), 1);
}

/// Compute dot product: result = x^T * y
/// 
/// @param x First vector
/// @param y Second vector
/// @return Dot product
/// @throws std::invalid_argument if vectors have different sizes
/// 
/// **Complexity:** O(n)
/// **MKL Function:** cblas_ddot
inline real dot(const std::vector<real>& x, const std::vector<real>& y) {
    if (x.size() != y.size()) {
        throw std::invalid_argument("Vectors must have the same size");
    }
    
    size_t n = x.size();
    mkl_index n_mkl = to_mkl_index(n);
    
    return cblas_ddot(n_mkl, x.data(), 1, y.data(), 1);
}

/// Compute Euclidean norm: ||x||_2
/// 
/// @param x Input vector
/// @return Euclidean norm (L2 norm)
/// 
/// **Complexity:** O(n)
/// **MKL Function:** cblas_dnrm2
inline real norm(const std::vector<real>& x) {
    size_t n = x.size();
    mkl_index n_mkl = to_mkl_index(n);
    
    return cblas_dnrm2(n_mkl, x.data(), 1);
}

/// Vector addition with scaling: y = alpha * x + y
/// 
/// @param alpha Scaling factor for x
/// @param x Input vector (not modified)
/// @param y Input/output vector (modified in-place)
/// @throws std::invalid_argument if vectors have different sizes
/// 
/// **Complexity:** O(n)
/// **MKL Function:** cblas_daxpy
inline void axpy(real alpha, const std::vector<real>& x, std::vector<real>& y) {
    if (x.size() != y.size()) {
        throw std::invalid_argument("Vectors must have the same size");
    }
    
    size_t n = x.size();
    mkl_index n_mkl = to_mkl_index(n);
    
    cblas_daxpy(n_mkl, alpha, x.data(), 1, y.data(), 1);
}

/// Vector addition with scaling: z = alpha * x + y (non-destructive)
/// 
/// @param alpha Scaling factor for x
/// @param x First input vector
/// @param y Second input vector
/// @param z Output vector (must be pre-allocated)
/// @throws std::invalid_argument if vectors have different sizes
inline void axpy(real alpha, 
                 const std::vector<real>& x,
                 const std::vector<real>& y,
                 std::vector<real>& z) {
    if (x.size() != y.size() || x.size() != z.size()) {
        throw std::invalid_argument("All vectors must have the same size");
    }
    
    size_t n = x.size();
    mkl_index n_mkl = to_mkl_index(n);
    
    // Copy y to z first
    cblas_dcopy(n_mkl, y.data(), 1, z.data(), 1);
    
    // Add alpha * x to z
    cblas_daxpy(n_mkl, alpha, x.data(), 1, z.data(), 1);
}

/// Copy vector: y = x
/// 
/// @param x Source vector
/// @param y Destination vector (must be pre-allocated)
/// @throws std::invalid_argument if vectors have different sizes
/// 
/// **Complexity:** O(n)
/// **MKL Function:** cblas_dcopy
inline void copy(const std::vector<real>& x, std::vector<real>& y) {
    if (x.size() != y.size()) {
        throw std::invalid_argument("Vectors must have the same size");
    }
    
    size_t n = x.size();
    mkl_index n_mkl = to_mkl_index(n);
    
    cblas_dcopy(n_mkl, x.data(), 1, y.data(), 1);
}

// =============================================================================
// LEVEL 2 BLAS: MATRIX-VECTOR OPERATIONS
// =============================================================================

/// Matrix-vector multiplication: y = alpha * A * x + beta * y
/// 
/// @param rows Number of rows in A
/// @param cols Number of columns in A
/// @param alpha Scaling factor for A*x
/// @param A Matrix in row-major format (size must be rows * cols)
/// @param x Input vector (size must be cols)
/// @param beta Scaling factor for y
/// @param y Output vector (size must be rows, modified in-place)
/// @throws std::invalid_argument if dimensions don't match
/// 
/// **Complexity:** O(rows * cols)
/// **MKL Function:** cblas_dgemv
inline void gemv(size_t rows, 
                 size_t cols,
                 real alpha,
                 const std::vector<real>& A,
                 const std::vector<real>& x,
                 real beta,
                 std::vector<real>& y) {
    // Validate dimensions
    if (A.size() != rows * cols) {
        throw std::invalid_argument("Matrix size mismatch: expected " + 
                                   std::to_string(rows * cols) + 
                                   " elements, got " + 
                                   std::to_string(A.size()));
    }
    if (x.size() != cols) {
        throw std::invalid_argument("Vector x size must equal matrix columns");
    }
    if (y.size() != rows) {
        throw std::invalid_argument("Vector y size must equal matrix rows");
    }
    
    // Convert dimensions to MKL integer types
    mkl_index m = to_mkl_index(rows);
    mkl_index n = to_mkl_index(cols);
    mkl_index lda = n; // Leading dimension for row-major storage
    
    // Call MKL GEMV (row-major layout)
    cblas_dgemv(
        CblasRowMajor,  // Layout
        CblasNoTrans,   // No transpose
        m,              // Number of rows
        n,              // Number of columns
        alpha,          // Scale factor for A*x
        A.data(),       // Matrix data
        lda,            // Leading dimension
        x.data(),       // Input vector
        1,              // Increment for x
        beta,           // Scale factor for y
        y.data(),       // Output vector
        1               // Increment for y
    );
}

/// Matrix-vector multiplication with transpose: y = alpha * A^T * x + beta * y
/// 
/// @param rows Number of rows in A (before transpose)
/// @param cols Number of columns in A (before transpose)
/// @param alpha Scaling factor for A^T*x
/// @param A Matrix in row-major format
/// @param x Input vector (size must be rows)
/// @param beta Scaling factor for y
/// @param y Output vector (size must be cols, modified in-place)
/// @throws std::invalid_argument if dimensions don't match
inline void gemv_transpose(size_t rows,
                          size_t cols,
                          real alpha,
                          const std::vector<real>& A,
                          const std::vector<real>& x,
                          real beta,
                          std::vector<real>& y) {
    if (A.size() != rows * cols) {
        throw std::invalid_argument("Matrix size mismatch");
    }
    if (x.size() != rows) {
        throw std::invalid_argument("Vector x size must equal matrix rows");
    }
    if (y.size() != cols) {
        throw std::invalid_argument("Vector y size must equal matrix columns");
    }
    
    mkl_index m = to_mkl_index(rows);
    mkl_index n = to_mkl_index(cols);
    mkl_index lda = n;
    
    cblas_dgemv(
        CblasRowMajor,
        CblasTrans,     // Transpose A
        m,
        n,
        alpha,
        A.data(),
        lda,
        x.data(),
        1,
        beta,
        y.data(),
        1
    );
}

// =============================================================================
// LEVEL 3 BLAS: MATRIX-MATRIX OPERATIONS
// =============================================================================

/// Matrix-matrix multiplication: C = alpha * A * B + beta * C
/// 
/// All matrices are stored in row-major format.
/// 
/// @param m Number of rows in A and C
/// @param k Number of columns in A and rows in B
/// @param n Number of columns in B and C
/// @param alpha Scaling factor for A*B
/// @param A First input matrix (m x k, row-major)
/// @param B Second input matrix (k x n, row-major)
/// @param beta Scaling factor for C
/// @param C Output matrix (m x n, row-major, modified in-place)
/// @throws std::invalid_argument if dimensions don't match
/// 
/// **Complexity:** O(m * n * k)
/// **MKL Function:** cblas_dgemm
inline void gemm(size_t m,
                 size_t k, 
                 size_t n,
                 real alpha,
                 const std::vector<real>& A,
                 const std::vector<real>& B,
                 real beta,
                 std::vector<real>& C) {
    // Validate dimensions
    if (A.size() != m * k) {
        throw std::invalid_argument("Matrix A size mismatch: expected " +
                                   std::to_string(m * k) +
                                   " elements, got " +
                                   std::to_string(A.size()));
    }
    if (B.size() != k * n) {
        throw std::invalid_argument("Matrix B size mismatch: expected " +
                                   std::to_string(k * n) +
                                   " elements, got " +
                                   std::to_string(B.size()));
    }
    if (C.size() != m * n) {
        throw std::invalid_argument("Matrix C size mismatch: expected " +
                                   std::to_string(m * n) +
                                   " elements, got " +
                                   std::to_string(C.size()));
    }
    
    // Convert to MKL integer types
    mkl_index m_mkl = to_mkl_index(m);
    mkl_index k_mkl = to_mkl_index(k);
    mkl_index n_mkl = to_mkl_index(n);
    
    // Leading dimensions for row-major storage
    mkl_index lda = k_mkl;
    mkl_index ldb = n_mkl;
    mkl_index ldc = n_mkl;
    
    // Call MKL GEMM
    cblas_dgemm(
        CblasRowMajor,  // Layout
        CblasNoTrans,   // No transpose for A
        CblasNoTrans,   // No transpose for B
        m_mkl,          // Rows in A and C
        n_mkl,          // Columns in B and C
        k_mkl,          // Columns in A, rows in B
        alpha,          // Scale factor for A*B
        A.data(),       // Matrix A
        lda,            // Leading dimension of A
        B.data(),       // Matrix B
        ldb,            // Leading dimension of B
        beta,           // Scale factor for C
        C.data(),       // Matrix C
        ldc             // Leading dimension of C
    );
}

// =============================================================================
// RAW POINTER INTERFACES (for advanced usage with non-owning views)
// =============================================================================

/// Scale a raw array by a constant: x = alpha * x
/// 
/// @param n Number of elements
/// @param alpha Scaling factor
/// @param x Pointer to array data (modified in-place)
/// 
/// **Warning:** No bounds checking. Caller must ensure valid pointer and size.
inline void scale_raw(size_t n, real alpha, real* x) {
    mkl_index n_mkl = to_mkl_index(n);
    cblas_dscal(n_mkl, alpha, x, 1);
}

/// Compute dot product of raw arrays: result = x^T * y
/// 
/// @param n Number of elements
/// @param x Pointer to first array
/// @param y Pointer to second array
/// @return Dot product
/// 
/// **Warning:** No bounds checking. Caller must ensure valid pointers and size.
inline real dot_raw(size_t n, const real* x, const real* y) {
    mkl_index n_mkl = to_mkl_index(n);
    return cblas_ddot(n_mkl, x, 1, y, 1);
}

/// Vector addition with scaling on raw arrays: y = alpha * x + y
/// 
/// @param n Number of elements
/// @param alpha Scaling factor for x
/// @param x Input array (not modified)
/// @param y Input/output array (modified in-place)
/// 
/// **Warning:** No bounds checking. Caller must ensure valid pointers and size.
inline void axpy_raw(size_t n, real alpha, const real* x, real* y) {
    mkl_index n_mkl = to_mkl_index(n);
    cblas_daxpy(n_mkl, alpha, x, 1, y, 1);
}

/// Copy raw array: y = x
/// 
/// @param n Number of elements
/// @param x Source array
/// @param y Destination array
/// 
/// **Warning:** No bounds checking. Caller must ensure valid pointers and size.
inline void copy_raw(size_t n, const real* x, real* y) {
    mkl_index n_mkl = to_mkl_index(n);
    cblas_dcopy(n_mkl, x, 1, y, 1);
}

} // namespace bolt
