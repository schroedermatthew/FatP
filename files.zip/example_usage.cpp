#include "BoltTypes.hpp"
#include "MathKernels.hpp"
#include <iostream>
#include <iomanip>
#include <vector>

using namespace bolt;

void print_vector(const std::vector<real>& v, const char* name) {
    std::cout << name << ": [";
    for (size_t i = 0; i < v.size(); ++i) {
        std::cout << std::setw(8) << std::setprecision(4) << v[i];
        if (i < v.size() - 1) std::cout << ", ";
    }
    std::cout << "]" << std::endl;
}

void example_vector_operations() {
    std::cout << "\n=== Vector Operations ===\n" << std::endl;
    
    // Create vectors
    std::vector<real> x = {1.0, 2.0, 3.0, 4.0, 5.0};
    std::vector<real> y = {5.0, 4.0, 3.0, 2.0, 1.0};
    
    print_vector(x, "x");
    print_vector(y, "y");
    
    // Dot product
    real dp = dot(x, y);
    std::cout << "\nDot product x·y: " << dp << std::endl;
    
    // Norm
    real norm_x = norm(x);
    std::cout << "Norm ||x||: " << norm_x << std::endl;
    
    // Scale
    std::vector<real> x_scaled = x;
    scale(2.0, x_scaled);
    print_vector(x_scaled, "2*x");
    
    // AXPY: y = 0.5*x + y
    std::vector<real> y_axpy = y;
    axpy(0.5, x, y_axpy);
    print_vector(y_axpy, "0.5*x + y");
}

void example_matrix_vector() {
    std::cout << "\n=== Matrix-Vector Operations ===\n" << std::endl;
    
    // 3x3 matrix (row-major)
    size_t rows = 3;
    size_t cols = 3;
    
    std::vector<real> A = {
        1.0, 0.0, 0.0,
        0.0, 2.0, 0.0,
        0.0, 0.0, 3.0
    };
    
    std::vector<real> x = {1.0, 2.0, 3.0};
    std::vector<real> y(rows, 0.0);
    
    std::cout << "A (3x3 diagonal):\n";
    for (size_t i = 0; i < rows; ++i) {
        std::cout << "  [";
        for (size_t j = 0; j < cols; ++j) {
            std::cout << std::setw(8) << A[i * cols + j];
        }
        std::cout << "]\n";
    }
    
    print_vector(x, "\nx");
    
    // y = A * x
    gemv(rows, cols, 1.0, A, x, 0.0, y);
    print_vector(y, "y = A*x");
}

void example_matrix_matrix() {
    std::cout << "\n=== Matrix-Matrix Operations ===\n" << std::endl;
    
    size_t m = 2, k = 3, n = 2;
    
    // A is 2x3
    std::vector<real> A = {
        1.0, 2.0, 3.0,
        4.0, 5.0, 6.0
    };
    
    // B is 3x2
    std::vector<real> B = {
        7.0, 8.0,
        9.0, 10.0,
        11.0, 12.0
    };
    
    // C is 2x2
    std::vector<real> C(m * n, 0.0);
    
    std::cout << "A (2x3):\n";
    for (size_t i = 0; i < m; ++i) {
        std::cout << "  [";
        for (size_t j = 0; j < k; ++j) {
            std::cout << std::setw(8) << A[i * k + j];
        }
        std::cout << "]\n";
    }
    
    std::cout << "\nB (3x2):\n";
    for (size_t i = 0; i < k; ++i) {
        std::cout << "  [";
        for (size_t j = 0; j < n; ++j) {
            std::cout << std::setw(8) << B[i * n + j];
        }
        std::cout << "]\n";
    }
    
    // C = A * B
    gemm(m, k, n, 1.0, A, B, 0.0, C);
    
    std::cout << "\nC = A*B (2x2):\n";
    for (size_t i = 0; i < m; ++i) {
        std::cout << "  [";
        for (size_t j = 0; j < n; ++j) {
            std::cout << std::setw(8) << C[i * n + j];
        }
        std::cout << "]\n";
    }
}

void example_large_arrays() {
    std::cout << "\n=== Large Array Support ===\n" << std::endl;
    
    size_t large_n = 100'000'000; // 100 million elements (~800 MB)
    
    std::cout << "Creating vector of size: " << large_n << std::endl;
    std::cout << "Memory required: ~" << (large_n * sizeof(real)) / (1024*1024) << " MB" << std::endl;
    
    // Demonstrate safe conversion
    mkl_index n_mkl = to_mkl_index(large_n);
    std::cout << "Converted to mkl_index: " << n_mkl << std::endl;
    std::cout << "Conversion successful (within 2^63-1 limit)" << std::endl;
    
    // Would create the vector if we had memory:
    // std::vector<real> large_vec(large_n, 1.0);
    // scale(0.5, large_vec);
}

void example_error_handling() {
    std::cout << "\n=== Error Handling ===\n" << std::endl;
    
    try {
        // Attempt to overflow
        size_t impossible_size = std::numeric_limits<size_t>::max();
        std::cout << "Attempting to convert size: " << impossible_size << std::endl;
        mkl_index bad_index = to_mkl_index(impossible_size);
        std::cout << "This should not print: " << bad_index << std::endl;
    }
    catch (const std::overflow_error& e) {
        std::cout << "Caught overflow error: " << e.what() << std::endl;
    }
    
    try {
        // Attempt negative conversion
        mkl_index negative = -100;
        std::cout << "\nAttempting to convert negative index: " << negative << std::endl;
        size_t bad_size = to_size_t(negative);
        std::cout << "This should not print: " << bad_size << std::endl;
    }
    catch (const std::domain_error& e) {
        std::cout << "Caught domain error: " << e.what() << std::endl;
    }
    
    try {
        // Mismatched vector sizes
        std::vector<real> x = {1.0, 2.0, 3.0};
        std::vector<real> y = {1.0, 2.0};
        std::cout << "\nAttempting dot product with mismatched sizes" << std::endl;
        real result = dot(x, y);
        std::cout << "This should not print: " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Caught invalid argument: " << e.what() << std::endl;
    }
}

int main() {
    std::cout << std::fixed << std::setprecision(4);
    
    std::cout << "BOLT Library Example Usage" << std::endl;
    std::cout << "===========================" << std::endl;
    
    std::cout << "\nType System:" << std::endl;
    std::cout << "  sizeof(real): " << sizeof(real) << " bytes" << std::endl;
    std::cout << "  sizeof(mkl_index): " << sizeof(mkl_index) << " bytes" << std::endl;
    std::cout << "  sizeof(size_t): " << sizeof(size_t) << " bytes" << std::endl;
    
    example_vector_operations();
    example_matrix_vector();
    example_matrix_matrix();
    example_large_arrays();
    example_error_handling();
    
    std::cout << "\n=== All examples completed successfully ===" << std::endl;
    
    return 0;
}
