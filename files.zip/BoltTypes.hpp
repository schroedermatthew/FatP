#pragma once

#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <complex>

// Include MKL types
#ifdef BOLT_USE_DOUBLE_PRECISION
    #include <mkl.h>
#else
    #error "Only double precision is supported"
#endif

namespace bolt {

// =============================================================================
// FUNDAMENTAL TYPES
// =============================================================================

/// Floating-point type for all BOLT numerical operations.
/// Always double precision (IEEE 754 binary64).
/// 
/// **Design Rationale:**
/// BOLT uses `real` rather than `double` directly to:
/// 1. Provide semantic clarity in numerical contexts (real numbers, not storage)
/// 2. Signal that this is a mathematical/computational value
/// 3. Maintain consistency with numerical computing conventions
/// 4. Enable clear distinction from platform types in code
/// 
/// **Properties:**
/// - Precision: ~15-17 decimal digits
/// - Range: ±1.7e±308
/// - Size: 64 bits (8 bytes)
/// 
/// @note This type is NOT configurable. BOLT only supports double precision.
using real = double;

/// Complex numbers built on real type
using complex = std::complex<real>;

/// MKL-compatible signed integer type for array dimensions and indices.
/// Uses 64-bit signed integers when MKL_ILP64 is defined.
/// 
/// **Usage:**
/// - All MKL function parameters (N, M, K, LDA, strides, etc.)
/// - Dimensions passed to BLAS/LAPACK routines
/// - Any integer that interfaces with Intel MKL
/// 
/// **Properties:**
/// - Type: int64_t (when MKL_ILP64 is defined)
/// - Range: -2^63 to 2^63-1
/// - Maximum array dimension: 9,223,372,036,854,775,807 elements
using mkl_index = MKL_INT;

// =============================================================================
// COMPILE-TIME VERIFICATION
// =============================================================================

static_assert(std::is_same_v<real, double>, 
              "BOLT library only supports double precision");
static_assert(sizeof(real) == 8,
              "real must be 64-bit IEEE 754 double");
static_assert(std::numeric_limits<real>::is_iec559,
              "real must conform to IEEE 754");

static_assert(sizeof(mkl_index) == 8, 
              "MKL_ILP64 must be defined for 64-bit integer support");
static_assert(std::is_signed_v<mkl_index>, 
              "MKL_INT must be a signed integer type");

// =============================================================================
// CONVERSION UTILITIES
// =============================================================================

/// Convert size_t to MKL's signed 64-bit integer type with overflow checking.
/// 
/// **Usage:**
/// ```cpp
/// std::vector<real> data(n);
/// size_t size = data.size();
/// mkl_index n_mkl = to_mkl_index(size);
/// cblas_dscal(n_mkl, alpha, data.data(), 1);
/// ```
/// 
/// @param sz The size_t value to convert
/// @return The value as mkl_index
/// @throws std::overflow_error if sz exceeds the maximum representable mkl_index value
/// 
/// **Maximum Safe Value:** 2^63-1 (9,223,372,036,854,775,807)
inline constexpr mkl_index to_mkl_index(size_t sz) {
    // Maximum safe value for signed 64-bit integer
    constexpr size_t max_safe = 
        static_cast<size_t>(std::numeric_limits<mkl_index>::max());
    
    if (sz > max_safe) {
        throw std::overflow_error(
            "Size exceeds maximum MKL_INT value (2^63-1). "
            "Array dimension too large for MKL operations."
        );
    }
    
    return static_cast<mkl_index>(sz);
}

/// Convert mkl_index to size_t with bounds checking.
/// 
/// Always safe for positive values since size_t has larger unsigned range.
/// Throws if the mkl_index is negative (which would be invalid for sizes).
/// 
/// @param idx The mkl_index value to convert
/// @return The value as size_t
/// @throws std::domain_error if idx is negative
inline constexpr size_t to_size_t(mkl_index idx) {
    if (idx < 0) {
        throw std::domain_error(
            "Cannot convert negative MKL_INT to size_t. "
            "Negative indices are invalid for size/count operations."
        );
    }
    return static_cast<size_t>(idx);
}

/// No-throw version of to_mkl_index for use in constexpr or noexcept contexts.
/// Returns -1 on overflow to indicate error.
/// 
/// **Usage:** When you need constexpr evaluation or guaranteed no-throw
/// ```cpp
/// constexpr mkl_index n = to_mkl_index_unchecked(1000); // OK at compile time
/// if (n == -1) { /* handle error */ }
/// ```
/// 
/// @param sz The size_t value to convert
/// @return The value as mkl_index, or -1 if overflow would occur
inline constexpr mkl_index to_mkl_index_unchecked(size_t sz) noexcept {
    constexpr size_t max_safe = 
        static_cast<size_t>(std::numeric_limits<mkl_index>::max());
    
    return (sz > max_safe) ? mkl_index{-1} : static_cast<mkl_index>(sz);
}

// =============================================================================
// TYPE TRAITS
// =============================================================================

/// Check if a type is a valid index type (size_t or mkl_index)
template<typename T>
struct is_index_type : std::false_type {};

template<>
struct is_index_type<mkl_index> : std::true_type {};

template<>
struct is_index_type<size_t> : std::true_type {};

template<typename T>
inline constexpr bool is_index_type_v = is_index_type<T>::value;

// =============================================================================
// DOCUMENTATION AND USAGE GUIDELINES
// =============================================================================

/*
 * TYPE USAGE GUIDELINES:
 * ======================
 * 
 * 1. USE size_t FOR:
 *    - STL container sizes: vector.size(), array.size()
 *    - Memory allocation sizes
 *    - Loop indices over STL containers
 *    - General-purpose non-negative counts
 *    - Standard C++ interfaces
 * 
 * 2. USE mkl_index FOR:
 *    - All MKL function parameters (N, M, K, LDA, etc.)
 *    - Dimensions passed to BLAS/LAPACK
 *    - Strides and increments in MKL calls
 *    - Any integer that interfaces directly with MKL
 * 
 * 3. USE real FOR:
 *    - All numerical computations
 *    - Matrix/vector element types
 *    - Function parameters representing mathematical quantities
 *    - Public API signatures
 * 
 * 4. CONVERSION PATTERN:
 *    ```cpp
 *    std::vector<real> data(n);
 *    
 *    // Get size as size_t (natural for STL)
 *    size_t n_size = data.size();
 *    
 *    // Convert to mkl_index for MKL call
 *    mkl_index n_mkl = to_mkl_index(n_size);
 *    
 *    // Call MKL function
 *    cblas_dscal(n_mkl, alpha, data.data(), 1);
 *    ```
 * 
 * 5. LARGE ARRAY SUPPORT:
 *    - With MKL_ILP64: Supports arrays up to 2^63-1 elements
 *    - Practical limit: System memory (typically << 2^63)
 *    - Example: A double array with 2^31 elements = 16 GB
 *    - Maximum mkl_index: 9,223,372,036,854,775,807 elements
 *    - Maximum size_t: 18,446,744,073,709,551,615 elements
 *    - The conversion function ensures we stay within MKL's signed limit
 * 
 * 6. PERFORMANCE NOTES:
 *    - Conversions are constexpr and optimize to nothing in release builds
 *    - Overflow checks are typically compiled out for constant expressions
 *    - Use unchecked version only when absolutely necessary for performance
 */

} // namespace bolt
