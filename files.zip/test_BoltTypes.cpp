#define BOOST_TEST_MODULE BoltTypesTests
#include <boost/test/unit_test.hpp>
#include "BoltTypes.hpp"

using namespace bolt;

BOOST_AUTO_TEST_SUITE(TypeVerification)

BOOST_AUTO_TEST_CASE(RealTypeProperties) {
    BOOST_CHECK_EQUAL(sizeof(real), 8);
    BOOST_CHECK((std::is_same_v<real, double>));
    BOOST_CHECK(std::numeric_limits<real>::is_iec559);
}

BOOST_AUTO_TEST_CASE(MklIndexProperties) {
    BOOST_CHECK_EQUAL(sizeof(mkl_index), 8);
    BOOST_CHECK((std::is_signed_v<mkl_index>));
}

BOOST_AUTO_TEST_CASE(ComplexTypeProperties) {
    BOOST_CHECK_EQUAL(sizeof(complex), 16);
    BOOST_CHECK((std::is_same_v<complex, std::complex<double>>));
}

BOOST_AUTO_TEST_SUITE_END()

BOOST_AUTO_TEST_SUITE(TypeConversions)

BOOST_AUTO_TEST_CASE(SmallValidConversion) {
    size_t sz = 1000;
    mkl_index mkl_idx = to_mkl_index(sz);
    
    BOOST_CHECK_EQUAL(mkl_idx, 1000);
}

BOOST_AUTO_TEST_CASE(LargeValidConversion) {
    size_t large_sz = 1'000'000'000; // 1 billion
    mkl_index mkl_idx = to_mkl_index(large_sz);
    
    BOOST_CHECK_EQUAL(mkl_idx, 1'000'000'000);
}

BOOST_AUTO_TEST_CASE(MaxValidConversion) {
    constexpr size_t max_safe = 
        static_cast<size_t>(std::numeric_limits<mkl_index>::max());
    
    mkl_index mkl_idx = to_mkl_index(max_safe);
    
    BOOST_CHECK_EQUAL(mkl_idx, std::numeric_limits<mkl_index>::max());
}

BOOST_AUTO_TEST_CASE(OverflowThrows) {
    size_t too_large = 
        static_cast<size_t>(std::numeric_limits<mkl_index>::max()) + 1;
    
    BOOST_CHECK_THROW(to_mkl_index(too_large), std::overflow_error);
}

BOOST_AUTO_TEST_CASE(ReverseConversion) {
    mkl_index mkl_idx = 5000;
    size_t sz = to_size_t(mkl_idx);
    
    BOOST_CHECK_EQUAL(sz, 5000u);
}

BOOST_AUTO_TEST_CASE(NegativeIndexThrows) {
    mkl_index negative = -100;
    
    BOOST_CHECK_THROW(to_size_t(negative), std::domain_error);
}

BOOST_AUTO_TEST_CASE(UncheckedConversionValid) {
    size_t sz = 1000;
    mkl_index mkl_idx = to_mkl_index_unchecked(sz);
    
    BOOST_CHECK_EQUAL(mkl_idx, 1000);
}

BOOST_AUTO_TEST_CASE(UncheckedConversionOverflow) {
    size_t too_large = 
        static_cast<size_t>(std::numeric_limits<mkl_index>::max()) + 1;
    
    mkl_index mkl_idx = to_mkl_index_unchecked(too_large);
    
    BOOST_CHECK_EQUAL(mkl_idx, -1);
}

BOOST_AUTO_TEST_CASE(ConstexprConversion) {
    constexpr size_t compile_time_size = 100;
    constexpr mkl_index compile_time_index = to_mkl_index_unchecked(compile_time_size);
    
    BOOST_CHECK_EQUAL(compile_time_index, 100);
}

BOOST_AUTO_TEST_SUITE_END()

BOOST_AUTO_TEST_SUITE(TypeTraits)

BOOST_AUTO_TEST_CASE(IndexTypeTraits) {
    BOOST_CHECK((is_index_type_v<mkl_index>));
    BOOST_CHECK((is_index_type_v<size_t>));
    BOOST_CHECK(!(is_index_type_v<int>));
    BOOST_CHECK(!(is_index_type_v<real>));
}

BOOST_AUTO_TEST_SUITE_END()
