# cmake/CompilerOptions.cmake

# Define standard warnings as an interface library for reusability
add_library(project_options INTERFACE)

# Define compiler-agnostic warning flags
target_compile_options(project_options INTERFACE
    "$<$<CXX_COMPILER_ID:MSVC>:/W3>"
    "$<$<OR:$<CXX_COMPILER_ID:GNU>,$<CXX_COMPILER_ID:Clang>>:-Wall;-Wextra;-pedantic>"
    "$<$<OR:$<CXX_COMPILER_ID:Intel>,$<CXX_COMPILER_ID:IntelLLVM>>:-QWall;-QWextra;-Qpedantic>"
)

# Handle MSVC runtime library selection globally
if (MSVC)
    set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
endif()
