# BOLT Library - Type System and CMake Configuration

This package contains the complete type system implementation and CMake configuration fixes for the BOLT/NOBS_CLIP library.

## Files Included

### C++ Header Files
- **BoltTypes.hpp** - Core type system with `real`, `complex`, `mkl_index` types and conversion utilities
- **MathKernels.hpp** - Complete BLAS wrapper implementations (Level 1, 2, 3)

### C++ Implementation Files
- **example_usage.cpp** - Comprehensive examples demonstrating all features
- **test_BoltTypes.cpp** - Unit tests using Boost.Test framework

### CMake Configuration Files
- **CompilerOptions.cmake** - Compiler warning configuration (goes in cmake/)
- **UtilityFunctions.cmake** - Helper functions for build system (goes in cmake/)
- **CMakeLists_root.txt** - Main project CMakeLists.txt (rename to CMakeLists.txt)
- **CMakeLists_app.txt** - App subdirectory CMakeLists.txt (rename to CMakeLists.txt)
- **CMakeLists_BOLT.txt** - BOLT subdirectory CMakeLists.txt (rename to CMakeLists.txt)
- **CMakeLists_examples.txt** - Examples of subdirectory CMakeLists.txt files

## Key Design Decisions

### Type System
1. **`real`** instead of `real_t` - Semantic clarity, not platform abstraction
2. **No `size_type` alias** - Just use `size_t` directly (already fundamental)
3. **`mkl_index`** for MKL interfacing - Signed 64-bit integers for large arrays
4. **Always double precision** - Removed configurability, single supported precision
5. **Always MKL_ILP64** - 64-bit integer support for arrays > 2 billion elements

### CMake Improvements
1. **Single library architecture** - Eliminated duplicate test library compilation
2. **Modern target_compile_definitions()** - Replaced deprecated add_definitions()
3. **Keyword-based ADD_LIBRARY_COMPONENT** - Uses PRIVATE/PUBLIC keywords
4. **Fixed MKL_LIBS retrieval** - Added get_property() call where missing
5. **Proper Boost handling** - Guarded behind BUILD_TESTS, removed from main executable
6. **Consistent project_options** - Applied to all targets for uniform warnings

## Installation

1. **Copy header files to your BOLT/bolt/ directory:**
   ```
   BoltTypes.hpp → BOLT/bolt/BoltTypes.hpp
   MathKernels.hpp → BOLT/bolt/MathKernels.hpp
   ```

2. **Replace CMake configuration files:**
   ```
   CompilerOptions.cmake → cmake/CompilerOptions.cmake
   UtilityFunctions.cmake → cmake/UtilityFunctions.cmake
   CMakeLists_root.txt → CMakeLists.txt (root directory)
   CMakeLists_app.txt → app/CMakeLists.txt
   CMakeLists_BOLT.txt → BOLT/CMakeLists.txt
   ```

3. **Update all subdirectory CMakeLists.txt files** to use the new syntax:
   
   **Old syntax:**
   ```cmake
   ADD_LIBRARY_COMPONENT(${PRIVATE_SOURCES} ${PUBLIC_SOURCES})
   ```
   
   **New syntax:**
   ```cmake
   ADD_LIBRARY_COMPONENT(
       PRIVATE ${PRIVATE_SOURCES}
       PUBLIC ${PUBLIC_SOURCES}
   )
   ```
   
   Or if no private sources:
   ```cmake
   ADD_LIBRARY_COMPONENT(
       PUBLIC ${PUBLIC_SOURCES}
   )
   ```

4. **Update subdirectories that need changes:**
   - core/CMakeLists.txt
   - modules/CMakeLists.txt (and subdirectories)
   - testutils/CMakeLists.txt
   - common/logger/CMakeLists.txt
   - common/parser/CMakeLists.txt
   - Any other subdirectories using ADD_LIBRARY_COMPONENT

   See `CMakeLists_examples.txt` for reference implementations.

## Type Usage Guidelines

### Use `size_t` for:
- STL container sizes: `vector.size()`, `array.size()`
- Memory allocation sizes
- Loop indices over STL containers
- General-purpose non-negative counts

### Use `mkl_index` for:
- All MKL function parameters (N, M, K, LDA, etc.)
- Dimensions passed to BLAS/LAPACK
- Strides and increments in MKL calls
- Any integer that interfaces with MKL

### Use `real` for:
- All numerical computations
- Matrix/vector element types
- Function parameters representing mathematical quantities
- Public API signatures

### Conversion Pattern:
```cpp
std::vector<real> data(n);

// Get size as size_t (natural for STL)
size_t n_size = data.size();

// Convert to mkl_index for MKL call
mkl_index n_mkl = to_mkl_index(n_size);

// Call MKL function
cblas_dscal(n_mkl, alpha, data.data(), 1);
```

## Building

```bash
mkdir build
cd build
cmake -DBUILD_TESTS=ON ..
cmake --build .
ctest  # Run tests
```

## Testing

The unit tests verify:
- Type properties (sizes, signedness, IEEE 754 compliance)
- Conversion functions (overflow checking, bounds checking)
- Type traits
- Constexpr evaluation

Run with:
```bash
cd build
ctest --verbose
```

## Large Array Support

With MKL_ILP64 enabled:
- Maximum array dimension: 2^63-1 elements (9.2 quintillion)
- Practical limit: System memory
- Example: 2^31 elements of double = 16 GB
- Conversion functions ensure staying within signed limit

## Features

### BLAS Level 1 (Vector Operations)
- `scale()` - Vector scaling
- `dot()` - Dot product
- `norm()` - Euclidean norm
- `axpy()` - Vector addition with scaling
- `copy()` - Vector copy

### BLAS Level 2 (Matrix-Vector Operations)
- `gemv()` - General matrix-vector multiplication
- `gemv_transpose()` - Transposed matrix-vector multiplication

### BLAS Level 3 (Matrix-Matrix Operations)
- `gemm()` - General matrix-matrix multiplication

### Raw Pointer Interfaces
For advanced usage with non-owning views:
- `scale_raw()`
- `dot_raw()`
- `axpy_raw()`
- `copy_raw()`

## Error Handling

All functions include:
- Dimension validation
- Overflow checking in conversions
- Clear error messages
- Exception-based error reporting

## Requirements

- C++17 or later
- Intel MKL (with MKL_ILP64 support)
- CMake 3.30+
- Boost (for tests, if BUILD_TESTS=ON)
- OpenMP

## License

(Add your license information here)

## Notes

- This is a header-only implementation for BoltTypes and MathKernels
- Zero external dependencies beyond MKL
- All conversions are constexpr and optimize to nothing in release builds
- Full compatibility with existing BOLT tensor operations
